import asyncio
import struct
import unittest

import codehost_mux_protocol as m


def h2(kind, flags=0, stream=0, payload=b''):
    return len(payload).to_bytes(3,'big') + bytes([kind,flags]) + stream.to_bytes(4,'big') + payload


class FramingTests(unittest.TestCase):
    def test_fragmented_and_coalesced_frames(self):
        expected = [(m.OPEN,1,b''),(m.DATA,1,b'opaque\x00\xff'),(m.HALF_CLOSE,1,b''),(m.FINISH,0,b'')]
        wire=b''.join(m.encode_frame(*v) for v in expected)
        for width in (1,3,14,17,len(wire)):
            parser=m.FrameParser(); actual=[]
            for offset in range(0,len(wire),width): actual.extend(parser.feed(wire[offset:offset+width]))
            parser.finish(); self.assertEqual(actual,expected)

    def test_header_and_payload_bounds_before_buffering(self):
        for header in (m.HEADER.pack(b'BAD!',3,m.DATA,1,5),m.HEADER.pack(m.MAGIC,4,m.DATA,1,5),
                       m.HEADER.pack(m.MAGIC,3,99,1,0),m.HEADER.pack(m.MAGIC,3,m.DATA,1,65537)):
            with self.assertRaises(ValueError):m.FrameParser().feed(header)
        for args in ((m.OPEN,0,b''),(m.FINISH,1,b''),(m.OPEN,1,b'x'),(m.DATA,1,b''),
                     (m.DATA,17,b'x'),(m.FINISH,False,b'')):
            with self.assertRaises(ValueError):m.encode_frame(*args)

    def test_partial_eof(self):
        wire=m.encode_frame(m.DATA,1,b'abc')
        for end in range(1,len(wire)):
            parser=m.FrameParser();parser.feed(wire[:end])
            with self.assertRaises(ValueError):parser.finish()

    def test_metadata_no_ambiguous_encoding(self):
        self.assertEqual(m.metadata(m.canonical({'a':1})),{'a':1})
        for raw in (b'{"a":1,"a":2}',b'[]',b'{ "a": 1 }',b'\xff'):
            with self.assertRaises((ValueError,UnicodeError)):m.metadata(raw)

    def test_queue_limits_and_release(self):
        b=m.QueueBudget()
        capacity=m.PER_CHANNEL_QUEUE_BYTES-b.headroom_bytes
        for c in range(1,5):b.reserve(c,capacity)
        b.reserve(5,3*b.headroom_bytes)
        with self.assertRaises(ValueError):b.reserve(5,1)
        with self.assertRaises(ValueError):b.reserve(1,1)
        b.release(1,capacity);b.reserve(6,capacity)
        self.assertEqual(b.total+b.headroom_bytes,m.AGGREGATE_QUEUE_BYTES)
        self.assertTrue(all(v+b.headroom_bytes<=m.PER_CHANNEL_QUEUE_BYTES for v in b.channel_maximum.values()))
        with self.assertRaises(ValueError):b.release(1,1)


class AsyncFramingTests(unittest.IsolatedAsyncioTestCase):
    async def test_read_eof_and_partial(self):
        reader=asyncio.StreamReader();reader.feed_data(m.encode_frame(m.OPEN,1));reader.feed_eof()
        self.assertEqual(await m.read_frame(reader),(m.OPEN,1,b''));self.assertIsNone(await m.read_frame(reader))
        for raw in (b'RC',m.encode_frame(m.DATA,1,b'abc')[:-1]):
            reader=asyncio.StreamReader();reader.feed_data(raw);reader.feed_eof()
            with self.assertRaises(ValueError):await m.read_frame(reader)


class H2Tests(unittest.TestCase):
    def ready(self):
        witness=m.H2Witness();witness.feed('upload',m.PREFACE+h2(4));witness.feed('download',h2(4));return witness

    def test_fragmented_lifecycle_and_idle_eof(self):
        w=m.H2Witness()
        for b in m.PREFACE+h2(4)+h2(1,5,1,b'\x82'):w.feed('upload',bytes([b]))
        for b in h2(4)+h2(1,4,1,b'\x88')+h2(0,1,1,b'payload'):w.feed('download',bytes([b]))
        self.assertEqual(w.idle_eof()['closed_streams'],1)

    def test_large_data_is_not_buffered(self):
        w=self.ready();w.feed('upload',h2(4,payload=b'\x00\x05'+(1048576).to_bytes(4,'big')))
        w.feed('upload',h2(1,5,1,b'\x82'));w.feed('download',h2(1,4,1,b'\x88'))
        wire=h2(0,1,1,b'x'*500000)
        for pos in range(0,len(wire),32768):
            w.feed('download',wire[pos:pos+32768])
            self.assertLessEqual(len(w.directions['download']['buffer']),9)
            if w.directions['download']['frame']:self.assertLessEqual(len(w.directions['download']['frame']['prefix']),8)
        self.assertEqual(w.idle_eof()['open_streams'],0)

    def test_live_lease_and_partial_frames_are_not_idle(self):
        w=self.ready();w.feed('upload',h2(1,5,1,b'\x82'));w.feed('download',h2(1,4,1,b'\x88'))
        self.assertEqual(w.summary()['active_stream_ids'],[1])
        with self.assertRaises(ValueError):w.idle_eof()
        for raw in (m.PREFACE[:5],m.PREFACE+h2(4)+h2(1,5,1,b'\x82')[:-1]):
            v=m.H2Witness();v.feed('upload',raw)
            with self.assertRaises(ValueError):v.idle_eof()

    def test_header_continuation_boundary(self):
        w=self.ready();w.feed('upload',h2(1,1,1,b'\x82'))
        with self.assertRaises(ValueError):w.idle_eof()
        w.feed('upload',h2(9,4,1,b'x'));w.feed('download',h2(1,5,1,b'\x88'))
        self.assertEqual(w.idle_eof()['closed_streams'],1)
        w=self.ready();w.feed('upload',h2(1,0,1,b'x'))
        with self.assertRaises(ValueError):w.feed('upload',h2(6,payload=b'12345678'))

    def test_rst_is_retained_never_idle_success(self):
        w=self.ready();w.feed('upload',h2(1,5,1,b'x'));w.feed('download',h2(3,0,1,(8).to_bytes(4,'big')))
        self.assertEqual(w.summary()['reset_records'],[{'direction':'download','stream_id':1,'error_code':8}])
        with self.assertRaises(ValueError):w.idle_eof()
        with self.assertRaises(ValueError):w.feed('download',h2(3,0,1,(8).to_bytes(4,'big')))

    def test_malformed_and_unknown_forms_fail_closed(self):
        cases=[h2(5,0,1,b''),h2(99),h2(6,payload=b'bad'),h2(4,payload=b'x'),
               h2(4,2),h2(8,payload=b'\0'*4),h2(7,payload=b'\0'*4+(1).to_bytes(4,'big')),
               h2(0,1,1,b'x'),h2(1,5,2,b'x'),h2(1,13,1,b'\xff')]
        for wire in cases:
            w=self.ready()
            with self.subTest(wire=wire),self.assertRaises(ValueError):w.feed('upload',wire)
            self.assertIsNotNone(w.summary()['error'])

    def test_reused_stream_and_state_bound(self):
        w=self.ready();w.feed('upload',h2(1,5,1,b'x'));w.feed('download',h2(1,5,1,b'y'))
        with self.assertRaises(ValueError):w.feed('upload',h2(1,5,1,b'x'))
        w=self.ready()
        for index in range(m.MAX_H2_STREAMS):w.feed('upload',h2(1,5,index*2+1,b'x'))
        with self.assertRaises(ValueError):w.feed('upload',h2(1,5,m.MAX_H2_STREAMS*2+1,b'x'))

    def test_retirement_rejects_new_stream_even_if_it_would_close_in_same_read(self):
        w=self.ready();front=w.begin_retirement()
        self.assertEqual(front['last_stream_id'],0)
        with self.assertRaises(ValueError):w.feed('upload',h2(1,5,1,b'x')+h2(3,0,1,(8).to_bytes(4,'big')))
        self.assertIsNotNone(w.summary()['error'])

    def test_retirement_cancel_fragmentation_and_original_frontier(self):
        for width in (1,3,13):
            w=self.ready();w.feed('upload',h2(1,5,1,b'x'))
            front=w.begin_retirement()
            wire=h2(3,0,1,(8).to_bytes(4,'big'))
            for offset in range(0,len(wire),width):w.feed('download',wire[offset:offset+width])
            self.assertEqual(front['active_stream_ids'],[1]);self.assertEqual(front['reset_records'],[])
            self.assertEqual(w.summary()['last_stream_id'],1)
            self.assertTrue(w.summary()['frames_complete']);self.assertEqual(w.summary()['open_streams'],0)
            with self.assertRaises(ValueError):w.begin_retirement()

    def test_rejection_distinguishes_higher_id_from_original_reset_reuse(self):
        for stream,member in ((15,False),(13,True)):
            for width in (1,8,9,13,100):
                with self.subTest(stream=stream,width=width):
                    w=self.ready();w.feed('upload',h2(1,4,13,b'initial'))
                    frontier=w.begin_retirement()
                    cancel=h2(3,0,13,(8).to_bytes(4,'big'))
                    rejected=h2(1,5,stream,b'opaque-header-value')
                    wire=cancel+rejected+h2(1,5,17,b'not-parsed')
                    with self.assertRaisesRegex(ValueError,'^HTTP/2 new stream after retirement$'):
                        for offset in range(0,len(wire),width):w.feed('upload',wire[offset:offset+width])
                    self.assertEqual(w.summary()['first_rejection'],{
                        'schema':'campaign002-h2-rejection-1','direction':'upload',
                        'frame_type':1,'flags':5,'stream_id':stream,
                        'payload_length':len(b'opaque-header-value'),
                        'active_at_rejection':False,'in_original_frontier':member,
                        'original_last_stream_id':13})
                    self.assertEqual(w.summary()['active_stream_ids'],[])
                    self.assertEqual(w.summary()['last_stream_id'],13)
                    self.assertEqual(w.summary()['reset_records'],[
                        {'direction':'upload','stream_id':13,'error_code':8}])
                    self.assertNotIn('first_rejection',frontier)

    def test_first_rejection_is_bounded_detached_and_payload_free(self):
        w=self.ready();w.feed('upload',h2(1,4,1,b'initial'));w.begin_retirement()
        secret=b'private-header-value-'*700
        with self.assertRaisesRegex(ValueError,'^HTTP/2 new stream after retirement$'):
            w.feed('upload',h2(1,5,3,secret))
        snapshot=w.summary();first=dict(snapshot['first_rejection'])
        retained=m.canonical(first)
        self.assertLess(len(retained),384)
        self.assertNotIn(b'private-header-value',retained)
        self.assertTrue(all(type(v) in (str,int,bool) for v in first.values()))
        before=(w.summary()['bytes'],w.summary()['frames'])
        snapshot['first_rejection']['stream_id']=999
        for _ in range(20):
            with self.assertRaisesRegex(ValueError,'^HTTP/2 new stream after retirement$'):
                w.feed('upload',h2(1,5,5,b'different'))
        self.assertEqual(w.summary()['first_rejection'],first)
        self.assertEqual((w.summary()['bytes'],w.summary()['frames']),before)

    def test_rejection_metadata_absent_for_success_and_other_failures(self):
        w=self.ready();w.feed('upload',h2(1,5,1,b'x'));w.feed('download',h2(1,5,1,b'y'))
        self.assertNotIn('first_rejection',w.idle_eof())
        w.begin_retirement();w.feed('upload',h2(7,payload=b'\0'*8))
        self.assertNotIn('first_rejection',w.idle_eof())
        other=self.ready()
        with self.assertRaisesRegex(ValueError,'^HTTP/2 DATA on unavailable stream$'):
            other.feed('upload',h2(0,1,1,b'opaque'))
        self.assertNotIn('first_rejection',other.summary())

    def test_retirement_does_not_excuse_earlier_or_other_reset(self):
        w=self.ready();w.feed('upload',h2(1,5,1,b'x'));w.feed('download',h2(3,0,1,(8).to_bytes(4,'big')))
        with self.assertRaises(ValueError):w.begin_retirement()
        w=self.ready();w.feed('upload',h2(1,5,1,b'x'));w.begin_retirement()
        with self.assertRaises(ValueError):w.feed('download',h2(3,0,1,(2).to_bytes(4,'big')))

    def test_fragmented_reset_started_before_retirement_is_not_reclassified(self):
        wire=h2(3,0,1,(8).to_bytes(4,'big'))
        for split in (1,8,9,11):
            w=self.ready();w.feed('upload',h2(1,5,1,b'x'))
            w.feed('download',wire[:split]);front=w.begin_retirement()
            self.assertFalse(front['frames_complete'])
            with self.assertRaises(ValueError):w.feed('download',wire[split:])
            self.assertEqual(w.summary()['reset_records'],[])

    def test_drain_controls_are_empty_owner_frames(self):
        for kind in (m.DRAIN_BEGIN,m.DRAIN_ACK):
            p=m.FrameParser();self.assertEqual(p.feed(m.encode_frame(kind,0)),[(kind,0,b'')]);p.finish()
            for channel,payload in ((1,b''),(0,b'x')):
                with self.assertRaises(ValueError):m.encode_frame(kind,channel,payload)

    def test_upload_eof_allows_partial_download_until_final_closure(self):
        w=self.ready();w.feed('upload',h2(1,5,1,b'x'));w.begin_retirement()
        response=h2(1,5,1,b'y');w.feed('download',response[:4])
        seal=w.upload_eof()
        self.assertTrue(seal['upload_complete']);self.assertFalse(seal['frames_complete'])
        self.assertEqual(seal['frame_complete'],{'upload':True,'download':False})
        with self.assertRaises(ValueError):w.idle_eof()
        w.feed('download',response[4:]);self.assertTrue(w.idle_eof()['frames_complete'])

    def test_upload_eof_rejects_partial_upload_even_if_download_is_complete(self):
        w=self.ready();w.feed('upload',h2(1,5,1,b'x')[:4]);w.begin_retirement()
        self.assertFalse(w.summary()['upload_complete'])
        with self.assertRaises(ValueError):w.upload_eof()


if __name__ == '__main__':unittest.main()
