"""Separate agent note bound and reserved framework terminal-note capacity."""
import hashlib
from instrumented_journal import InstrumentedJournal
from supervisor import require,atomic_bytes

class Journal(InstrumentedJournal):
    def _note(self,content,limit):
        require(isinstance(content,str),'invalid_note','UTF-8 note required',400)
        raw=content.encode();require(len(raw)<=limit,'invalid_note','Note bound exceeded',413)
        path=self.workspace/'Continuity.md';require(not path.is_symlink(),'invalid_note','Host mirror must be regular',400)
        previous=path.read_bytes() if path.exists() else b''
        require(len(previous)<=65536,'invalid_note','Existing note exceeds reserved capacity',413)
        require(self.bytes+len(previous)+len(raw)<self.limit-2*1024**2,'storage_limit','Evidence budget reached',507)
        for value in (previous,raw):
            dest=self.root/'continuity-history'/(hashlib.sha256(value).hexdigest()+'.md')
            if not dest.exists():atomic_bytes(dest,value);self.bytes+=len(value)
        atomic_bytes(path,raw)
        return {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'previous_sha256':hashlib.sha256(previous).hexdigest()}
    def continuity(self,content):return self._note(content,32768)
    def framework_continuity(self,content):return self._note(content,65536)
    def read_continuity(self):
        path=self.workspace/'Continuity.md';require(not path.is_symlink(),'invalid_note','Host mirror must be regular',400)
        raw=path.read_bytes() if path.exists() else b''
        require(len(raw)<=65536,'invalid_note','Note exceeds reserved capacity',413)
        return {'ok':True,'content':raw.decode(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
