"""One declared long-host diagnostic: no model and no recovery commands."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
CAMPAIGN = HERE.parent
RCI = CAMPAIGN.parent
REPO = RCI.parents[1]


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def prepare(args):
    spec = importlib.util.spec_from_file_location('probe_challenges', RCI / 'host/challenges.py')
    challenges = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(challenges)
    value = challenges.make_manifest('blocked-insert-home', 'serve', args.run_id)
    value.update(framework_revision=args.revision, noise_seed=24201, sim_cap_s=args.sim_cap_s,
                 wall_cap_s=300 if args.sim_cap_s == 240 else 840, storage_cap_bytes=536870912, model_turns_max=0,
                 qualification_stage='campaign002-host-probe-qualification',
                 diagnostic_purpose=args.purpose,
                 runtime_workspace=str(Path(os.environ['LOCALAPPDATA']) / 'RobotCodex/Campaign002/qualification' / args.run_id))
    sources = (list((CAMPAIGN / 'harness').glob('*.py'))
               + list((CAMPAIGN / 'assessment').glob('*.py'))
               + list((RCI / 'readiness-session-10/assessment').glob('*.py'))
               + [Path(__file__), HERE / 'assess_host_probe.py'])
    value['runtime_input_files'] = [path.relative_to(REPO).as_posix() for path in sorted(sources)]
    value['scope'] = (f'Fixed {args.sim_cap_s} simulation-second idle serve-mode diagnostic: {args.purpose}. '
                      'No model, operator recovery, task score or substitution for final qualification.')
    challenges.validate_manifest(value)
    save(args.manifest, value)
    print(json.dumps({'run_id': args.run_id, 'model_calls': 0, 'sim_cap_s': args.sim_cap_s}))


def run(args):
    manifest = json.loads(args.manifest.read_text(encoding='utf-8'))
    if (manifest.get('qualification_stage') != 'campaign002-host-probe-qualification'
            or manifest.get('model_turns_max') != 0 or manifest.get('mode') != 'serve'
            or (manifest.get('sim_cap_s'), manifest.get('wall_cap_s')) not in ((240, 300), (720, 840))):
        raise ValueError('Only the declared bounded no-model diagnostic is allowed')
    workspace = Path(manifest['runtime_workspace'])
    if workspace.exists():
        raise ValueError('Existing diagnostic workspace; never resubmit')
    free_before = shutil.disk_usage(REPO).free
    if free_before < 102_000_000_000:
        raise RuntimeError('Free reserve threatened')
    args.output.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, '-X', 'utf8', '-B', str(CAMPAIGN / 'harness/run_host.py'),
               '--manifest', str(args.manifest.resolve()), '--evidence', str(args.output / 'host'),
               '--runtime-workspace', str(workspace)]
    start = time.time()
    with (args.output / 'stdout.txt').open('x', encoding='utf-8') as out, (args.output / 'stderr.txt').open('x', encoding='utf-8') as err:
        result = subprocess.run(command, cwd=REPO, stdout=out, stderr=err, timeout=manifest['wall_cap_s'] + 60,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    save(args.output / 'execution.json', {'schema': 'campaign002-host-probe-execution-1',
         'run_id': manifest['run_id'], 'argv': command, 'exit_code': result.returncode,
         'started_unix_s': start, 'ended_unix_s': time.time(), 'model_calls': 0,
         'manifest_sha256': hashlib.sha256(args.manifest.read_bytes()).hexdigest(),
         'free_before': free_before, 'free_after': shutil.disk_usage(REPO).free})
    print(json.dumps({'run_id': manifest['run_id'], 'host_exit_code': result.returncode, 'model_calls': 0}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    p = sub.add_parser('prepare')
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--run-id', required=True)
    p.add_argument('--revision', required=True)
    p.add_argument('--sim-cap-s', type=int, choices=(240, 720), default=720)
    p.add_argument('--purpose', choices=('long-host-timing', 'garbage-collection-correlation'), default='long-host-timing')
    p = sub.add_parser('run')
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    (prepare if args.action == 'prepare' else run)(args)
