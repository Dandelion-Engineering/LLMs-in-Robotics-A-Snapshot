"""Synthetic initial-state/restart-policy fixtures; no physical runs or seeds released."""
import copy
import unittest
import xml.etree.ElementTree as ET

from initial_conditions import RestartOpportunity,validate_initial_snapshot
from test_evaluator import obj,zone,move
from cell import ZONES,zone_half,build_scene


def initial(n=3,raw_x=.32):
    objects=[]
    for index in range(n):
        family='A' if index%2==0 else 'B';row,col=divmod(index,3)
        item=obj(f'{family}{index+1}',raw_x+.085*col,-.31+.074*row,family=family)
        item.update(recipe=None,cycles=0,inspection=None,cycle_history=[],inspection_history=[])
        objects.append(item)
    objects.extend([obj('insert_A',*ZONES['fixture'],kind='insert'),obj('insert_B',*ZONES['insert_home_B'],family='B',kind='insert')])
    return {'objects':objects,'zones':{name:zone(*xy,*zone_half(name)) for name,xy in ZONES.items()},
            'station':{'busy':False,'ready':True,'fault':False,'guard_closed':False,'clamped':False},
            'pending':{k:False for k in ('active_request','queued_motion','active_segment','machine_cycle','inspection')},
            'arm_velocity':[0.]*7,'finger_velocity':[0.,0.]}


class InitialTests(unittest.TestCase):
    def test_all_three_nominal_stock_shapes_pass_necessary_conditions(self):
        # The raw grid remains .32m; parking2 moved to .20m. These are synthetic
        # necessary-condition checks, not contact/reachability calibration.
        for n in (3,6,10):
            report=validate_initial_snapshot(initial(n),n)
            self.assertTrue(report['valid'],report)
            self.assertIn('complete trajectory feasibility',report['not_asserted'])

    def test_former_ten_part_raw_column_overlaps_single_capacity_parking(self):
        snapshot=initial(10)
        snapshot['zones']['parking2']=zone(.27,-.09,.053,.053)
        report=validate_initial_snapshot(snapshot,10)
        self.assertFalse(report['valid'])
        self.assertEqual(report['initial_parking_occupancy']['parking2'],['A7','B10'])

    def test_generated_ten_part_layouts_preserve_raw_grid_and_empty_parking(self):
        for seed in range(8):
            xml,registry=build_scene(10,seed);tree=ET.fromstring(xml)
            snapshot=initial(10)
            for item in snapshot['objects']:
                body=tree.find(".//body[@name='"+item['id']+"']")
                move(item,list(map(float,body.get('pos').split())),registry[item['id']]['half'])
            report=validate_initial_snapshot(snapshot,10)
            self.assertTrue(report['valid'],report)
            self.assertEqual(report['initial_parking_occupancy'],{'parking1':[],'parking2':[]})
        self.assertEqual(ZONES['parking2'],(.20,-.09))

    def test_wrong_stock_reserved_occupancy_or_prior_history_is_rejected(self):
        for change in (lambda s:s['objects'].pop(0),
                       lambda s:move(s['objects'][0],[.4,.33,.02]),
                       lambda s:s['objects'][0].update(cycles=1),
                       lambda s:s['objects'][0].update(gripper_contact=True),
                       lambda s:s['station'].update(busy=True),
                       lambda s:s['pending'].update(active_request=True)):
            snapshot=initial();change(snapshot)
            self.assertFalse(validate_initial_snapshot(snapshot,3)['valid'])

    def test_unsettled_robot_and_wrong_insert_home_fail(self):
        snapshot=initial();snapshot['arm_velocity'][0]=.03
        self.assertFalse(validate_initial_snapshot(snapshot,3)['valid'])
        snapshot=initial();move(snapshot['objects'][-1],[.65,-.29,.008])
        self.assertFalse(validate_initial_snapshot(snapshot,3)['valid'])

    def test_same_supplied_seed_selects_same_rules_without_public_seed_field(self):
        first=RestartOpportunity(17);second=RestartOpportunity(17)
        self.assertEqual(first.configuration(),second.configuration())
        self.assertNotIn('world_seed',first.configuration())
        cuts={RestartOpportunity(i).configuration()['cut'] for i in range(40)}
        self.assertEqual(cuts,set(RestartOpportunity.PHASES))

    def test_every_selected_cut_has_deterministic_reachable_synthetic_trigger(self):
        found={}
        for seed in range(100):
            tracker=RestartOpportunity(seed);config=tracker.configuration()
            if config['cut'] in found:continue
            phase,width={'after_acceptance':(None,.08),'closed_grip_transfer':(5,.042),
                         'after_release':(7,.08),'before_outcome':(9,.08)}[config['cut']]
            for ordinal in range(1,config['transport_ordinal']+1):
                result=tracker.observe(ordinal,{'operation':'transport','request_id':str(ordinal)},
                                       {'phase':phase} if phase is not None else None,width=width)
            self.assertTrue(result['configured_milestone_exercised'])
            self.assertFalse(result['fallback_used'])
            self.assertIsNone(tracker.observe(5.,None,None,width=.08))
            found[config['cut']]=True
        self.assertEqual(set(found),set(RestartOpportunity.PHASES))

    def test_fallback_resolves_an_unexercised_milestone_without_claiming_recovery(self):
        tracker=RestartOpportunity(5)
        self.assertIsNone(tracker.observe(59.,None,None,width=.08))
        event=tracker.observe(60.,None,None,width=.08)
        self.assertTrue(event['fallback_used'])
        self.assertFalse(event['configured_milestone_exercised'])
        self.assertNotIn('recovered',event)

    def test_disabled_counterpart_never_restarts_and_clock_cannot_reset(self):
        self.assertIsNone(RestartOpportunity(5,enabled=False).observe(100.,None,None,width=.08))
        tracker=RestartOpportunity(5);tracker.observe(10.,None,None,width=.08)
        with self.assertRaises(ValueError):tracker.observe(9.,None,None,width=.08)


if __name__=='__main__':unittest.main(verbosity=2)
