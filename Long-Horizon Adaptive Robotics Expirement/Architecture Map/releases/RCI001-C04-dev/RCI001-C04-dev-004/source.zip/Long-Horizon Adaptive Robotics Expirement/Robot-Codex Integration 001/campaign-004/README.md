# Campaign 004

Prospective implementation is in progress. No Campaign 004 model has run and no experimental allocation is frozen. Read [CONTRACT.md](CONTRACT.md) for the authorized experiment. Campaigns 001–003 remain immutable.

The immediate work is six-face rendered identity, bounded fresh-session continuation in the same occurrence, deterministic qualification and independent readback. Compact exact-source declarations and every attempted qualification will be retained in the Architecture Map before execution.
