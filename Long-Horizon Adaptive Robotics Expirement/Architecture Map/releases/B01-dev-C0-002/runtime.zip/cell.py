"""Physical Panda workcell. Candidate observations are estimated from RGB/depth.

The supervisor/evaluator owns this module. Never import it into a candidate.
No transport modifies object qpos or welds objects to the gripper.
"""
from __future__ import annotations
import colorsys
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import mujoco
import numpy as np

HERE = Path(__file__).resolve().parent
ZONES = {'fixture':(.57,0), 'inspection':(.34,.20),
         'parking1':(.27,.05), 'parking2':(.27,-.09),
         'tray1':(.40,.33), 'tray2':(.61,.33), 'tray3':(.65,-.29),
         'quarantine':(.20,.29), 'insert_home_A':(.18,-.25), 'insert_home_B':(.18,-.34)}
PART_HALF = np.array([.021,.021,.018])
HOME = np.array([0,-.5,0,-2.2,0,1.7,.7854])
DT = .002

def zone_half(name): return np.array([.092,.065]) if name.startswith('tray') else np.array([.053,.053])

def _sub(parent,tag,**attrs):
    return ET.SubElement(parent,tag,{k:str(v) for k,v in attrs.items()})

def build_scene(n=3, seed=0):
    """Generated geometry; Menagerie Panda rigid body/actuators preserved."""
    source = HERE/'vendor'/'panda'/'panda.xml'
    root = ET.parse(source).getroot()
    root.find('compiler').set('meshdir',str(source.parent/'assets'))
    root.find('option').set('timestep',str(DT))
    root.find('option').set('iterations','80')
    root.find('option').set('cone','elliptic')
    for key in root.findall('keyframe'):
        root.remove(key)
    visual = _sub(root,'visual')
    _sub(visual,'global',offwidth=640,offheight=480)
    _sub(visual,'headlight',ambient='.65 .65 .65',diffuse='.45 .45 .45',specular='0 0 0')
    world = root.find('worldbody')
    _sub(world,'geom',name='table',type='plane',size='1 1 .1',rgba='.24 .27 .30 1',friction='1 .01 .001')
    _sub(world,'camera',name='overhead',pos='.43 0 1.25',xyaxes='1 0 0 0 1 0',fovy='48')
    _sub(world,'camera',name='oblique',pos='1.05 -.85 .95',xyaxes='.80 .60 0 -.36 .48 .80',fovy='48')
    hand = root.find(".//body[@name='hand']")
    _sub(hand,'site',name='tcp',pos='0 0 .1034',size='.004',rgba='1 0 0 1')
    _sub(hand,'camera',name='wrist',pos='.06 0 .05',xyaxes='1 0 0 0 -1 0',fovy='70')
    # Pad friction is an explicit common calibration parameter, never a weld.
    for geom in root.findall('.//geom'):
        if geom.get('class','').startswith('fingertip_pad'):
            geom.set('friction','1.5 .02 .001')
    for name,(x,y) in ZONES.items():
        half=zone_half(name)
        _sub(world,'geom',name='zone_'+name,type='box',pos=f'{x} {y} -.001',size=f'{half[0]} {half[1]} .001',rgba='.36 .39 .41 1',contype='0',conaffinity='0')
        if name == 'fixture':
            for dx,dy,sx,sy in ((.049,0,.004,.053),(-.049,0,.004,.053),(0,.049,.053,.004),(0,-.049,.053,.004)):
                _sub(world,'geom',name=f'fixture_wall_{dx}_{dy}',type='box',pos=f'{x+dx} {y+dy} .006',size=f'{sx} {sy} .006',rgba='.5 .5 .5 1')
    asset = root.find('asset')
    rng = np.random.default_rng(seed)
    registry = {}
    # Public identification palette; only rendered pixels establish presence.
    names = [f'{"A" if i%2==0 else "B"}{i+1}' for i in range(n)] + ['insert_A','insert_B']
    for i,name in enumerate(names):
        hue = (i+.25)/len(names)
        # Keep saturated pigments below clipping under the calibrated lights.
        color = colorsys.hsv_to_rgb(hue,.95,.35)
        rgb = ' '.join(str(v) for v in color)
        _sub(asset,'material',name='tagmat_'+name,rgba=rgb+' 1',emission='.7',specular='0',shininess='0')
        if name.startswith('insert'):
            x,y = ZONES['fixture'] if name=='insert_A' else ZONES['insert_home_B']
            half = [.025,.025,.008]
            z = .009
        else:
            row,col = divmod(i,3)
            x,y = .32 + .085*col, -.31 + .074*row
            x,y = x+rng.uniform(-.003,.003),y+rng.uniform(-.003,.003)
            half = PART_HALF
            z = .021
        body = _sub(world,'body',name=name,pos=f'{x} {y} {z}')
        _sub(body,'freejoint',name='free_'+name)
        size = ' '.join(map(str,half))
        _sub(body,'geom',name='part_'+name,type='box',size=size,mass='.1',rgba='.60 .61 .62 1',friction='1.2 .015 .001',condim='4')
        _sub(body,'geom',name='tag_'+name,type='box',size='.014 .014 .0003',pos=f'0 0 {half[2]+.0004}',material='tagmat_'+name,contype='0',conaffinity='0',mass='.0001')
        # Binary process mark: dark raw, white after a valid machine cycle.
        _sub(body,'geom',name='mark_'+name,type='box',size='.004 .014 .0003',pos=f'.018 0 {half[2]+.0004}',rgba='.03 .03 .03 1',contype='0',conaffinity='0',mass='.0001')
        registry[name]={'family':name[-1] if name.startswith('insert') else name[0], 'hue':hue,'half':list(map(float,half)),'kind':'insert' if name.startswith('insert') else 'part'}
    return ET.tostring(root,encoding='unicode'),registry

class Cell:
    def __init__(self,n=3,seed=0):
        self.xml,self.registry=build_scene(n,seed)
        self.model=mujoco.MjModel.from_xml_string(self.xml)
        self.data=mujoco.MjData(self.model)
        self.ikdata=mujoco.MjData(self.model)
        self.data.qpos[:7]=HOME
        self.data.qpos[7:9]=.04
        self.data.ctrl[:7]=HOME
        self.data.ctrl[7]=255
        mujoco.mj_forward(self.model,self.data)
        self.renderer=mujoco.Renderer(self.model,480,640)
        self.tcp=mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_SITE,'tcp')
        self.jacp=np.zeros((3,self.model.nv)); self.jacr=self.jacp.copy()
        self.part_ids=[k for k,v in self.registry.items() if v['kind']=='part']
        self.truth={name:{'recipe':None,'cycles':0,'inspection':None} for name in self.part_ids}
        self.station={'busy':False,'ready':True,'fault':False,'cycle_id':0,'completed_cycle_id':None,'fixture_insert':'A','guard_closed':False,'clamped':False}
        self.cycle=None
        self.inspection=None
        self.inspection_due=None
        self.last_detections=[]
        self.last_rgb=None
        self.last_depth=None
        self.detection_time=0.
        self.motion=[]
        self.segment=None
        self.active_request=None
        self.lease_deadline=None
        self.feedback=[]
        self.events=[]
        self.contact_peak=0.
        self.collision_impulse=0.
        self.total_path=0.
        self.last_tcp=self.data.site_xpos[self.tcp].copy()

    def close(self): self.renderer.close()

    def actual_pos(self,name):
        return self.data.xpos[mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_BODY,name)].copy()

    def _physical_zone(self,name,zone,tolerance=.039):
        pos=self.actual_pos(name)
        half=np.array(self.registry[name]['half'])
        body=mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_BODY,name)
        bounds=np.abs(self.data.xmat[body].reshape(3,3))@half
        xy=np.array(ZONES[zone])
        return bool(np.all(np.abs(pos[:2]-xy)+bounds[:2]<zone_half(zone)) and pos[2]<.07 and np.linalg.norm(self.data.cvel[body,3:])<.05)

    def truth_snapshot(self):
        return {'sim_time':float(self.data.time),'objects':{n:{'pos':self.actual_pos(n).tolist(),**self.truth.get(n,{})} for n in self.registry},'station':dict(self.station),'qpos':self.data.qpos.tolist(),'qvel':self.data.qvel.tolist(),'ctrl':self.data.ctrl.tolist()}

    def render(self,camera='overhead'):
        self.renderer.disable_depth_rendering()
        self.renderer.update_scene(self.data,camera=camera)
        rgb=self.renderer.render().copy()
        self.renderer.enable_depth_rendering()
        depth=self.renderer.render().copy()
        self.renderer.disable_depth_rendering()
        return rgb,depth

    def sense(self):
        rgb,depth=self.render()
        pix=rgb.astype(float)/255
        maximum=pix.max(2); minimum=pix.min(2); delta=maximum-minimum
        hue=np.zeros_like(maximum)
        valid=delta>.08
        red=valid & (pix[:,:,0]==maximum)
        green=valid & (pix[:,:,1]==maximum)
        blue=valid & (pix[:,:,2]==maximum)
        hue[red]=((pix[:,:,1][red]-pix[:,:,2][red])/delta[red])%6
        hue[green]=(pix[:,:,2][green]-pix[:,:,0][green])/delta[green]+2
        hue[blue]=(pix[:,:,0][blue]-pix[:,:,1][blue])/delta[blue]+4
        hue/=6
        sat=delta/np.maximum(maximum,1e-9)
        camera=self.model.camera('overhead').id
        rotation=self.data.cam_xmat[camera].reshape(3,3)
        camera_pos=self.data.cam_xpos[camera]
        focal=480/(2*np.tan(np.deg2rad(self.model.cam_fovy[camera])/2))
        detections=[]
        for name,tag in self.registry.items():
            diff=np.abs(hue-tag['hue']); diff=np.minimum(diff,1-diff)
            mask=(diff<.024)&(sat>.55)&(maximum>.4)
            yy,xx=np.where(mask)
            if len(xx)<12: continue
            # Visible tag centroid; do not infer hidden corners from simulator state.
            u,v=float(np.median(xx)),float(np.median(yy))
            z=float(np.median(depth[yy,xx]))
            local=np.array([(u-319.5)*z/focal,-(v-239.5)*z/focal,-z])
            surface=camera_pos+rotation@local
            center=surface-np.array([0,0,tag['half'][2]+.0007])
            zone='raw'
            for key,xy in ZONES.items():
                if np.all(np.abs(center[:2]-xy)<zone_half(key)): zone=key; break
            # Sample known mark location in image coordinates (objects placed yaw 0).
            mu=int(round(u+.018*focal/z)); mv=int(round(v))
            crop=pix[max(0,mv-3):min(480,mv+4),max(0,mu-2):min(640,mu+3)]
            white=float(np.mean(crop)) if crop.size else 0
            mark='processed' if white>.72 else 'raw'
            detections.append({'id':name,'family':tag['family'],'pos':center.tolist(),'zone':zone,'visible_mark':mark,'age_s':0.,'pixels':len(xx),'uncertainty_m':.004,'kind':tag['kind']})
        self.last_detections=detections; self.last_rgb=rgb; self.last_depth=depth
        self.detection_time=float(self.data.time)
        return detections,rgb,depth

    def public_packet(self,order,run_id,incarnation,sequence):
        detections=[{**d,'age_s':float(self.data.time)-self.detection_time} for d in self.last_detections]
        fixture=next((d['id'] for d in detections if d['zone']=='fixture' and d['kind']=='part'),None)
        insert=next((d['family'] for d in detections if d['zone']=='fixture' and d['kind']=='insert'),None)
        station={**self.station,'occupied_visible_id':fixture,'fixture_insert':insert}
        # Public installed insert comes from observed tag; no private inventory.
        tcp=self.data.site_xpos[self.tcp]
        holding=next((d['id'] for d in detections if np.linalg.norm(np.array(d['pos'])-tcp)<.055 and d['pos'][2]>.075),None)
        recent=self.feedback[-1] if self.feedback and self.data.time-self.feedback[-1]['sim_time']<=60. else None
        return {'run_id':run_id,'incarnation':incarnation,'sequence':sequence,'sim_time':float(self.data.time),'order':order,'process_contract':{'family_recipes':{'A':'A','B':'B'},'processed_mark_requires_eligible_cycle':True},'detections':detections,'station':station,'gripper':{'holding_visible_id':holding,'width':float(sum(self.data.qpos[7:9]))},'inspection':self.inspection,'joints':self.data.qpos[:7].tolist(),'last_feedback':recent}

    def ik(self,xyz,initial=None):
        d=self.ikdata
        d.qpos[:]=self.data.qpos
        d.qpos[:7]=self.data.qpos[:7] if initial is None else initial
        target_rotation=np.diag([1.,-1.,-1.])
        for _ in range(120):
            mujoco.mj_forward(self.model,d)
            current=d.site_xmat[self.tcp].reshape(3,3)
            # Spatial orientation error, sum of basis cross products.
            rot_error=.5*sum((np.cross(current[:,i],target_rotation[:,i]) for i in range(3)),start=np.zeros(3))
            pos_error=np.array(xyz)-d.site_xpos[self.tcp]
            if np.linalg.norm(pos_error)<.001 and np.linalg.norm(rot_error)<.01: return d.qpos[:7].copy()
            mujoco.mj_jacSite(self.model,d,self.jacp,self.jacr,self.tcp)
            jac=np.vstack((self.jacp[:,:7],self.jacr[:,:7]*.4))
            error=np.r_[pos_error,rot_error*.4]
            dq=jac.T@np.linalg.solve(jac@jac.T+np.eye(6)*.002,error)
            d.qpos[:7]+=np.clip(dq,-.15,.15)
            ranges=self.model.jnt_range[:7]
            d.qpos[:7]=np.clip(d.qpos[:7],ranges[:,0]+.015,ranges[:,1]-.015)
        raise ValueError(f'IK did not converge at {xyz}, error={pos_error}')

    def plan_transport(self,part_id,destination,objective=None):
        observed=next((d for d in self.last_detections if d['id']==part_id),None)
        if observed is None or self.data.time-self.detection_time>.35: raise ValueError('fresh visible part required')
        if destination not in ZONES: raise ValueError('unknown destination')
        if self.station['busy'] and (observed['zone']=='fixture' or destination=='fixture'):raise ValueError('machine guard interlock is closed')
        occupied=[d for d in self.last_detections if d['id']!=part_id and d['zone']==destination and d['kind']=='part']
        if occupied and not destination.startswith('tray'): raise ValueError('destination occupied')
        obj=objective or {}
        clearance=float(obj.get('clearance',.16)); speed=float(obj.get('speed_scale',.8))
        if not np.isfinite(clearance) or not .08<=clearance<=.25 or not .3<=speed<=1: raise ValueError('invalid geometric objective')
        if obj.get('approach','vertical')!='vertical':raise ValueError('unsupported approach constraint')
        avoid=obj.get('avoid_zones',[])
        if not isinstance(avoid,list) or any(z not in ZONES for z in avoid):raise ValueError('unknown avoidance region')
        source=np.array(observed['pos']); source[2]=max(source[2],self.registry[part_id]['half'][2])
        dest=np.r_[ZONES[destination],self.registry[part_id]['half'][2]+.003]
        if destination.startswith('tray'):
            slots=[np.array(ZONES[destination])+[dx,dy] for dy in (-.028,.028) for dx in (-.055,0,.055)]
            free=[p for p in slots if not any(np.linalg.norm(p-np.array(d['pos'][:2]))<.043 for d in occupied)]
            if not free: raise ValueError('delivery tray full')
            dest[:2]=free[0]
        if destination=='fixture' and self.registry[part_id]['kind']=='part': dest[2]+=.017
        above=max(source[2],dest[2])+clearance
        tcp=self.data.site_xpos[self.tcp].copy()
        points=[(np.r_[tcp[:2],max(tcp[2],above)],255),
                (np.r_[source[:2],above],255),(source,255),(source,0),
                (np.r_[source[:2],above],0),(np.r_[dest[:2],above],0),
                (dest,0),(dest,255),(np.r_[dest[:2],above],255),
                (None,255)]  # Return to a calibrated clear-view rest posture.
        q=self.data.qpos[:7].copy(); segments=[]
        for index,(point,grip) in enumerate(points):
            qnext=HOME.copy() if point is None else self.ik(point,q)
            # Check the actual interpolated joint path against requested public
            # exclusion columns. Rejection preserves model authority; a silently
            # ignored geometric instruction would not test this architecture.
            for fraction in np.linspace(0,1,21):
                self.ikdata.qpos[:7]=q+(qnext-q)*fraction
                mujoco.mj_forward(self.model,self.ikdata)
                projected=self.ikdata.site_xpos[self.tcp,:2]
                if any(np.all(np.abs(projected-ZONES[z])<zone_half(z)+.04) for z in avoid):
                    raise ValueError('planned path conflicts with requested avoidance constraint')
            duration=max(.5 if index in (3,7) else .65,float(np.max(np.abs(qnext-q)))/.7)/speed
            segments.append({'q':qnext,'grip':grip,'duration':duration,'phase':index})
            q=qnext
        self.motion=segments
        self.segment=None

    def submit(self,action):
        if self.active_request is not None: return {'status':'rejected','reason':'arm resource busy'}
        op=action['operation']; request_id=action['request_id']
        part=action.get('part_id'); self.active_request=action
        self.lease_deadline=float(self.data.time)+2.
        try:
            if op=='transport':
                self.plan_transport(part,action['destination'],action.get('objective'))
            elif op=='setup':
                if self.station['busy']:raise ValueError('machine guard interlock is closed')
                family=action['family']; insert='insert_'+family
                if any(d['kind']=='part' and d['zone']=='fixture' for d in self.last_detections): raise ValueError('fixture occupied')
                current=next((d for d in self.last_detections if d['kind']=='insert' and d['zone']=='fixture'),None)
                if current and current['id']==insert: self.finish('completed','requested insert already visibly seated')
                elif current:
                    self.plan_transport(current['id'],'insert_home_'+current['family'])
                    self.active_request={**action,'setup_pending':insert}
                else:
                    self.plan_transport(insert,'fixture')
            elif op=='cycle':
                if self.station['busy'] or self.station['fault']: raise ValueError('machine unavailable')
                if part not in self.truth or not self._physical_zone(part,'fixture'): raise ValueError('seating interlock not satisfied')
                family=self.registry[part]['family']
                if not self._physical_zone('insert_'+family,'fixture'): raise ValueError('insert interlock not satisfied')
                if action['recipe']!=family: raise ValueError('recipe incompatible')
                if self.truth[part]['cycles'] and self.truth[part]['inspection']!='rework': raise ValueError('part not eligible for another cycle')
                self.station['cycle_id']+=1; self.station['busy']=True; self.station['ready']=False;self.station['guard_closed']=True;self.station['clamped']=True
                self.cycle={'part_id':part,'recipe':family,'due':float(self.data.time)+8.,'cycle_id':self.station['cycle_id']}
                self.finish('completed','cycle accepted',cycle_id=self.station['cycle_id'])
            elif op=='inspect':
                if part not in self.truth or not self._physical_zone(part,'inspection'): raise ValueError('inspection pad placement required')
                self.inspection_due={'part_id':part,'due':float(self.data.time)+2.,'request_id':request_id}
            elif op in ('observe','wait','done','help'):
                self.finish('completed',op)
            else: raise ValueError('unknown operation')
            return {'status':'accepted','request_id':request_id}
        except (KeyError,ValueError) as e:
            self.active_request=None; self.motion=[]; self.segment=None
            return {'status':'rejected','request_id':request_id,'reason':str(e)}

    def finish(self,status,reason,**extra):
        if self.active_request is None: return
        event={'request_id':self.active_request['request_id'],'status':status,'reason':reason,'sim_time':float(self.data.time),**extra}
        self.feedback.append(event); self.events.append({'type':'feedback',**event})
        self.active_request=None
        self.lease_deadline=None

    def renew_authority(self,order_version,incarnation):
        """Fixed executor renews only the same currently lawful operation."""
        if self.active_request and self.data.time-self.detection_time<=.35 and self.active_request.get('order_version')==order_version and self.active_request.get('incarnation')==incarnation:
            self.lease_deadline=float(self.data.time)+2.
            return True
        return False

    def cancel(self,reason='incarnation revoked'):
        self.motion=[];self.segment=None
        self.data.ctrl[:7]=self.data.qpos[:7]
        self.finish('cancelled',reason)

    def tick(self):
        if self.active_request and self.lease_deadline is not None and self.data.time>=self.lease_deadline:
            self.cancel('bounded command authority expired')
        if self.motion or self.segment:
            if self.segment is None:
                self.segment=self.motion.pop(0)
                self.segment.update(start=float(self.data.time),q0=self.data.ctrl[:7].copy())
            s=self.segment
            u=np.clip((self.data.time-s['start'])/s['duration'],0,1)
            blend=u*u*u*(10+u*(-15+6*u))
            self.data.ctrl[:7]=s['q0']+(s['q']-s['q0'])*blend
            self.data.ctrl[7]=s['grip']
            if u>=1:
                self.segment=None
                if not self.motion:
                    pending=self.active_request.get('setup_pending') if self.active_request else None
                    if pending:
                        self.sense()
                        try:
                            self.plan_transport(pending,'fixture')
                            self.active_request.pop('setup_pending')
                        except ValueError as e:self.finish('failed',str(e))
                    else:self.finish('completed','trajectory ended; physical outcome requires observation')
        mujoco.mj_step(self.model,self.data)
        position=self.data.site_xpos[self.tcp].copy()
        self.total_path+=float(np.linalg.norm(position-self.last_tcp));self.last_tcp=position
        for i in range(self.data.ncon):
            force=np.zeros(6);mujoco.mj_contactForce(self.model,self.data,i,force)
            self.contact_peak=max(self.contact_peak,float(np.linalg.norm(force[:3])))
            self.collision_impulse+=float(np.linalg.norm(force[:3]))*DT
        if self.cycle and self.data.time>=self.cycle['due']:
            c=self.cycle; record=self.truth[c['part_id']]
            record['recipe']=c['recipe'];record['cycles']+=1
            geom=self.model.geom('mark_'+c['part_id']).id
            self.model.geom_rgba[geom]=[1,1,1,1]
            self.station.update(busy=False,ready=True,completed_cycle_id=c['cycle_id'],guard_closed=False,clamped=False)
            self.events.append({'type':'cycle_complete','sim_time':float(self.data.time),'cycle_id':c['cycle_id']})
            self.cycle=None
        if self.inspection_due and self.data.time>=self.inspection_due['due']:
            part=self.inspection_due['part_id']
            status='pass' if self.truth[part]['recipe']==self.registry[part]['family'] and self._physical_zone(part,'inspection') else 'fail'
            self.truth[part]['inspection']=status
            self.inspection={'part_id':part,'status':status,'inspection_id':self.inspection_due['request_id']}
            self.inspection_due=None
            self.finish('completed','inspection returned',inspection=self.inspection)

    def outcome(self,order):
        accepted={r['tray']:[] for r in order['requirements']}
        reasons=[]
        for requirement in order['requirements']:
            for part in self.part_ids:
                state=self.truth[part]
                if self._physical_zone(part,requirement['tray']):
                    if self.registry[part]['family']==requirement['family'] and state['recipe']==requirement['recipe'] and state['inspection']=='pass':accepted[requirement['tray']].append(part)
                    else:reasons.append('invalid part in delivery tray: '+part)
            if len(accepted[requirement['tray']])!=requirement['count']:reasons.append('quantity mismatch '+requirement['tray'])
        if self.station['busy']:reasons.append('machine busy')
        if any(self.actual_pos(p)[2]>.075 for p in self.part_ids):reasons.append('part not resting')
        if any(self._physical_zone(p,'fixture') for p in self.part_ids):reasons.append('fixture contains work')
        if self.active_request:reasons.append('command outstanding')
        if not order['closed']:reasons.append('order stream open')
        return {'success':not reasons,'accepted':accepted,'reasons':reasons,'accepted_count':sum(map(len,accepted.values()))}

def calibration(output):
    """One true contact transport; measured errors decide readiness."""
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    cell=Cell(3,0)
    try:
        for _ in range(250):cell.tick()
        detections,rgb,depth=cell.sense()
        from png import write_png
        write_png(output/'initial.png',rgb)
        measured=[]
        for detection in detections:
            measured.append({'id':detection['id'],'error_m':float(np.linalg.norm(np.array(detection['pos'])-cell.actual_pos(detection['id']))),'observed':detection['pos'],'actual':cell.actual_pos(detection['id']).tolist()})
        response=cell.submit({'operation':'transport','part_id':'A1','destination':'inspection','request_id':'calibration-grasp-1','order_version':1,'incarnation':1})
        trace=[]
        for tick in range(12500):
            if tick%50==0:
                cell.sense();cell.renew_authority(1,1)
            cell.tick()
            if tick%50==0:trace.append({'time':float(cell.data.time),'tcp':cell.data.site_xpos[cell.tcp].tolist(),'part':cell.actual_pos('A1').tolist(),'q':cell.data.qpos[:7].tolist(),'finger':cell.data.qpos[7:9].tolist()})
            if not cell.active_request:break
        for _ in range(250):cell.tick()
        detections,rgb,depth=cell.sense();write_png(output/'final.png',rgb)
        result={'scope':'physical-contact calibration; not an architecture experiment','response':response,'feedback':cell.feedback,'perception':measured,'transport_in_zone':cell._physical_zone('A1','inspection'),'part_final':cell.actual_pos('A1').tolist(),'trace':trace,'contact_peak_N':cell.contact_peak,'xml_sha256':hashlib.sha256(cell.xml.encode()).hexdigest()}
        (output/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({k:v for k,v in result.items() if k!='trace'},indent=2))
        if not result['transport_in_zone']:raise SystemExit(2)
    finally:cell.close()

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--calibrate',required=True)
    calibration(parser.parse_args().calibrate)
