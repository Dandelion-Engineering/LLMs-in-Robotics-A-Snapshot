"""Small supervisor regression checks. No simulator, model or queue job runs."""
from concurrent.futures import Future
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import numpy as np
import experiment
import sandbox


class Clock:
    def __init__(self):self.t=0.
    def now(self):self.t+=.002;return self.t


class DeferredModelFuture:
    """Unready inside the episode, completed when cleanup awaits the result."""
    def __init__(self,error=None):self.error=error
    def done(self):return False
    def result(self,timeout=None):
        if self.error:raise self.error
        return {'text':'{"operation":"wait"}','usage':{'total_tokens':17}}


class ImmediateExecutor:
    def __init__(self,model,deferred):self.model=model;self.deferred=deferred
    def submit(self,function,*args,**kwargs):
        if function==self.model.complete:return self.deferred
        future=Future()
        try:future.set_result(function(*args,**kwargs))
        except BaseException as exc:future.set_exception(exc)
        return future
    def shutdown(self,**kwargs):pass


def fake_cell(clock=None, sense_error=None):
    cell=MagicMock()
    cell.data.time=0.;cell.data.qpos=np.zeros(16);cell.data.qvel=np.zeros(16)
    cell.data.actuator_force=np.zeros(9);cell.data.ctrl=np.zeros(9)
    cell.data.site_xpos=np.zeros((1,3));cell.tcp=0
    cell.total_path=0.;cell.contact_peak=0.;cell.collision_impulse=0.
    cell.events=[];cell.feedback=[];cell.segment=None;cell.active_request=None
    cell.tick.side_effect=lambda:setattr(cell.data,'time',cell.data.time+.002)
    cell.outcome.return_value={'success':False,'accepted_count':0,'accepted':{},'reasons':['fixture unfinished']}
    cell.truth_snapshot.return_value={}
    cell.public_packet.return_value={'sequence':1,'sim_time':.5,'detections':[]}
    def sense():
        if sense_error:raise sense_error
        if clock:clock.t+=.2
        return [],np.zeros((2,2,3),dtype=np.uint8),np.zeros((2,2))
    cell.sense.side_effect=sense
    return cell


class SupervisorTests(unittest.TestCase):
    def test_wall_stall_cannot_disappear_from_lag(self):
        timing=experiment.TimingMonitor()
        timing.observe(.2,0.)
        timing.observe(1.2,1.)
        report=timing.report()
        self.assertGreaterEqual(report['maximum_lag_s'],.199)
        self.assertFalse(report['actual_host_timing_pass'])
        self.assertEqual(report['complete_wall_windows'],1)
        self.assertAlmostEqual(report['timing'][0]['real_time_factor'],.8)

    def test_matching_clocks_pass_complete_windows(self):
        timing=experiment.TimingMonitor()
        for i in range(1,251):timing.observe(i*.01,i*.01)
        report=timing.report()
        self.assertTrue(report['actual_host_timing_pass'])
        self.assertAlmostEqual(report['trailing_partial_window_s'],.5)

    def test_pending_restart_worker_is_closed(self):
        old=MagicMock();fresh=MagicMock();pending=Future();pending.set_result(fresh)
        self.assertEqual(experiment.close_pending_restart(pending,'restart',old),[])
        old.close.assert_called_once();fresh.close.assert_called_once()

    def test_late_restart_after_cleanup_timeout_is_still_closed(self):
        old=MagicMock();fresh=MagicMock();pending=Future()
        errors=experiment.close_pending_restart(pending,'restart',old,timeout=.001)
        self.assertTrue(errors)
        pending.set_result(fresh)
        fresh.close.assert_called_once()

    def test_candidate_input_records_exact_supplied_message(self):
        worker=MagicMock();worker.receive.return_value={'type':'step','response':None}
        evidence=MagicMock();evidence.emit.return_value=8
        message={'type':'step','packet':{'sequence':5,'age_s':.123}}
        reply=experiment.candidate_call(worker,message,evidence,lambda:1.5,[3])
        evidence.emit.assert_called_once_with('candidate_input',{'message':message},1.5,'candidate_gateway',[3])
        worker.send.assert_called_once_with(message)
        self.assertEqual(reply['supervisor_input_event_id'],8)

    def test_initialization_failure_retains_terminal_result(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(experiment,'EVIDENCE',Path(directory)), patch.object(experiment,'Cell',side_effect=RuntimeError('fixture setup failed')), contextlib.redirect_stdout(io.StringIO()):
            result=experiment.run_episode(run_id='startup-failure')
            saved=json.loads((Path(directory)/'startup-failure'/'result.json').read_text())
        self.assertEqual(result,saved)
        self.assertEqual(result['failure_class'],'infrastructure_failure')
        self.assertEqual(result['validity'],'invalid')
        self.assertIsNone(result['wall_duration_s'])
        self.assertIsNone(result['independent_outcome'])

    def test_render_failure_retains_terminal_result(self):
        cell=fake_cell(sense_error=RuntimeError('render failed'));worker=MagicMock()
        with tempfile.TemporaryDirectory() as directory, patch.object(experiment,'EVIDENCE',Path(directory)), patch.object(experiment,'Cell',return_value=cell), patch.object(sandbox,'CandidateSandbox',return_value=worker), contextlib.redirect_stdout(io.StringIO()):
            result=experiment.run_episode(run_id='render-failure',cap=.1)
        self.assertEqual(result['failure_class'],'infrastructure_failure')
        self.assertIn('render failed',result['error'])
        worker.close.assert_called_once();cell.close.assert_called_once()

    def test_sensor_latency_is_in_final_actual_host_timing(self):
        clock=Clock();cell=fake_cell(clock);worker=MagicMock()
        worker.receive.return_value={'type':'step','response':None};worker.alive=True
        with tempfile.TemporaryDirectory() as directory, patch.object(experiment,'EVIDENCE',Path(directory)), patch.object(experiment,'Cell',return_value=cell), patch.object(sandbox,'CandidateSandbox',return_value=worker), patch.object(experiment.time,'perf_counter',side_effect=clock.now), patch.object(experiment,'write_png'), patch.object(experiment.np,'savez_compressed'), contextlib.redirect_stdout(io.StringIO()):
            result=experiment.run_episode(run_id='sensor-stall',cap=.1)
        self.assertGreater(result['maximum_lag_s'],.1)
        self.assertEqual(result['validity'],'invalid')
        cell.renew_authority.assert_called_once_with(1,1)

    def late_model_run(self,error=None):
        clock=Clock();cell=fake_cell();worker=MagicMock();worker.alive=True
        worker.receive.return_value={'type':'step','response':{'type':'model','messages':[{'role':'user','content':'wait'}],'schema':{'type':'object'}}}
        model=MagicMock();model.identity={'test_fixture':True};model.config.request_timeout_s=.01
        executor=ImmediateExecutor(model,DeferredModelFuture(error))
        with tempfile.TemporaryDirectory() as directory, patch.object(experiment,'EVIDENCE',Path(directory)), patch.object(experiment,'Cell',return_value=cell), patch.object(sandbox,'CandidateSandbox',return_value=worker), patch.object(experiment,'ThreadPoolExecutor',return_value=executor), patch.object(experiment.time,'perf_counter',side_effect=clock.now), patch.object(experiment,'write_png'), patch.object(experiment.np,'savez_compressed'), contextlib.redirect_stdout(io.StringIO()):
            result=experiment.run_episode(kind='A1',model=model,run_id='late-model',cap=.15)
            events=[json.loads(line) for line in (Path(directory)/'late-model'/'events.jsonl').read_text().splitlines()]
        return result,events,model

    def test_model_tokens_finishing_after_cap_are_accounted_without_delivery(self):
        result,events,model=self.late_model_run()
        self.assertEqual(result['model_calls'],1)
        self.assertEqual(result['late_model_responses'],1)
        self.assertEqual(result['total_tokens'],17)
        self.assertTrue(result['model_accounting_complete'])
        self.assertTrue(any(e['event_type']=='late_model_response' and e['payload']['after_episode_end'] for e in events))
        self.assertFalse(any(e['event_type']=='candidate_input' and e['payload']['message']['type']=='model_response' for e in events))

    def test_failed_late_model_call_has_missing_token_count(self):
        result,events,model=self.late_model_run(TimeoutError('model timed out'))
        self.assertEqual(result['model_failed_calls'],1)
        self.assertIsNone(result['total_tokens'])
        self.assertEqual(result['unknown_token_calls'],1)
        self.assertFalse(result['model_accounting_complete'])
        model.stop.assert_called_once()


if __name__=='__main__':unittest.main()
