"""Queued experiment supervisor: physics, isolated candidate, model and evidence.

Development entrypoint first. Evaluation is refused without a frozen manifest
and passing shared readiness evidence; a completed program is not task success.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import threading
import time
import uuid
import numpy as np

from cell import Cell,DT,ZONES
from png import write_png

HERE=Path(__file__).resolve().parent
EVIDENCE=HERE.parent/'Evidence'/'raw'

def utc():return datetime.now(timezone.utc).isoformat()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class TimingMonitor:
    """Fresh wall/simulation samples; one-second wall-window rates.

    Boundary simulation time is interpolated between adjacent observed samples.
    The maximum observed gap is retained so sparse samples cannot claim precise
    sub-window timing. Initialization and post-episode cleanup are excluded.
    """
    def __init__(self):
        self.previous=(0.,0.);self.boundary=1.;self.boundary_sim=0.
        self.windows=[];self.maximum_lag=0.;self.maximum_sample_gap=0.
    def observe(self,wall,sim):
        old_wall,old_sim=self.previous
        if wall<old_wall or sim<old_sim:raise ValueError('Clock sample moved backwards')
        self.maximum_lag=max(self.maximum_lag,wall-sim)
        self.maximum_sample_gap=max(self.maximum_sample_gap,wall-old_wall)
        while wall>=self.boundary:
            fraction=(self.boundary-old_wall)/(wall-old_wall) if wall>old_wall else 1.
            boundary_sim=old_sim+(sim-old_sim)*fraction
            rtf=boundary_sim-self.boundary_sim
            self.windows.append({'wall_start_s':self.boundary-1.,'wall_end_s':self.boundary,
                                 'sim_end_s':boundary_sim,'real_time_factor':rtf,
                                 'lag_s':self.boundary-boundary_sim,'within_tolerance':.95<=rtf<=1.05})
            self.boundary_sim=boundary_sim;self.boundary+=1.
        self.previous=(wall,sim)
    def report(self):
        bad=sum(not w['within_tolerance'] for w in self.windows)
        fraction=bad/len(self.windows) if self.windows else None
        return {'maximum_lag_s':self.maximum_lag,'maximum_timing_sample_gap_s':self.maximum_sample_gap,
                'timing':self.windows,'complete_wall_windows':len(self.windows),
                'outside_rtf_tolerance_windows':bad,'outside_rtf_tolerance_fraction':fraction,
                'actual_host_timing_pass':bool(self.windows) and self.maximum_lag<.1 and fraction<.01,
                'timing_boundary_method':'linear interpolation of adjacent fresh wall/sim samples',
                'trailing_partial_window_s':self.previous[0]-len(self.windows)}


class EpisodeFailure(RuntimeError):
    def __init__(self,classification,message):
        super().__init__(message);self.classification=classification


def close_pending_restart(pending,pending_type,current_worker,timeout=45.):
    """A late restart owns a new process even if the episode already ended."""
    errors=[]
    if pending is not None and pending_type=='restart':
        try:
            fresh=pending.result(timeout=timeout)
            if fresh is not current_worker:fresh.close()
        except Exception as exc:
            errors.append('pending restart cleanup: '+str(exc))
            if not pending.done():
                # shutdown(wait=True) below may outlast this bounded wait. The
                # late-created worker must still be closed when it appears.
                def close_late(future):
                    if future.cancelled():return
                    try:
                        fresh=future.result()
                        if fresh is not current_worker:fresh.close()
                    except Exception as late_exc:errors.append('late restart cleanup: '+str(late_exc))
                pending.add_done_callback(close_late)
    if current_worker:
        try:current_worker.close()
        except Exception as exc:errors.append('candidate cleanup: '+str(exc))
    return errors

class Evidence:
    def __init__(self,directory,run_id):
        self.path=Path(directory);self.path.mkdir(parents=True,exist_ok=False)
        (self.path/'frames').mkdir();(self.path/'contexts').mkdir()
        self.events=(self.path/'events.jsonl').open('w',encoding='utf-8',newline='\n')
        self.motion=(self.path/'motion.jsonl').open('w',encoding='utf-8',newline='\n')
        self.run_id=run_id;self.sequence=0;self.start=time.perf_counter()
        self.lock=threading.Lock()
    def emit(self,kind,payload,sim_time,source='supervisor',parents=None):
        with self.lock:
            self.sequence+=1
            event={'schema_version':'robot-evidence-1.0','run_id':self.run_id,'event_id':self.sequence,'event_type':kind,'source':source,'sim_time_s':sim_time,'sim_tick':round(sim_time/DT),'wall_elapsed_s':time.perf_counter()-self.start,'parent_ids':parents or [],'payload_sha256':hashlib.sha256(canonical(payload)).hexdigest(),'payload':payload}
            self.events.write(json.dumps(event,allow_nan=False,separators=(',',':'))+'\n')
            if kind not in ('observation','world_snapshot'):self.events.flush()
            return self.sequence
    def close(self):self.events.close();self.motion.close()

def initial_order(n,amend=False):
    a=(n+1)//2;b=n//2
    req=[{'family':'A','recipe':'A','count':a,'tray':'tray1'}]
    if b:req.append({'family':'B','recipe':'B','count':b,'tray':'tray2'})
    return {'version':1,'closed':not amend,'requirements':req,'text':f'Process and inspect {a} A and {b} B parts. Deliver to the named trays.'}

def candidate_call(worker,message,evidence=None,simulation_time=None,parents=None):
    parent=None
    if evidence is not None:
        parent=evidence.emit('candidate_input',{'message':message},simulation_time(),'candidate_gateway',parents)
    worker.send(message)
    reply=worker.receive(timeout=20.)
    if parent is not None:reply={**reply,'supervisor_input_event_id':parent}
    return reply

def restart_worker(old_worker,old_pending,kind,episode_dir,persistent):
    """Keep physics live during all OS process teardown/startup latency."""
    from sandbox import CandidateSandbox
    old_worker.close()
    if old_pending:
        try:old_pending.result(timeout=2.)
        except Exception:pass
    if not persistent:
        assert episode_dir.resolve().parent.parent==EVIDENCE.resolve()
        shutil.rmtree(episode_dir);episode_dir.mkdir()
    worker=CandidateSandbox(kind,episode_dir,persistent=persistent)
    worker.start()
    return worker

def run_episode(kind='baseline',n=3,seed=0,cap=300.,condition='persistent',scenario='nominal',stage='development',model=None,run_id=None):
    from sandbox import CandidateSandbox
    if stage=='evaluation':raise ValueError('Evaluation requires a separately frozen ready release; development entrypoint cannot score it')
    run_id=run_id or f'dev-{kind}-{datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")}-{uuid.uuid4().hex[:6]}'
    evidence=Evidence(EVIDENCE/run_id,run_id)
    episode_dir=evidence.path/'candidate_state'
    condition_persistent=condition=='persistent'
    cell=None;worker=None;executor=ThreadPoolExecutor(max_workers=3)
    pending=None;pending_type=None;model_pending=None;model_parent=None;model_incarnation=None
    last_observation_event=None;model_delivery_parent=None
    lifecycle={};feedback_cursor=0;cell_event_cursor=0
    last_frame=-1.;last_snapshot=-1.;last_motion=-1.;last_capture_wall=None
    next_decision=0.;done_assertions=0;false_done=0;model_calls=0;tokens=0
    model_responses=0;model_failures=0;unknown_token_calls=0;late_model_responses=0
    incarnation=1;obs_sequence=0;success_since=None;success=False
    restart_exercised=False;amend_exercised=False;restart_pending=False
    order=initial_order(n,scenario in ('order_change','mixed'))
    elapsed=0.;termination='time_cap';error=None;failure_class=None;phase='initialization'
    start=None;base_sim=0.;monitor=TimingMonitor();camera_gaps=[];cleanup_errors=[]
    final=None;started_at=utc();episode_ended_at=None;episode_end_wall=None;sim_at_end=None

    def sim_now():return float(cell.data.time) if cell is not None else 0.

    def dispatch_candidate(message,parents=None):
        frozen_message=json.loads(canonical(message))
        return executor.submit(candidate_call,worker,frozen_message,evidence,sim_now,parents)

    def collect_model(future,*,late=False):
        nonlocal tokens,model_responses,model_failures,unknown_token_calls,late_model_responses,model_delivery_parent
        stale=model_incarnation!=incarnation
        metadata={'original_incarnation':model_incarnation,'current_incarnation':incarnation,
                  'stale':stale,'after_episode_end':late}
        if late:
            metadata['post_episode_wall_s']=time.perf_counter()-episode_end_wall
            metadata['wall_beyond_cap_s']=max(0.,time.perf_counter()-start-cap) if start is not None else None
        try:
            timeout=(getattr(getattr(model,'config',None),'request_timeout_s',30.)+25.) if late else None
            reply=future.result(timeout=timeout)
            count=reply.get('total_tokens',reply.get('usage',{}).get('total_tokens'))
            if count is None:unknown_token_calls+=1
            else:tokens+=int(count)
            model_responses+=1
            if late:late_model_responses+=1
            model_delivery_parent=evidence.emit('late_model_response' if late else 'model_response',{'result':reply,**metadata},sim_now(),'local_model',[model_parent] if model_parent else [])
            if stale:evidence.emit('stale_model_output_discarded',metadata,sim_now())
            return reply.get('text',reply.get('raw_text','')) if not stale and not late else None
        except Exception as exc:
            model_failures+=1;unknown_token_calls+=1
            if late and not future.done() and model is not None:
                try:model.stop()
                except Exception as stop_exc:cleanup_errors.append('model timeout cleanup: '+str(stop_exc))
            evidence.emit('stale_model_error_discarded' if stale else 'model_error',{'error':str(exc),**metadata},sim_now(),'local_model',[model_parent] if model_parent else [])
            # Explicit invalid output consumes the candidate's bounded malformed-
            # output attempt. It cannot silently substitute a control policy.
            return '{}' if not stale and not late else None

    try:
        episode_dir.mkdir()
        manifest={'run_id':run_id,'stage':stage,'architecture':kind,'condition':condition,'scenario':scenario,'seed':seed,'part_count':n,'cap_s':cap,'started_at':started_at,'code_sha256':{p.name:sha(p) for p in HERE.glob('*.py')},'model':model.identity if model else None,'clock_track':'actual_host','scope':'physical-workcell development; readiness not yet established'}
        (evidence.path/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
        phase='cell_initialization';cell=Cell(n,seed)
        phase='candidate_startup';worker=CandidateSandbox(kind,episode_dir,persistent=condition_persistent)
        worker.start()
        phase='physics_initialization'
        for _ in range(250):cell.tick()
        base_sim=sim_now();start=time.perf_counter();evidence.start=start
        evidence.emit('initial_world',cell.truth_snapshot(),sim_now(),'evaluator')
        while True:
            elapsed=time.perf_counter()-start
            if elapsed>=cap:break
            phase='physics';target=base_sim+elapsed;steps=0
            while cell.data.time<target and steps<50:
                cell.tick();steps+=1
                if cell.data.time-last_motion>=.01-1e-9:
                    evidence.motion.write(json.dumps({'sim_time_s':sim_now(),'q':cell.data.qpos[:7].tolist(),'dq':cell.data.qvel[:7].tolist(),'effort':cell.data.actuator_force[:7].tolist(),'target':cell.data.ctrl[:7].tolist(),'tcp':cell.data.site_xpos[cell.tcp].tolist(),'contact_peak_N':cell.contact_peak},separators=(',',':'))+'\n')
                    last_motion=sim_now()
            sim=sim_now()
            if sim-last_frame>=.1-1e-9:
                phase='sensor';capture_wall=time.perf_counter()-start
                detections,rgb,depth=cell.sense();obs_sequence+=1
                if worker.alive and not restart_pending:cell.renew_authority(order['version'],incarnation)
                if last_capture_wall is not None:
                    gap={'sequence':obs_sequence,'wall_gap_s':capture_wall-last_capture_wall,'sim_gap_s':sim-last_frame}
                    gap['missed_nominal_intervals']=max(0,int((gap['wall_gap_s']+1e-6)/.1)-1)
                    camera_gaps.append(gap)
                last_capture_wall=capture_wall
                phase='sensor_evidence';stem=f'{obs_sequence:06d}'
                write_png(evidence.path/'frames'/f'{stem}.png',rgb)
                np.savez_compressed(evidence.path/'frames'/f'{stem}-depth.npz',depth_m=depth)
                packet=cell.public_packet(order,run_id,incarnation,obs_sequence)
                last_observation_event=evidence.emit('observation',{'packet':packet,'rgb':f'frames/{stem}.png','depth':f'frames/{stem}-depth.npz','camera':'overhead','capture_sim_time_s':sim,'capture_wall_elapsed_s':capture_wall},sim,'sensor_gateway')
                last_frame=sim
            phase='supervisor_evidence'
            if sim-last_snapshot>=1.-1e-9:
                evidence.emit('world_snapshot',cell.truth_snapshot(),sim,'evaluator');last_snapshot=sim
            for event in cell.events[cell_event_cursor:]:evidence.emit('physical_service_event',event,sim,'gateway')
            cell_event_cursor=len(cell.events)
            if scenario in ('order_change','mixed') and not amend_exercised and (sim-base_sim>40 or len(cell.feedback)>4):
                order={**order,'version':2,'closed':True,'requirements':[dict(r) for r in order['requirements']]}
                for r in order['requirements']:
                    if r['family']=='B':r['tray']='tray3'
                amend_exercised=True;evidence.emit('order_amendment',order,sim,'public_order_service')
            released=cell.segment is not None and cell.segment['phase']==7 and sum(cell.data.qpos[7:9])>.065
            restart_due=scenario in ('restart','mixed') and not restart_exercised and (released or sim-base_sim>60)
            if restart_due and not restart_pending:
                restart_exercised=True;restart_pending=True
                evidence.emit('restart_begin',{'incarnation':incarnation,'active_request':cell.active_request,'cut':'release' if released else 'deadline_fallback'},sim,'evaluator')
                cell.cancel('runtime incarnation revoked')
                if model_pending is not None:evidence.emit('model_output_invalidated',{'reason':'incarnation ended','original_incarnation':model_incarnation},sim)
                incarnation+=1
                pending=executor.submit(restart_worker,worker,pending,kind,episode_dir,condition_persistent);pending_type='restart'
                feedback_cursor=len(cell.feedback)
            phase='candidate_ipc'
            if pending is not None and pending.done():
                try:reply=pending.result()
                except Exception as exc:
                    evidence.emit('candidate_transport_error',{'phase':pending_type,'error':str(exc)},sim,'candidate_runtime')
                    raise EpisodeFailure('candidate_transport_failure',str(exc)) from exc
                action_response=None
                if pending_type=='restart':
                    worker=reply;restart_pending=False;evidence.emit('restart_ready',{'incarnation':incarnation},sim)
                else:
                    evidence.emit('candidate_reply',reply,sim,'candidate',[reply['supervisor_input_event_id']] if reply.get('supervisor_input_event_id') else [])
                    if isinstance(reply,dict) and reply.get('type')=='error':
                        raise EpisodeFailure('candidate_reported_error',json.dumps(reply))
                    action_response=reply.get('response') if isinstance(reply,dict) else None
                pending=None;pending_type=None
                if action_response:
                    response_type=action_response.get('type')
                    if response_type=='model':
                        if model is None:raise RuntimeError('Candidate requested a model but no local model is running')
                        model_calls+=1;model_parent=evidence.emit('model_request',action_response,sim,'candidate');model_incarnation=incarnation
                        model_pending=executor.submit(model.complete,action_response['messages'],action_response['schema'],max_tokens=1024,seed=seed)
                    elif response_type=='action':
                        action=dict(action_response['action']);action.setdefault('incarnation',incarnation);action.setdefault('request_id',uuid.uuid4().hex)
                        request_event=evidence.emit('action_requested',action,sim,'candidate');rid=action['request_id'];previous=lifecycle.get(rid)
                        if previous and sim-previous['time']<=60:feedback={**previous['feedback'],'duplicate_suppressed':True}
                        elif action.get('order_version')!=order['version'] and action.get('operation') not in ('observe','wait','help'):
                            feedback={'request_id':rid,'status':'rejected','reason':'stale order version'}
                        elif action.get('incarnation')!=incarnation:feedback={'request_id':rid,'status':'rejected','reason':'old incarnation'}
                        else:
                            if action['operation']=='done':
                                done_assertions+=1;checked=cell.outcome(order)
                                if not checked['success']:false_done+=1
                                evidence.emit('completion_claim_check',checked,sim,'evaluator',[request_event])
                            feedback=cell.submit(action);lifecycle[rid]={'feedback':feedback,'time':sim}
                        admission_event=evidence.emit('action_admission',feedback,sim,'gateway',[request_event])
                        pending=dispatch_candidate({'type':'feedback','feedback':feedback},[admission_event]);pending_type='feedback';next_decision=sim+.15
            if model_pending is not None and model_pending.done() and pending is None and not restart_pending:
                text=collect_model(model_pending);model_pending=None
                if text is not None:
                    pending=dispatch_candidate({'type':'model_response','text':text},[model_delivery_parent] if model_delivery_parent else []);pending_type='model_response'
            if pending is None and model_pending is None and not restart_pending:
                if feedback_cursor<len(cell.feedback):
                    feedback=cell.feedback[feedback_cursor];feedback_cursor+=1
                    if feedback['request_id'] in lifecycle:lifecycle[feedback['request_id']]['feedback']=feedback
                    pending=dispatch_candidate({'type':'feedback','feedback':feedback});pending_type='feedback'
                elif cell.active_request is None and sim>=next_decision:
                    packet=cell.public_packet(order,run_id,incarnation,obs_sequence)
                    pending=dispatch_candidate({'type':'step','packet':packet},[last_observation_event] if last_observation_event else []);pending_type='step';next_decision=sim+.1
            phase='outcome_check';checked=cell.outcome(order)
            if checked['success']:
                success_since=sim if success_since is None else success_since
                if sim-success_since>=.5:success=True;termination='independent_completion'
            else:success_since=None
            # Sample AFTER physics, rendering, compression, IPC handling and logs.
            elapsed=time.perf_counter()-start;monitor.observe(elapsed,sim_now()-base_sim)
            if success:break
            remaining=start+(sim_now()-base_sim)-time.perf_counter()
            time.sleep(max(.0001,min(.002,remaining)))
    except BaseException as exc:
        error=f'{type(exc).__name__}: {exc}'
        failure_class=exc.classification if isinstance(exc,EpisodeFailure) else 'infrastructure_failure'
        termination=failure_class
        try:evidence.emit('terminal_error',{'phase':phase,'classification':failure_class,'error':error},sim_now(),'supervisor')
        except Exception as log_exc:cleanup_errors.append('terminal error evidence: '+str(log_exc))
    finally:
        episode_end_wall=time.perf_counter();episode_ended_at=utc()
        sim_at_end=sim_now()
        if start is not None:
            elapsed=episode_end_wall-start
            try:monitor.observe(elapsed,sim_now()-base_sim)
            except Exception as exc:cleanup_errors.append('final timing sample: '+str(exc))
        if cell is not None:
            try:
                final=cell.outcome(order)
                evidence.emit('final_world',cell.truth_snapshot(),sim_now(),'evaluator')
            except Exception as exc:
                cleanup_errors.append('final evaluator evidence: '+str(exc));failure_class='infrastructure_failure'
        if model_pending is not None:
            try:collect_model(model_pending,late=True)
            except Exception as exc:cleanup_errors.append('late model evidence: '+str(exc))
            model_pending=None
        restart_cleanup_errors=close_pending_restart(pending,pending_type,worker)
        try:executor.shutdown(wait=True,cancel_futures=True)
        except Exception as exc:cleanup_errors.append('executor shutdown: '+str(exc))
        cleanup_errors.extend(restart_cleanup_errors)
        if cell is not None:
            try:cell.close()
            except Exception as exc:cleanup_errors.append('cell close: '+str(exc))
        try:evidence.close()
        except Exception as exc:cleanup_errors.append('evidence close: '+str(exc))
    timing_report=monitor.report()
    invalid=failure_class=='infrastructure_failure' or bool(cleanup_errors) or (start is not None and not timing_report['actual_host_timing_pass'])
    reasons=[]
    if failure_class=='infrastructure_failure':reasons.append('Shared infrastructure failed in phase '+phase)
    if cleanup_errors:reasons.append('Cleanup/evidence failure: '+'; '.join(cleanup_errors))
    if start is not None and not timing_report['actual_host_timing_pass']:reasons.append('Actual-host timing gate not met; cause is unassigned, not automatically attributed to the candidate')
    if not invalid:reasons.append('Development workcell has not passed all scored-readiness gates')
    result={'run_id':run_id,'stage':stage,'execution_status':'failed' if error or cleanup_errors else 'completed',
            'outcome':('success' if success else ('partial' if final and final['accepted_count'] else 'failure')) if final is not None else 'unknown',
            'validity':'invalid' if invalid else 'unknown','validity_reason':'; '.join(reasons),'ended_at':episode_ended_at,'finalized_at':utc(),
            'termination_reason':termination,'error':error,'failure_class':failure_class,'cleanup_errors':cleanup_errors,'independent_outcome':final,
            'wall_duration_s':elapsed if start is not None else None,'sim_duration_s':sim_at_end-base_sim if start is not None else None,
            'completion_time_s':elapsed if success else None,'post_episode_accounting_s':time.perf_counter()-episode_end_wall,
            'model_calls':model_calls,'model_responses':model_responses,'model_failed_calls':model_failures,'late_model_responses':late_model_responses,
            'total_tokens':tokens if unknown_token_calls==0 else None,'known_total_tokens':tokens,'unknown_token_calls':unknown_token_calls,
            'model_accounting_complete':model_calls==model_responses+model_failures and unknown_token_calls==0,
            'done_assertions':done_assertions,'false_done_assertions':false_done,'restart_exercised':restart_exercised,'order_amendment_exercised':amend_exercised,
            **timing_report,'camera_gap_samples':camera_gaps,'camera_maximum_wall_gap_s':max((g['wall_gap_s'] for g in camera_gaps),default=None),
            'camera_missed_nominal_intervals':sum(g['missed_nominal_intervals'] for g in camera_gaps),
            'motion_path_m':cell.total_path if cell is not None else None,'contact_peak_N':cell.contact_peak if cell is not None else None,
            'contact_impulse_Ns':cell.collision_impulse if cell is not None else None,
            'limits':['Development only; no scored inference until shared readiness passes','Timing gates do not determine whether lag was candidate or host/harness induced','One-second timing boundaries interpolate adjacent wall/sim samples; maximum sample gap retained','Contact impulse includes intended contacts; not a collision-only metric']}
    temporary=evidence.path/'result.json.tmp';temporary.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');os.replace(temporary,evidence.path/'result.json')
    print(json.dumps(result,indent=2),flush=True)
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--kind',choices=['baseline','A1','A2','A3'],default='baseline');parser.add_argument('--parts',type=int,default=3);parser.add_argument('--seed',type=int,default=0);parser.add_argument('--cap',type=float,default=300);parser.add_argument('--scenario',choices=['nominal','order_change','restart','mixed'],default='nominal');parser.add_argument('--condition',choices=['persistent','no-persistence'],default='persistent');parser.add_argument('--run-id')
    args=parser.parse_args();kwargs={'kind':args.kind,'n':args.parts,'seed':args.seed,'cap':args.cap,'scenario':args.scenario,'condition':args.condition,'run_id':args.run_id}
    if args.kind=='baseline':run_episode(**kwargs)
    else:
        from model_runtime import LocalModel
        with LocalModel() as model:run_episode(model=model,**kwargs)

if __name__=='__main__':main()
