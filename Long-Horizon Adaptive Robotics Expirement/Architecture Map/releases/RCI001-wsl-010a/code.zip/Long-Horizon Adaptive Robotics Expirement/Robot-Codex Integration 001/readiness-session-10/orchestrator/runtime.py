"""Trusted Windows orchestration; no host credentials enter the Linux workspace."""
from __future__ import annotations
import argparse
import asyncio
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid

HERE = Path(__file__).resolve().parent
SESSION = HERE.parent
INTEGRATION = SESSION.parent
REPO = INTEGRATION.parents[1]
S9 = INTEGRATION / 'isolation-session-9'
BOUNDARY = SESSION / 'boundary'
DISTRO = 'Ubuntu-24.04'
RUNTIME_ROOT = '/var/tmp/robot-codex-session10'
sys.path.insert(0, str(S9 / 'wsl'))
sys.path.insert(0, str(BOUNDARY))
sys.path.insert(0, str(INTEGRATION / 'host'))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

prior = load('session9_qualification', S9 / 'wsl/qualification.py')
bootstrap = load('session10_bootstrap', HERE / 'bootstrap_client.py')
from codehost_bridge import run as with_codehost

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())

def linux(script, *args, payload=None, timeout=30):
    result = subprocess.run(['wsl.exe', '-d', DISTRO, '--', 'python3', '-B', '-c', script, *map(str,args)],
        input=None if payload is None else json.dumps(payload), capture_output=True,
        text=True, encoding='utf-8', timeout=timeout)
    if result.returncode:
        raise RuntimeError('Linux trusted operation failed: ' + result.stderr[-3000:])
    return result.stdout

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs): return None
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

def request(origin, token, method, path, body=None, *, operator=False):
    raw = None if body is None else json.dumps(body, allow_nan=False).encode()
    req = urllib.request.Request(origin + path, data=raw, method=method,
        headers={('X-Robot-Operator-Capability' if operator else 'X-Robot-Capability'): token,
                 'Content-Type': 'application/json'})
    try:
        response = OPENER.open(req, timeout=8)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        raw = response.read(1048577)
        if len(raw) > 1048576: raise RuntimeError('Gateway reply exceeds 1MiB')
        return response.code, json.loads(raw)

class Runtime:
    def __init__(self, evidence, files, endpoint=None, host_workspace=None, prior_snapshot=None):
        self.evidence = Path(evidence)
        self.evidence.mkdir(parents=True, exist_ok=False)
        self.root = self.evidence / 'control'
        self.root.mkdir()
        self.run = RUNTIME_ROOT + '/' + uuid.uuid4().hex
        self.workspace = self.run + '/workspace'
        self.socket = self.run + '/gateway.sock'
        self.files = dict(files)
        self.host_workspace = host_workspace
        self.bridge_idle = asyncio.Event(); self.bridge_idle.set()
        self.abort_event = threading.Event()
        self.client_finishing = threading.Event()
        self.stop = threading.Event()
        self.gateway = self.owner = self.broker = None
        self.broker_calls = []
        self.tokens = []
        self.personal_canary = None
        self.retired = False
        if endpoint is None:
            from run_host import HttpGateway
            from supervisor import Supervisor, Journal
            from test_supervisor import FakeAdapter, Candidate, packet
            self.adapter = FakeAdapter()
            self.journal = Journal(self.root / 'protected', self.root / 'runtime', 'readiness-synthetic')
            self.host = Supervisor(self.adapter, Candidate('baseline', self.root / 'baseline', True), self.journal)
            self.host.update_observation(packet())
            self.host.activate('Readiness filesystem bootstrap; no physical robot')
            self.gateway = HttpGateway(self.journal.workspace)
            self.gateway.rotate(self.host.epoch); self.gateway.start()
            endpoint = {'url': 'http://127.0.0.1:' + str(self.gateway.server.server_port),
                        'capability': self.gateway.capability, 'authority_epoch': self.host.epoch}
            def owner():
                while not self.stop.wait(.01): self.gateway.process(self.host)
            self.owner = threading.Thread(target=owner, daemon=True); self.owner.start()
        self.endpoint = dict(endpoint)
        self.token = endpoint['capability']; self.tokens.append(self.token)
        self.files['live/endpoint.json'] = json.dumps({**endpoint, 'schema':'robot-codex-host-1.0','url':'http://127.0.0.1:38117'})
        personal = Path(os.environ['USERPROFILE']) / 'Documents' / ('RobotCodex-S10-Canary-' + uuid.uuid4().hex + '.txt')
        personal.write_text('Synthetic unrelated-user denial control; no secret.\n')
        self.personal_canary = personal
        repo_canary = self.evidence / 'repository-canary.txt'
        repo_canary.write_text('Synthetic repository denial control.\n')
        protected = {'repository_canary': prior.wsl_path(repo_canary), 'unrelated_user_canary':prior.wsl_path(personal),
                     'evaluator_canary':self.run+'/protected/evaluator.txt', 'development_evidence_canary':self.run+'/protected/development.txt'}
        self.files['live/canaries.json'] = json.dumps({'protected':protected,'other_port':1})
        setup = '''import sys,json,pathlib,hashlib
sys.path.insert(0,sys.argv[1]); from runtime_layout import prepare_workspace
x=json.load(sys.stdin); prepare_workspace(x['run'],x['files'])
root=pathlib.Path(x['run']); (root/'protected').mkdir()
for n in ['evaluator.txt','development.txt']:(root/'protected'/n).write_text('Synthetic denied control')
print(json.dumps({'protected_exist':{k:pathlib.Path(v).is_file() for k,v in x['protected'].items()},'binary_sha256':hashlib.sha256(pathlib.Path(x['codex']).read_bytes()).hexdigest(),'codehost_sha256':hashlib.sha256(pathlib.Path(x['codehost']).read_bytes()).hexdigest()}))
'''
        self.setup = json.loads(linux(setup, prior.wsl_path(BOUNDARY), payload={'run':self.run,'files':self.files,'protected':protected,
            'codex':prior.LINUX_CODEX,'codehost':prior.LINUX_CODEHOST}))
        if not all(self.setup['protected_exist'].values()) or self.setup['binary_sha256'] != prior.LINUX_SHA256 or self.setup['codehost_sha256'] != prior.CODEHOST_SHA256:
            raise RuntimeError('Positive controls or installed binary hashes failed')
        if prior_snapshot:
            payload = json.loads(Path(prior_snapshot).read_text(encoding='utf-8'))
            restore = '''import pathlib,json,base64,sys,os
root=pathlib.Path(sys.argv[1]); x=json.load(sys.stdin)
for name,item in x['files'].items():
 if not(name.startswith('notes/') or name.startswith('programs/') or name=='.continuity/Continuity.md'):continue
 p=root/name
 if not p.resolve().is_relative_to(root.resolve()):raise SystemExit('Restore escape')
 p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(base64.b64decode(item['base64']))
print('restored')
'''
            linux(restore, self.workspace, payload=payload)
        self.broker = subprocess.Popen(['wsl.exe','-d',DISTRO,'--','python3','-B',prior.wsl_path(BOUNDARY/'unix_broker.py'),self.socket,
            '--workspace',self.workspace], stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
        ready = json.loads(self.broker.stdout.readline())
        if not ready.get('ready'): raise RuntimeError('Fixed broker did not start')
        control = "import pathlib,json,socket,sys;p=pathlib.Path(sys.argv[1]);x=json.loads(p.read_text());x['other_port']=int(sys.argv[2]);p.write_text(json.dumps(x));s=socket.create_connection(('127.0.0.1',int(sys.argv[2])),2);s.close();print('passed')"
        self.setup['outside_loopback_control'] = 'passed' in linux(control,self.workspace+'/live/canaries.json',ready['other_port'])
        self.broker_thread = threading.Thread(target=self._broker_loop,daemon=True);self.broker_thread.start()
        self.mirror_thread=None
        if self.host_workspace:
            self.mirror_thread=threading.Thread(target=self._mirror_loop,daemon=True);self.mirror_thread.start()
        write_json(self.evidence/'runtime-input-hashes.json',{k:hashlib.sha256(v.encode()).hexdigest() for k,v in self.files.items() if k!='live/endpoint.json'})
        write_json(self.evidence/'runtime-location.json',{'run':self.run,'workspace':self.workspace,'durable_backing':True,'setup':self.setup})

    def _mirror_loop(self):
        script='''import pathlib,json,sys,os,uuid
root=pathlib.Path(sys.argv[1]); x=json.load(sys.stdin)
for name,content in x.items():
 p=root/name
 if name not in ['live/state.json','live/activation.json','live/observations/latest.json']:raise SystemExit('not a public mirror')
 p.parent.mkdir(parents=True,exist_ok=True); tmp=p.with_name(p.name+'.mirror-'+uuid.uuid4().hex);tmp.write_text(content);os.replace(tmp,p)
'''
        while not self.stop.is_set():
            try:
                files={}
                for name in ('live/state.json','live/activation.json','live/observations/latest.json'):
                    path=Path(self.host_workspace)/name
                    if path.is_file() and path.stat().st_size<=1048576:files[name]=path.read_text(encoding='utf-8')
                linux(script,self.workspace,payload=files,timeout=10)
            except Exception as error:
                write_json(self.evidence/'mirror-error.json',{'error':str(error)})
                self.abort_event.set();return
            self.stop.wait(.75)

    def _broker_loop(self):
        from gateway_policy import validate_request
        for line in self.broker.stdout:
            try:
                data = json.loads(line)
                valid = validate_request(data)
                # validate_request raises for malformed/unknown routes; token is
                # permanently tied to this invocation, never reread from disk.
                if data.get('capability') != self.token or self.retired:
                    status, body = 403, {'ok':False,'error':{'code':'invocation_capability_denied'}}
                else:
                    payload=json.loads(data['body']) if data.get('body') else None
                    status, body = request(self.endpoint['url'],self.token,data['method'],data['path'],payload)
                record = {'wall_unix_s':time.time(),'method':data.get('method'),'path':data.get('path'),
                          'status':status,'request':data.get('body'),'response':body}
                with (self.evidence/'broker-events.jsonl').open('a',encoding='utf-8') as stream:
                    stream.write(self.redact(json.dumps(record))+'\n');stream.flush();os.fsync(stream.fileno())
                self.broker_calls.append({'method':data.get('method'),'path':data.get('path'),'status':status})
                self.broker.stdin.write(json.dumps({'status':status,'body':json.dumps(body)})+'\n');self.broker.stdin.flush()
            except (ValueError, KeyError, PermissionError) as error:
                self.broker.stdin.write(json.dumps({'status':403,'body':json.dumps({'ok':False,'error':{'code':'broker_route_denied'}})})+'\n');self.broker.stdin.flush()
            except Exception as error:
                write_json(self.evidence/'broker-failure.json',{'type':type(error).__name__,'error':self.redact(str(error))})
                self.abort_event.set();break

    def argv(self,mode):
        return ['wsl.exe','-d',DISTRO,'--','python3','-B',prior.wsl_path(BOUNDARY/'linux_entry.py'),mode,
            '--workspace',self.workspace,'--socket',self.socket,'--codex',prior.LINUX_CODEX,'--codehost',prior.LINUX_CODEHOST]

    def redact(self,value):
        for token in self.tokens:
            if token:value=value.replace(token,'[REDACTED_EPHEMERAL_CAPABILITY]')
        return value

    def export(self,label):
        script = '''import pathlib,json,base64,hashlib,sys
root=pathlib.Path(sys.argv[1]); files={}; total=0
for p in sorted(root.rglob('*')):
 if p.is_symlink():continue
 if not p.is_file():continue
 name=p.relative_to(root).as_posix()
 if name=='live/endpoint.json':continue
 if not p.resolve().is_relative_to(root.resolve()):raise SystemExit('Export escape')
 size=p.stat().st_size
 if size>4194304:raise SystemExit('Artifact exceeds 4MiB')
 total+=size
 if total>33554432:raise SystemExit('Runtime export exceeds32MiB')
 raw=p.read_bytes();files[name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'base64':base64.b64encode(raw).decode()}
print(json.dumps({'files':files,'total_bytes':total,'scope':'actual file bytes; endpoint omitted'}))
'''
        snapshot = json.loads(linux(script,self.workspace))
        # Agent output is redacted only when it contains the invocation token;
        # record the raw hash separately from the retained redacted bytes.
        for item in snapshot['files'].values():
            raw=base64.b64decode(item['base64'])
            for token in self.tokens: raw=raw.replace(token.encode(),b'[REDACTED_EPHEMERAL_CAPABILITY]')
            item['retained_sha256']=hashlib.sha256(raw).hexdigest()
            item['base64']=base64.b64encode(raw).decode()
        write_json(self.evidence/(label+'.json'),snapshot)
        return snapshot

    def qualify(self):
        for mode in ('canary','codehost-canary'):
            proc=subprocess.run(self.argv(mode),capture_output=True,text=True,encoding='utf-8',timeout=45)
            (self.evidence/(mode+'-stdout.json')).write_text(self.redact(proc.stdout),encoding='utf-8')
            (self.evidence/(mode+'-stderr.txt')).write_text(self.redact(proc.stderr),encoding='utf-8')
            data=json.loads(proc.stdout)
            if proc.returncode or not data.get('qualified',data.get('host_qualified')):
                raise RuntimeError(mode+' qualification failed')

    async def model(self,timeout=600,preflight=False,interrupt_event=None):
        async def callback(url):
            await prior.executor_probe(url,self)
            await asyncio.wait_for(self.bridge_idle.wait(),15)
            args=argparse.Namespace(exec_server_url=url,host_cwd=self.root,codex_home=Path(os.environ.get('CODEX_HOME',str(Path.home()/'.codex'))),
                remote_cwd='file:///workspace',evidence=self.evidence/'client',timeout=timeout,run_bootstrap=not preflight,
                redact_tokens=self.tokens,abort_event=self.abort_event,client_finishing=self.client_finishing)
            async def model_host(host_url):
                args.code_mode_host_url=host_url
                return await asyncio.to_thread(bootstrap.run,args)
            return await with_codehost(self,model_host)
        return await prior.bridge_executor(self,callback)

    def close(self):
        self.retired=True
        self.stop.set()
        if self.mirror_thread:self.mirror_thread.join(timeout=12)
        if self.broker:
            self.broker.stdin.close()
            try:self.broker.wait(timeout=8)
            except subprocess.TimeoutExpired:self.broker.terminate();self.broker.wait(timeout=5)
            self.broker_thread.join(timeout=2)
        if self.owner:self.owner.join(timeout=2)
        if self.gateway:self.gateway.close()
        if self.personal_canary:self.personal_canary.unlink(missing_ok=True)
        write_json(self.evidence/'gateway-calls.json',self.broker_calls)

def template(kind):
    folder=INTEGRATION/('smoke-template' if kind=='bootstrap' else 'runtime-template')
    files={p.relative_to(folder).as_posix():p.read_text(encoding='utf-8') for p in folder.rglob('*') if p.is_file()}
    files['RobotAgentPrompt.md']=(REPO/'Robot Agent Filesystem v0.1/workspace/RobotAgentPrompt.md').read_text(encoding='utf-8')
    files['Tools.md']+='\nSession10 binding: WSL2/bubblewrap enforces isolation. Run `python3 /canary.py` for non-actuating boundary checks. Continuity.md is a fixed symlink to a writable directory; atomic replacements must target its resolved .continuity/Continuity.md backing file. No subagents or external network.\n'
    if kind=='bootstrap':
        files['Tasks.md']+='\nAlso run `python3 /canary.py` and save its JSON result to notes/boundary-observation.json. Use atomic replacement of .continuity/Continuity.md and verify Continuity.md reads the new bytes. No actuation.\n'
    return files

def run_bootstrap(evidence,preflight=False,timeout=600):
    runtime=None; result={'success':False}
    try:
        runtime=Runtime(evidence,template('bootstrap'))
        runtime.qualify()
        asyncio.run(runtime.model(timeout,preflight))
        result=json.loads((Path(evidence)/'client/result.json').read_text())
    except Exception as error:
        result.update(error=str(error),error_type=type(error).__name__)
    finally:
        if runtime:
            try:runtime.export('runtime-before-close')
            except Exception as error:result['export_error']=str(error)
            runtime.close()
            try:
                after=runtime.export('runtime-after-close')
                before=json.loads((Path(evidence)/'runtime-before-close.json').read_text())
                result['durable_retention_verified']=before==after
            except Exception as error:result['post_close_export_error']=str(error)
        write_json(Path(evidence)/'orchestration-result.json',result)
    print(json.dumps(result))
    return 0 if result.get('success') and result.get('durable_retention_verified') else 1

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--evidence',type=Path,required=True)
    parser.add_argument('--preflight',action='store_true')
    parser.add_argument('--timeout',type=int,default=600)
    args=parser.parse_args()
    raise SystemExit(run_bootstrap(args.evidence,args.preflight,args.timeout))
