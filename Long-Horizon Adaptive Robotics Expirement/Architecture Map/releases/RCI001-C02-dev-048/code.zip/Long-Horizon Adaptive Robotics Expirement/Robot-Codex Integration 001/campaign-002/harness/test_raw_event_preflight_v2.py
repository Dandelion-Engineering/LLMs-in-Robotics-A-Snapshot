"""Owner-aware metadata preflight; synthetic receipts, no process launch."""
import copy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import test_raw_event_preflight as old

spec=importlib.util.spec_from_file_location('owner_preflight_under_test',Path(__file__).with_name('raw_event_preflight_v2.py'))
P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)
B=P.dependency('bootstrap_client_v4')


class OwnerPreflightTests(unittest.TestCase):
    def setUp(self):
        self.fixture=old.PreflightTests()
        self.addCleanup(self.fixture.doCleanups)
        with patch.object(old,'P',P),patch.object(old,'B',B):
            self.fixture.setUp()
        self.root=self.fixture.root;self.runtime=self.fixture.runtime
        self.fixture.source['schema']='campaign002-raw-preflight-source-2'
        old.put(self.root/'source-binding.json',self.fixture.source)
        self.owner={'schema':'campaign002-native-owner-1','owner_kind':'model_client',
                    'pid':123,'process_creation_filetime':789,
                    'executable':self.fixture.source['native_binary']}
        old.put(self.runtime/'client/native-owner.json',self.owner)
        old.put(self.runtime/'codehost-native-owner-v3.json',self.owner)
        events=self.events()
        binding=P.binding(self.runtime/'client/native-owner.json')
        events.insert(0,{'kind':'native_process_owner_registered',
                         'receipt_sha256':binding['sha256'],'receipt_bytes':binding['bytes']})
        self.write_events(events)
        retirement=old.get(self.runtime/'executor-1-retirement.json')
        retirement['identity_path']=self.fixture.namespace+'/codehost-owner.json'
        old.put(self.runtime/'codehost-owner-retirement-v3.json',retirement)
        self.proof={'passed':True,'accepted_count':0,'input_bindings':{
            'client/native-owner.json':P.binding(self.runtime/'client/native-owner.json')}}
        self.verifier=self.enterContext(patch.object(P.dependency('transport_integrity_v3'),
            'verify_transport_integrity',side_effect=lambda *a,**kw:copy.deepcopy(self.proof)))

    def events(self):
        return [json.loads(line) for line in (self.runtime/'client/events.jsonl').read_bytes().splitlines()]

    def write_events(self,events):
        (self.runtime/'client/events.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in events),encoding='utf-8')

    def assess(self):return P.assess(self.root,self.fixture.snapshot)

    def test_zero_channel_preflight_still_requires_eager_namespace_and_owner(self):
        result=self.assess()
        self.assertTrue(result['passed'],result['errors'])
        self.assertEqual(result,P.assess(self.root,self.fixture.snapshot))
        self.assertEqual(result['lifecycle']['namespace_retirements'],[
            'codehost-owner-retirement-v3.json','executor-1-retirement.json','executor-2-retirement.json'])
        self.assertFalse(result['lifecycle']['raw_tool_payload_path_tested'])
        self.verifier.assert_called_with(self.runtime,self.fixture.frozen,owner_kind='model_client',allow_empty=True)

    def test_owner_mismatch_and_missing_identity_fail_before_lifecycle(self):
        for field,value in [('pid',True),('process_creation_filetime',0),('owner_kind','transport_probe')]:
            with self.subTest(field=field):
                modified=copy.deepcopy(self.owner);modified[field]=value
                old.put(self.runtime/'client/native-owner.json',modified)
                self.assertFalse(self.assess()['passed'])
                old.put(self.runtime/'client/native-owner.json',self.owner)
        self.verifier.assert_not_called()

    def test_receipt_after_initialize_duplicate_or_wrong_hash_is_rejected(self):
        original=self.events()
        for case in ('late','duplicate','hash'):
            events=copy.deepcopy(original)
            if case=='late':events.insert(2,events.pop(0))
            elif case=='duplicate':events.insert(0,copy.deepcopy(events[0]))
            else:events[0]['receipt_sha256']='0'*64
            self.write_events(events)
            self.assertFalse(self.assess()['passed'],case)
        self.verifier.assert_not_called()

    def test_verifier_failure_missing_host_retirement_and_byte_mismatch_fail(self):
        self.proof['passed']=False
        self.assertFalse(self.assess()['passed'])
        self.proof['passed']=True
        self.proof['input_bindings']['client/native-owner.json']['sha256']='0'*64
        self.assertFalse(self.assess()['passed'])
        self.proof['input_bindings']['client/native-owner.json']=P.binding(self.runtime/'client/native-owner.json')
        (self.runtime/'codehost-owner-retirement-v3.json').unlink()
        self.assertFalse(self.assess()['passed'])

    def test_model_activity_and_changed_raw_option_still_fail(self):
        events=self.events();original=copy.deepcopy(events)
        events.append({'kind':'request','method':'turn/start','id':11,'params':{}})
        self.write_events(events);self.assertFalse(self.assess()['passed'])
        self.write_events(original)
        preflight=old.get(self.runtime/'client/preflight.json')
        preflight['experimental_raw_events_thread_start_accepted']=False
        old.put(self.runtime/'client/preflight.json',preflight)
        self.assertFalse(self.assess()['passed'])

    def test_executor_capture_delivery_and_retirement_remain_required(self):
        (self.runtime/'executor-2-retirement.json').unlink()
        self.assertFalse(self.assess()['passed'])

    def test_source_inventory_includes_owner_transport_and_prospective_contract(self):
        names=P.required_sources()
        for suffix in ('bootstrap_client_v4.py','codehost_owner.py','codehost_mux_protocol.py',
                       'transport_integrity_v3.py','raw_event_preflight_v2.py',
                       'CODEHOST_CHANNEL_TRANSPORT_V3.md','CHANNEL_TRANSPORT_V3_QUALIFICATION_001.md'):
            self.assertEqual(sum(name.endswith('/'+suffix) for name in names),1)


if __name__=='__main__':unittest.main()
