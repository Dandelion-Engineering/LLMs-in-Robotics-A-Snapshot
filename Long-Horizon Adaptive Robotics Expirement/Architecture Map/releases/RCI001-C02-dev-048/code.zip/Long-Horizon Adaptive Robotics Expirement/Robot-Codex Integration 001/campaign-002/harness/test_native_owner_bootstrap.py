"""No native launch: owner ordering/failure closure and exact dev041 parity."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

from test_raw_event_capture import load, HERE, REPO

V4 = load('native_owner_candidate_v4', HERE / 'bootstrap_client_v4.py')
ARCHIVE = HERE.parents[2] / 'Architecture Map/releases/RCI001-C02-dev-041/code.zip'
ARCHIVE_SHA = '1b05d7dc1ac46973c64e0a45f34d933a179c99b813a2058eadfd2824f9a99727'
CALLBACK_BLOCK = b'''        if code_mode_host_url:
            owner_callback = getattr(args, "native_process_ready", None)
            require(callable(owner_callback), "Authenticated native process owner callback is required")
            owner_binding = owner_callback(client.process, LAUNCH.CODEX)
            require(isinstance(owner_binding, dict), "Native owner callback did not return a receipt")
            owner_path = args.evidence / "native-owner.json"
            LAUNCH.write_json(owner_path, owner_binding)
            client.log({"kind": "native_process_owner_registered",
                        "receipt_sha256": LAUNCH.sha256(owner_path),
                        "receipt_bytes": owner_path.stat().st_size})
'''
RUNTIME_EDITS = (
    (b"bootstrap = load('campaign002_bootstrap_v3', HERE / 'bootstrap_client_v3.py')",
     b"bootstrap = load('campaign002_bootstrap_v4', HERE / 'bootstrap_client_v4.py')"),
    (b"with_codehost = load('campaign002_codehost_bridge_v2', HERE / 'codehost_bridge_v2.py').run",
     b"with_codehost = load('campaign002_codehost_bridge_v3', HERE / 'codehost_bridge_v3.py').run"),
    (b"entry = HERE / 'codehost_entry_v2.py'", b"entry = HERE / 'codehost_entry_v3.py'"),
    (b'                args.code_mode_host_url=host_url\n',
     b'                args.code_mode_host_url=host_url\n                args.native_process_ready=self.native_process_ready\n'),
)


class NativeOwnerBootstrapTests(unittest.TestCase):
    def exercise(self, *, callback=True, failure=None, invalid=False, write_failure=False, model=False):
        root = Path(self.enterContext(tempfile.TemporaryDirectory()))
        host, home = root/'host', root/'home'
        host.mkdir(); home.mkdir()
        args = SimpleNamespace(host_cwd=host, codex_home=home, timeout=90,
            evidence=root/'client', exec_server_url='ws://127.0.0.1:1234/synthetic',
            code_mode_host_url='http://127.0.0.1:2345', remote_cwd='file:///workspace',
            run_bootstrap=model)
        events, calls, receipts = [], [], {}
        process = object()
        binding = {'schema': 'synthetic-owner', 'pid': 123, 'creation': 'synthetic'}
        def register(actual, binary):
            self.assertIs(actual, process)
            self.assertEqual(binary, Path('synthetic-native.exe'))
            events.append('registered')
            if failure: raise RuntimeError(failure)
            return None if invalid else binding
        if callback: args.native_process_ready = register
        config = {'features': {name: False for name in V4.DISABLED},
                  'model_provider': 'openai', 'web_search': 'disabled', 'project_doc_max_bytes': 0}
        config['features']['code_mode_host'] = True
        class Native:
            def call(self, method, params, *, private=False):
                calls.append((method, copy.deepcopy(params), private)); events.append(method)
                if method == 'config/read': return {'config': config}
                if method == 'account/read': return {'account': {'type': 'chatgpt'}}
                if method == 'environment/status': return {'status': 'unknown' if params['environmentId']=='local' else 'ready'}
                if method == 'environment/info': return {'shell': {'path': '/usr/bin/bash'}, 'cwd': 'file:///workspace'}
                if method == 'thread/start': return {'model': V4.LAUNCH.MODEL, 'modelProvider': 'openai',
                    'reasoningEffort': V4.LAUNCH.EFFORT, 'instructionSources': [], 'thread': {'id': 'synthetic-thread'}}
                if method == 'mcpServerStatus/list': return {'data': []}
                if method == 'turn/start': return {'turn': {'id': 'synthetic-turn'}}
                return {}
            def send(self, value): events.append('send')
            def log(self, value):
                events.append(value['kind'])
                if value['kind']=='native_process_owner_registered':
                    raw=(args.evidence/'native-owner.json').read_bytes()
                    self_outer.assertEqual(value['receipt_sha256'], hashlib.sha256(raw).hexdigest())
                    self_outer.assertEqual(value['receipt_bytes'], len(raw))
            def wait_turn(self, identity): return {'id': identity, 'status': 'completed'}
            def close(self): events.append('closed')
        self_outer=self
        native=Native(); native.process=process
        def write(path, value):
            if write_failure and path.name=='native-owner.json': raise OSError('synthetic receipt failure')
            path.write_text(json.dumps(value), encoding='utf-8')
            receipts[path.name]=copy.deepcopy(value); events.append('write:'+path.name)
        fake=SimpleNamespace(MODEL=V4.LAUNCH.MODEL, EFFORT=V4.LAUNCH.EFFORT,
            CODEX=Path('synthetic-native.exe'), utc=lambda:'synthetic-time',
            sha256=lambda path: hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else '0'*64,
            config_args=lambda config:[], clean_environment=lambda path:{}, write_json=write)
        with patch.object(V4,'LAUNCH',fake),patch.object(V4,'Client',return_value=native):
            result=V4.run(args)
        return result, events, calls, receipts

    def test_registration_and_durable_receipt_precede_first_rpc(self):
        result, events, calls, receipts=self.exercise()
        self.assertTrue(result['success']); self.assertFalse(result['model_started'])
        self.assertLess(events.index('registered'), events.index('write:native-owner.json'))
        self.assertLess(events.index('write:native-owner.json'), events.index('native_process_owner_registered'))
        self.assertLess(events.index('native_process_owner_registered'), events.index('initialize'))
        self.assertEqual(sum(method=='thread/start' for method,_,_ in calls),1)
        self.assertFalse(any(method=='turn/start' for method,_,_ in calls))
        self.assertTrue(receipts['preflight.json']['experimental_raw_events_thread_start_accepted'])

    def test_missing_callback_fails_before_initialize_and_closes_client(self):
        result,events,calls,_=self.exercise(callback=False)
        self.assertFalse(result['success']); self.assertFalse(result['model_started'])
        self.assertEqual(calls,[]); self.assertIn('closed',events)

    def test_registration_rejection_fails_before_any_rpc(self):
        result,events,calls,receipts=self.exercise(failure='synthetic owner rejected')
        self.assertFalse(result['success']); self.assertFalse(result['model_started'])
        self.assertIn('owner rejected',result['error']); self.assertEqual(calls,[])
        self.assertNotIn('native-owner.json',receipts); self.assertIn('closed',events)

    def test_invalid_callback_receipt_fails_before_any_rpc(self):
        result,events,calls,_=self.exercise(invalid=True)
        self.assertFalse(result['success']); self.assertEqual(calls,[]); self.assertIn('closed',events)

    def test_failed_durable_receipt_prevents_initialize(self):
        result,events,calls,_=self.exercise(write_failure=True)
        self.assertFalse(result['success']); self.assertEqual(calls,[])
        self.assertNotIn('native_process_owner_registered',events); self.assertIn('closed',events)

    def test_exact_bootstrap_and_raw_option_survive_owner_plumbing(self):
        result,_,calls,_=self.exercise(model=True)
        self.assertTrue(result['success']); self.assertTrue(result['model_started'])
        turns=[p for m,p,_ in calls if m=='turn/start']; self.assertEqual(len(turns),1)
        self.assertEqual(turns[0]['input'],[{'type':'text','text':V4.BOOTSTRAP,'text_elements':[]}])
        self.assertIs(next(p for m,p,_ in calls if m=='thread/start')['experimentalRawEvents'],True)


class NativeOwnerParityTests(unittest.TestCase):
    def test_exact_mechanical_reversal_recovers_archived_dev041(self):
        self.assertEqual(hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),ARCHIVE_SHA)
        with zipfile.ZipFile(ARCHIVE) as archive:
            original=archive.read((HERE/'bootstrap_client_v3.py').relative_to(REPO).as_posix())
            self.assertEqual(original,(HERE/'bootstrap_client_v3.py').read_bytes())
            candidate=(HERE/'bootstrap_client_v4.py').read_bytes()
            self.assertEqual(candidate.count(CALLBACK_BLOCK),1)
            self.assertEqual(candidate.replace(CALLBACK_BLOCK,b''),original)
            current=(HERE/'runtime.py').read_bytes()
            for before,after in RUNTIME_EDITS:
                self.assertEqual(current.count(after),1); current=current.replace(after,before)
            self.assertEqual(current,archive.read((HERE/'runtime.py').relative_to(REPO).as_posix()))

    def test_client_and_unrelated_runtime_methods_are_identical(self):
        with zipfile.ZipFile(ARCHIVE) as archive:
            for name,oldfile,newfile,changed in [('Client','bootstrap_client_v3.py','bootstrap_client_v4.py',set()),
                                                 ('Runtime','runtime.py','runtime.py',{'argv','model'})]:
                old=ast.parse(archive.read((HERE/oldfile).relative_to(REPO).as_posix()))
                new=ast.parse((HERE/newfile).read_bytes())
                def methods(tree):
                    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)
                    return {n.name:ast.dump(n,include_attributes=False) for n in cls.body
                            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
                baseline,candidate=methods(old),methods(new)
                self.assertEqual(set(baseline),set(candidate))
                for method in baseline:
                    if method not in changed: self.assertEqual(baseline[method],candidate[method],method)


if __name__=='__main__': unittest.main()
