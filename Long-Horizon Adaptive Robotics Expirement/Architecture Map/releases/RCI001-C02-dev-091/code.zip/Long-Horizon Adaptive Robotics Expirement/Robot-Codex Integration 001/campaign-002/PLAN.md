# Campaign 002: apparatus repair and known-fixture repeatability

Randy's September 27, 2026 13:45 PDT instruction authorizes infrastructure repair, requalification and this campaign without another launch approval. Campaign 001 remains exactly 6 valid successes, 4 infrastructure-invalid attempts and 14 not run. Its sources, manifests, assessments and investigation are immutable inputs, not targets for repair.

## Experiment and allocation

After qualification, run **20 fresh attempts, 10 per known challenge family**: misplaced stock and blocked insert home. Keep world seed 173, use sensor seeds 23001–23020, alternate family within pairs and reverse first family on alternate pairs. Use a fresh external workspace, empty initial continuity and one fresh GPT-6 Astra Max invocation per slot. The exact sole bootstrap remains `Follow the instructions in RobotAgentPrompt.md.`. No recovery prompt, template, policy, controller, physics, sensing, fixture or evaluator tuning is authorized here.

Campaign 001's ten starts occupied 49.10 queue minutes and 46.71 summed host minutes; 6 were valid and 4 infrastructure-invalid. A 20-slot allocation projects approximately 98 minutes of queue occupancy at that observed mean, plus qualification, reporting and service variability. The host caps allow up to 6.11 hours of physics-host time, with outer overhead additional. Ten trials per family have an 89.3% chance to expose at least one event of probability 20%, assuming independent trials; 10/10 successes still have a 95% Wilson lower limit near 72.2%. This is useful repeatability evidence with broad uncertainty, not a high-reliability certification. Twenty is a fresh allocation justified by observed cost and precision, not replacement of Campaign 001's fourteen unrun slots.

## Repairs and prospective timing definition

The transport repair makes established revocation durable in the broker: a confirmed handback or definitive denial of the pinned capability latches local denial of later calls. It never fabricates successful continuity, extends robot authority, or forgives an unexplained transport failure. New request-intent and failure records retain route, association and time.

Campaign 001 used a per-tick loop origin and a differently anchored sparse journal reconstruction. Home02 passed the former and failed the latter; home03/home05 failed both. Campaign 002 retains complete compact timing samples with one explicit measured-physics origin and samples before catch-up as well as after ticks. Apply the **unchanged** frozen TimingMonitor: maximum lag strictly below 0.1 s, one-second RTF 0.95–1.05, and strictly fewer than 1% out-of-range windows. Initialization before physics and terminal cleanup after it are explicitly outside the interval, as the original monitor specification intended. Journal reconstruction remains diagnostic. This is a prospective measurement correction, not a reinterpretation of Campaign 001.

The initial stabilization uses existing WSL service warmup before host start, Windows AboveNormal host priority and a paired 1 ms timer request, with receipts. These are prospective scheduling changes, not proven explanations of historical stalls. Per-phase measurements will identify any remaining critical-path delays. A failed development qualification can lead to another infrastructure revision with a new immutable run identity; every failure remains retained. No scored outcomes may be used for tuning.

## Qualification gates

Before scoring, register and freeze each tested revision. Run meaningful negative tests for revocation, transport errors, source/queue integrity, timing replay and threshold equality. Preserve existing host, client, boundary, lifecycle, evaluator and continuity tests. Run six unretried no-model reference episodes (three per family, sensor seeds 24001–24006) through the shared queue to test the repaired host and independently verified fixture completion. Retain every failed qualification, never silently replace it.

Then exercise the full isolated path with the existing interruption/fresh-invocation smoke and one development pilot per family (seeds 24101–24103, fresh identities). The smoke has its existing two-invocation lifecycle protocol; pilots retain the campaign's one-invocation protocol. Require authentic queue completion, original boundary canaries, control fencing, complete evidence/retirement/continuity, independent evaluation, and strict fresh timing for the final revision. Diagnostic retries after a repair are distinct new qualification attempts, not scored repetitions. If these gates cannot be satisfied, scoring stays closed and the concrete unresolved evidence is reported.

Seal the exact final implementation, external assessor, qualification receipts, storage policy, allocation and manifests before any scored launch, then register every scored slot. Implementation changes after a scored start terminate Campaign 002 for review.

## Outcomes, stopping and resources

Keep the 900 simulation-second / 1100 host-wall-second caps, 600-second model invocation, 150-second conventional follow-through, 20 action requests, 50 observations and 512 MiB host evidence cap. Physics advances while the agent reasons. No injected scored restart, replacement, success-seeking retry, architecture comparison, ablation, simpler agent, challenge expansion or Maps + Attention work is included.

Protected independent evaluation determines task success/failure. Validity is separate: model timeout or ineffective recovery can be a valid task failure if infrastructure and evidence remain sound. Wrong sources/model/bootstrap, isolation/evaluator breach, incomplete retirement, corrupt evidence, unresolved client/transport error or strict timing failure are infrastructure-invalid. Official queue `succeeded` with integer exit 0 is required before scientific consumption; other outputs remain diagnostic with unknown task outcome.

Stop immediately for a source/isolation/evaluator/evidence-integrity breach, unverified namespace retirement or threatened capacity. Stop admission after two consecutive ordinary infrastructure-invalid slots. Invalid starts consume their slot. Do not stop early for good or bad task performance. Record every planned, started, failed, invalid and unrun slot. Never resubmit a slot with an intent, job, workspace or evidence already present; reconcile it.

Preserve all historical evidence. Monitor native and WSL growth, shared logs and free capacity. Retain a 100 GB free reserve and 2 GB retirement headroom. Allocate about 1 GiB per scored attempt plus 5 GB for qualification and investigation, with 25% planning margin; this is an estimate, not a permission gate. Modest explainable growth continues. Unexpected growth or a practical capacity threat triggers notification and an appropriate stop or adjustment, as Randy directed. No routine storage approval is required.

## Investigation and final stop

Show Campaign 002 alongside the unchanged Campaign 001 with full denominators, valid-trial Wilson intervals, invalidity, all-planned operational counts and unresolved bounds. Comparisons describe apparatus changes and observed patterns; they cannot identify a causal recovery improvement. Prespecify the first and last scheduled episode of each family for inspection regardless of outcome; additionally inspect the first valid task failure per family and each distinct infrastructure/unexpected category, labeled outcome-selected.

Connect actual observations, model/tool choices, authority, actions, continuity, conventional follow-through and protected outcomes. Use retained original images, explicitly mark missing evidence, and report whether each infrastructure fix held. Stop for Randy's review after the campaign and investigation.
