"""Trusted Windows lifetime for one persistent journaled Linux workspace."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import uuid
from common import HERE, canonical, save

DISTRO='Ubuntu-24.04'
def wsl(path):
    path=Path(path).resolve();return '/mnt/'+path.drive[0].lower()+'/'+str(path)[3:].replace('\\','/')
def linux(code,*args,payload=None):
    p=subprocess.run(['wsl.exe','-d',DISTRO,'--','python3','-B','-c',code,*map(str,args)],
        input=None if payload is None else json.dumps(payload),capture_output=True,text=True,encoding='utf-8',timeout=25)
    if p.returncode:raise RuntimeError(p.stderr[-3000:])
    return p.stdout

class WorkspaceBlock:
    def __init__(self,evidence,files,run_id,source_revision):
        self.evidence=Path(evidence);self.evidence.mkdir(parents=True,exist_ok=False)
        self.run='/var/tmp/robot-codex-session10/c03-'+uuid.uuid4().hex
        self.workspace=self.run+'/workspace';self.run_id=run_id;self.source_revision=source_revision
        self.session_id='setup';self.closed=False
        initial={'notes':None,'programs':None,'.continuity':None,'.continuity/Continuity.md':files.get('Continuity.md',''),
                 'Continuity.md':{'symlink':'.continuity/Continuity.md'}}
        for name,content in files.items():
            if name=='Continuity.md':continue
            parts=name.split('/')
            for n in range(1,len(parts)):initial.setdefault('/'.join(parts[:n]),None)
            initial[name]=content
        identity=self.identity('setup')
        linux("import pathlib,sys,json; r=pathlib.Path(sys.argv[1]); r.mkdir(mode=0o700,parents=True,exist_ok=False);(r/'workspace').mkdir();x=json.load(sys.stdin);[(r/n).write_text(json.dumps(v)) for n,v in x.items()]",self.run,
              payload={'initial.json':initial,'identity.json':identity})
        self.log=(self.evidence/'fuse-server.log').open('wb')
        self.process=subprocess.Popen(['wsl.exe','-d',DISTRO,'--','python3','-B',wsl(HERE/'journal_fs.py'),
            '--mount',self.workspace,'--evidence',self.run+'/journal','--initial',self.run+'/initial.json',
            '--identity',self.run+'/identity.json'],stdout=self.log,stderr=self.log,creationflags=subprocess.CREATE_NO_WINDOW)
        linux("import os,time,sys; end=time.monotonic()+15\nwhile not os.path.ismount(sys.argv[1]):\n if time.monotonic()>end:raise RuntimeError('Mount deadline')\n time.sleep(.02)",self.workspace)
        save(self.evidence/'location.json',{'run':self.run,'workspace':self.workspace,'run_id':run_id,'source_revision':source_revision})
        self.checkpoint('initialized')

    def identity(self,session):return {'run_id':self.run_id,'session_id':session,'source_revision':self.source_revision,'phase':'workspace'}

    def begin_session(self,session_id,files):
        self.session_id=session_id
        # Sequential invocations only: caller must hold the previous retirement receipt.
        linux("import pathlib,sys,json,os; r=pathlib.Path(sys.argv[1]);x=json.load(sys.stdin);p=r/'identity.next';p.write_text(json.dumps(x['identity']));os.replace(p,r/'identity.json')\nfor name,content in x['files'].items():\n if name=='Continuity.md' or name.startswith(('notes/','programs/','.continuity/')):continue\n p=r/'workspace'/name;p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.trusted-next');t.write_text(content);os.replace(t,p)",self.run,payload={'identity':self.identity(session_id),'files':files})
        return self.checkpoint('session-start')

    def checkpoint(self,label,sim_time_s=None):
        before={'windows_perf_ns':time.perf_counter_ns(),'windows_wall_unix_ns':time.time_ns(),'sim_time_s':sim_time_s}
        result=json.loads(linux("import socket,sys,json;s=socket.socket(socket.AF_UNIX);s.connect(sys.argv[1]);s.sendall((json.dumps(json.load(sys.stdin))+'\\n').encode());print(s.makefile().readline())",self.run+'/journal/control.sock',payload={'label':label,'clock_bracket':before}))
        if 'error' in result:raise RuntimeError(result['error'])
        value={'label':label,'run_id':self.run_id,'session_id':self.session_id,'before':before,'linux':result,
               'after':{'windows_perf_ns':time.perf_counter_ns(),'windows_wall_unix_ns':time.time_ns()}}
        with (self.evidence/'clock-brackets.jsonl').open('ab') as f:
            import os
            f.write(canonical(value)+b'\n');f.flush();os.fsync(f.fileno())
        return value

    def terminal(self,accepted,resumed,retirement):
        value=json.loads(linux("import sys,json;sys.path.insert(0,sys.argv[1]);from terminal import TerminalAppend;x=json.load(sys.stdin);print(json.dumps(TerminalAppend(sys.argv[2]+'/terminal').finalize(sys.argv[2]+'/workspace/.continuity/Continuity.md',x['accepted'],x['resumed'],x['retirement'])))",wsl(HERE),self.run,payload=dict(accepted=accepted,resumed=resumed,retirement=retirement)))
        self.checkpoint('framework-terminal-appended',resumed['sim_time_s']);return value

    def close(self):
        if self.closed:raise ValueError('Workspace already closed')
        self.checkpoint('block-close')
        linux("import subprocess,sys;p=subprocess.run(['fusermount3','-u',sys.argv[1]],capture_output=True,text=True);assert p.returncode==0,p.stderr",self.workspace)
        code=self.process.wait(timeout=10);self.log.close();self.closed=True
        if code:raise RuntimeError('Journal server exit '+str(code))
        receipt=json.loads(linux("import sys,json;sys.path.insert(0,sys.argv[1]);from verify_journal import verify;r=verify(sys.argv[2]+'/journal',sys.argv[3]);print(json.dumps({k:v for k,v in r.items() if k not in ('state','states','read_events')}))",wsl(HERE),self.run,self.run_id))
        save(self.evidence/'replay-receipt.json',receipt)
        # Exact journal including every old content object; no credential-bearing
        # Windows capability is ever placed in this workspace.
        linux("import tarfile,sys;from pathlib import Path;r=Path(sys.argv[1]);out=Path(sys.argv[2]);t=tarfile.open(out,'w:gz');t.add(r/'journal',arcname='journal',filter=lambda x:None if x.name.endswith('control.sock') else x);t.add(r/'identity.json',arcname='identity.json');t.add(r/'initial.json',arcname='initial.json');t.close()",self.run,wsl(self.evidence/'evidence.tar.gz'))
        return receipt
