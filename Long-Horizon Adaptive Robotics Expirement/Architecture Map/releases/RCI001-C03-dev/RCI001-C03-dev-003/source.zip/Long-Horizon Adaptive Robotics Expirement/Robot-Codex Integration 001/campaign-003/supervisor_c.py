"""Add terminal evidence to the existing protected authority state machine."""
import copy
import time
import os
from common import canonical
from common import inherited_paths
inherited_paths()
from supervisor import Supervisor as OriginalSupervisor

class Supervisor(OriginalSupervisor):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.accepted_handbacks={};self.resumptions={};self.current_session_id=None

    def native_event(self,event):
        if event.get('type')=='operator_plant_reload':
            with (self.journal.root/'plant-events.jsonl').open('ab') as stream:
                stream.write(canonical({'run_id':self.journal.run_id,'wall_unix_ns':time.time_ns(),**event})+b'\n')
                stream.flush();os.fsync(stream.fileno())
            return
        super().native_event(event)

    def handback(self,envelope):
        old_count=self.handoffs
        value=super().handback(envelope)
        if self.handoffs>old_count:
            receipt={**copy.deepcopy(value['command']),'run_id':self.journal.run_id,
                'session_id':self.current_session_id or (self.invocation or {}).get('invocation_id'),
                'new_authority_epoch':self.epoch,'event_id':self.journal.events[-1]['event_id'],
                'sim_time_s':self.now,'wall_unix_ns':time.time_ns()}
            self.accepted_handbacks[receipt['request_id']]=receipt
            self.emit('terminal_append_pending',{'handback_request_id':receipt['request_id'],
                'session_id':receipt['session_id'],'reason':'Await conventional resumption and namespace retirement'})
        return value

    def conventional_step(self):
        before=self.baseline_steps
        super().conventional_step()
        if self.owner=='conventional' and self.baseline_steps>before:
            for rid,accepted in self.accepted_handbacks.items():
                if rid in self.resumptions or accepted['new_authority_epoch']!=self.epoch:continue
                # A real scheduler step returned under conventional ownership.
                # Admission/terminal identities are independently retained.
                commands=[c for c in self.commands.values() if c['actor']=='conventional'
                    and c['envelope']['authority_epoch']==accepted['new_authority_epoch']
                    and c.get('requested_sim_time_s',-1)>=accepted['sim_time_s']
                    and c.get('admission',{}).get('status')=='accepted']
                if not commands:continue
                c=commands[-1]
                receipt={'run_id':self.journal.run_id,'session_id':accepted['session_id'],
                    'owner':'conventional','authority_epoch':self.epoch,'handback_request_id':rid,
                    'conventional_request_id':c['request_id'],'sim_time_s':self.now,'wall_unix_ns':time.time_ns()}
                receipt['event_id']=self.emit('conventional_resumed',receipt)
                self.resumptions[rid]=receipt
