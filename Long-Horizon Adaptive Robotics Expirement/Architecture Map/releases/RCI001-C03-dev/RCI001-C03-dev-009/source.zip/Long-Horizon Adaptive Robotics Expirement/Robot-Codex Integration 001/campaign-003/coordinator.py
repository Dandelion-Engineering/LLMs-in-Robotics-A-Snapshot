"""Prospective operator coordinator. No development proof or C motion policy.

Default invocation stops before any host/model process. A human-approved final
registration with exact source identities is required; none is supplied here.
"""
import argparse
import asyncio
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace
from common import HERE,REPO,inherited_paths,canonical,save,sha
inherited_paths()
from workspace_block import WorkspaceBlock,linux,wsl
from scheduler import Schedule
# Explicit load avoids the inherited modules named runtime/run_host.
from common import load_module
runtime=load_module('campaign003_runtime_system',HERE/'runtime.py')

class JournalView:
    def __init__(self,root):self.root=Path(root)
    @property
    def events(self):
        raw=(self.root/'public-history.jsonl').read_bytes()
        return [json.loads(line) for line in raw.splitlines(keepends=True) if line.endswith(b'\n')]

def approved_manifest(path):
    if path is None:raise RuntimeError('Campaign 003 awaits human review and final registration')
    path=Path(path);manifest=json.loads(path.read_text(encoding='utf-8'))
    if manifest.get('stage')!='reviewed_campaign' or not manifest.get('human_approval_reference'):
        raise RuntimeError('Campaign 003 awaits human review and final registration')
    snapshot=path.parent/manifest['source_snapshot_path']
    if sha(snapshot)!=manifest['source_snapshot_sha256']:raise ValueError('Final source snapshot identity mismatch')
    identities=json.loads(snapshot.read_text(encoding='utf-8'))
    for area in ('source','inherited'):
        for name,identity in identities[area].items():
            if sha(REPO/name)!=identity['sha256']:raise ValueError('Final source changed: '+name)
    return manifest

def run(output,reviewed_manifest=None):
    approval=approved_manifest(reviewed_manifest)
    out=Path(output).resolve();out.mkdir(parents=True,exist_ok=False)
    result={'passed':False,'model_calls_requested':0,'sessions':[],'stage_events':[]};block=guest=host=None;log=None
    try:
        manifest=approval['apparatus_manifest']
        save(out/'manifest.json',manifest)
        log=(out/'host-console.log').open('wb')
        host=subprocess.Popen([sys.executable,'-X','utf8','-B',str(HERE/'apparatus.py'),'--manifest',str(out/'manifest.json'),
            '--evidence',str(out/'host'),'--runtime-workspace',str(out/'public')],stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
        end=time.monotonic()+90;endpoint_path=out/'host/operator-endpoint.json'
        while not endpoint_path.is_file():
            if host.poll() is not None:raise RuntimeError('Host exited during initialization')
            if time.monotonic()>end:raise RuntimeError('Host initialization deadline')
            time.sleep(.1)
        ep=json.loads(endpoint_path.read_text());url=ep['url'];token=ep['capability']
        def op(path,body=None):
            code,value=runtime.request(url,token,'GET' if body is None else 'POST','/operator/'+path,body,operator=True)
            if code!=200 or not value.get('ok') or value.get('command',{}).get('status')=='rejected':raise RuntimeError(str(value))
            return value
        def wait(predicate,timeout=90):
            stop=time.monotonic()+timeout
            while time.monotonic()<stop:
                if host.poll() is not None:raise RuntimeError('Host exited during reviewed block')
                value=op('status')
                if predicate(value):return value
                time.sleep(.05)
            raise RuntimeError('Bounded state deadline')
        block=WorkspaceBlock.__new__(WorkspaceBlock)
        block.__init__(out/'workspace-block',runtime.template(),manifest['run_id'],approval['revision_id'],approval['source_snapshot_sha256'])
        count=0
        while True:
            status=op('status');order=status['packet']['order']
            if order['kind']=='C-placement':
                status=wait(lambda s:s['owner']=='robot')
                count+=1;sid=f'robot-session-{count}'
                started=op('start-invocation',{'request_id':'start-'+sid,'authority_epoch':status['authority_epoch'],'invocation_id':sid})
                robot_ep=started['endpoint'];session_root=out/sid
                status=op('status');files=runtime.template()
                files.update({'live/state.json':json.dumps(status),'live/activation.json':json.dumps(status['activation']),
                              'live/observations/latest.json':json.dumps(status['packet'])})
                guest=runtime.Runtime.__new__(runtime.Runtime)
                guest.__init__(session_root,files,robot_ep,block,sid,host_workspace=out/'public')
                from image_sensor import ImageSensor
                sensor=ImageSensor(out/'public',JournalView(out/'host'),manifest['run_id'],sid,robot_ep['authority_epoch'])
                guest.image_sensor=sensor
                guest.qualify()
                before=block.checkpoint('before-model-invocation',op('status')['packet']['sim_time'])
                result['model_calls_requested']+=1
                asyncio.run(guest.model(timeout=600,reviewed_campaign_authority=True))
                client=json.loads((session_root/'client/result.json').read_text())
                save(session_root/'bound-client-result.json',client)
                if not client.get('success') or not client.get('native_quiescence',{}).get('qualified'):
                    raise RuntimeError('Model invocation or native retirement unqualified; stop admission')
                registry=json.loads((out/'host/command-registry.json').read_text())
                accepted=[c for c in registry.values() if c['kind']=='handback' and c['status']=='completed'
                          and c['envelope']['authority_epoch']==robot_ep['authority_epoch']]
                if len(accepted)!=1:
                    result['task_failure']='No accepted handback after the bounded invocation'
                    raise RuntimeError('Bounded task not completed; stop block without replacement')
                hb=accepted[0]['request_id']
                wait(lambda s:op('terminal/'+hb)['resumed'] is not None)
                if not op('outcome')['outcome']['success']:
                    result['task_failure']='Handback lacks independent placement acceptance'
                    raise RuntimeError('Independent C task acceptance missing')
                receipts=op('terminal/'+hb)
                sensor.retired=True
                clean=guest.close();assert clean
                retire_files=list(session_root.glob('executor-*-retirement.json'))
                assert retire_files and not guest.abort_event.is_set()
                retirement={'run_id':manifest['run_id'],'session_id':sid,'all_namespaces_retired':True,
                            'evidence_sha256':hashlib.sha256(canonical({p.name:sha(p) for p in [*retire_files,session_root/'cleanup.json',session_root/'client/result.json']})).hexdigest()}
                save(session_root/'retirement-bound.json',retirement)
                current=op('status');op('retire-invocation',{'request_id':'retire-'+sid,'authority_epoch':current['authority_epoch'],'invocation_id':sid,'reason':'All prior runtime namespaces retired'})
                prior_note=linux("import pathlib,sys;sys.stdout.write(pathlib.Path(sys.argv[1]).read_text())",block.workspace+'/.continuity/Continuity.md')
                appended=block.terminal(receipts['accepted'],receipts['resumed'],retirement)
                note=linux("import pathlib,sys;sys.stdout.write(pathlib.Path(sys.argv[1]).read_text())",block.workspace+'/.continuity/Continuity.md')
                assert note.startswith(prior_note) and hashlib.sha256(note.encode()).hexdigest()==appended['after_sha256']
                op('framework-terminal',{'receipt':appended,'content':note})
                after=block.checkpoint('session-retired',op('status')['packet']['sim_time'])
                result['sessions'].append({'session_id':sid,'client_result_sha256':sha(session_root/'client/result.json'),'independent_success':True,'accepted_handback':hb,
                    'resumption':receipts['resumed'],'terminal_append':appended,'before':before,'after':after,
                    'image_deliveries_file':'host/image-views-'+sid+'.jsonl','clean_retirement':True})
                guest=None
            wait(lambda s:s['owner']=='conventional' and not s['active_command'] and op('outcome')['outcome']['success'])
            version=op('status')['order_version'];next_job=op('stage-next',{'request_id':'stage-after-'+str(version),'order_version':version})
            result['stage_events'].append(next_job)
            if next_job['block_complete']:break
            wait(lambda s:s['order_version']==next_job['order_version'])
        assert count==manifest['encounters']
        status=op('status');op('stop',{'request_id':'reviewed-block-finished','authority_epoch':status['authority_epoch'],'reason':'Reviewed block sequence complete'})
        assert host.wait(timeout=30)==0
        result['filesystem']=block.close();block=None
        host_result=json.loads((out/'host/result.json').read_text());result['host']=host_result
        from timing import verify_timing
        result['independent_timing_replay']=verify_timing(out/'host')
        result['passed']=host_result['execution_completed'] and host_result['timing_v2']['passed'] and result['filesystem']['passed']
    except Exception as e:result.update(error=str(e),traceback=traceback.format_exc())
    finally:
        if guest:
            try:result['failed_session_cleanup']=guest.close()
            except Exception as e:result['cleanup_error']=str(e)
        if host and host.poll() is None:
            try:
                status=op('status');op('stop',{'request_id':'qualification-abort','authority_epoch':status['authority_epoch'],'reason':'Block stopped on failure'})
                host.wait(timeout=30)
            except Exception as e:host.terminate();host.wait(timeout=10);result['host_forced_stop']=str(e)
        if block:
            try:result['failed_block_replay']=block.close()
            except Exception as e:result['block_cleanup_error']=str(e)
        if log:log.close()
        save(out/'receipt.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('host','sessions')}),flush=True)
    return 0 if result['passed'] else 1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('output');p.add_argument('--reviewed-manifest',type=Path);a=p.parse_args();raise SystemExit(run(a.output,a.reviewed_manifest))
