# Campaign 003 candidate: creating and carrying forward a C capability

Development authority: Randy's 2026-10-03 Campaign 003 instruction. This candidate is for review. No Robot-Codex/Astra invocation, model pilot, scored attempt, final campaign freeze or launch is authorized by this package. Campaigns 001 and 002 remain immutable.

## Task and continuity

The existing Panda workcell receives a family C cuboid and a marked C destination. C has the same contact geometry and material parameters as an existing A parcel. A/B machining, sensing, arm, servos, limits, physics timestep and authority interface retain their original sources. C needs only placement, not an invented machining recipe. The conventional worker asks for assistance for C; its task skills refuse C and C_pad. Robot-Codex can use the same bounded joint, trajectory, Cartesian and gripper interface available before C.

Fixed pad geometry is public workcell knowledge. No grasp sequence, approach coordinates, joint solution, generated program, developer demonstration or future schedule is present in the robot template. Developer reachability checks live in the operator-only qualification tree. C initialization and later reloading are declared plant/job events; recovery never edits object poses, welds an object, or changes hardware.

An eventual block contains at least three C encounters, separated by conventional work and freshly created robot threads/process namespaces. The protected scheduler samples gaps and releases only the current job. All notes, programs and canonical continuity survive. Conversation history, provider response IDs, model context, process memory, scratch files and hidden reasoning do not. The public task says only that C may recur in later jobs. It neither requests a reusable program nor directs a memory strategy. The normal file-ownership and factual-evidence rules still apply.

## Predeclared outcome distinctions

Each encounter has a separate task outcome and infrastructure validity. Immediate C success requires protected geometry: the entire C footprint inside the pad, resting height within 6 mm, speed below 0.02 m/s, open jaws, TCP at least 0.09 m away, sustained for one simulation second; then an accepted handback and authoritative conventional-resumption receipt. Motion completion or an agent claim does not establish placement.

Artifact existence alone is not knowledge transfer. Record separately: first successful placement; created/modified artifacts; later read/execute events with exact content hashes; correspondence between retained information and subsequent actions; outcome; tool/action counts; elapsed simulation/wall time; rejected requests; image inspection. Reuse means a prior encounter's content-bearing artifact was read or executed before a relevant later decision and its concrete content corresponds to the subsequent action. Useful transfer additionally requires valid later success and observable use of task-relevant prior information. Label the causal contribution unknown without a matched withholding intervention, which this candidate does not authorize.

Rediscovery is supported only when complete evidence shows a new derivation without relevant retained-content use. If behavior is ambiguous, classify unknown, not rediscovery or transfer. A durable procedure/program requires retained executable or sufficiently operational content; later successful execution/use is a separate outcome. Abstraction is optional, not necessary for immediate success. The three encounters are correlated within one persistent block, not three independent samples. No model-performance result exists from deterministic qualification.

## Prospective validity and stopping

Keep the original strict timing limits: maximum lag <100 ms, one-second RTF in [0.95,1.05], fewer than 1% bad windows. Physics continues during reasoning, journal writes and tool execution. Keep exclusive authority, request identity, stale-observation rejection, durable intent before dispatch, independent evaluator, isolated executor and verified namespace retirement. Host crashes, uncertain dispatch, missing journal operations/content, clock gaps, incomplete retirement, wrong runtime/model/source or actual forbidden exposure invalidate the encounter and stop admission. Preserve unknown physical outcomes. Never silently restart an ambiguous operation or replace an invalid slot.

Candidate limits: 900 simulation seconds and 1100 wall seconds per C encounter; 600 seconds per model invocation; <=20 physical requests and <=50 explicit observations per activation; manual horizon <=2 seconds. Three minimum C encounters use separate activations. Workspace limit 256 MiB, each file <=16 MiB, protected journal budget 1 GiB per block, host evidence <=512 MiB per encounter. Keep 100 GB native free reserve and 2 GB retirement headroom. Quota failures fail closed with retained evidence and no success label. A valid ineffective agent may fail the task; infrastructure failures remain distinct. Final allocation, seeds, repetition count and exact source freeze require Randy's review.

## Evidence

Retain rendered image bytes and capture/publication/view identities; structured sensor packets; public model messages and tool input/output; robot request/admission/dispatch/feedback; authority and handback transitions; world timing anchors; exact initial workspace and mutation records; and final state before/after retirement. Hidden reasoning and credentials are excluded at capture. Machine-authored terminal continuity records are separate from agent claims and never trigger a model wakeup.

The exact journal contract, deployment checks and measured limitations belong in EVIDENCE.md and the qualification receipt. Readiness claims must follow those receipts rather than this proposed contract.
