"""Receipt adversaries: no sockets, native processes, models or simulation."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import transport_integrity_v3 as subject


def raw_json(value):
    return json.dumps(value, indent=2).encode() + b'\n'


def stream(raw):
    return {'bytes': len(raw), 'sha256': subject.digest(raw)}


def h2(upload, download, active=False):
    return {'schema': 'campaign002-passive-h2-3', 'error': None,
            'preface_complete': True, 'settings_complete': True, 'frames_complete': True,
            'headers_complete': True, 'open_streams': int(active), 'closed_streams': int(not active),
            'reset_streams': 0, 'active_stream_ids': [1] if active else [], 'reset_records': [],
            'goaway': {'upload': None, 'download': None}, 'frames': {'upload': 2, 'download': 2},
            'bytes': {'upload': len(upload), 'download': len(download)}, 'max_streams': 1024}


class Fixture:
    def __init__(self, root, count=2):
        self.repo, self.stage = root / 'repo', root / 'stage'
        self.stage.mkdir(); (self.stage / 'client').mkdir()
        self.frozen = {'sources': {}}
        for name in subject.SOURCE_NAMES + (subject.PROBE_SOURCE_NAME, subject.PREFLIGHT_SOURCE_NAME, subject.BOUNDARY_SOURCE_NAME):
            p = self.repo / name; p.parent.mkdir(parents=True, exist_ok=True)
            raw = ('fixture source ' + name).encode(); p.write_bytes(raw)
            self.frozen['sources'][name] = stream(raw)
        self.sources = {name: self.frozen['sources'][name] for name in subject.BRIDGE_SOURCE_NAMES}
        self.inside = {name: self.frozen['sources'][subject.CAMPAIGN + 'harness/' + name]
                       for name in ('codehost_inside_v3.py', 'codehost_mux_protocol.py')}
        self.owner = {'schema': 'campaign002-native-owner-1', 'owner_kind': 'model_client',
                      'pid': 123, 'process_creation_filetime': 789,
                      'queried_executable_path': 'C:\\native\\codex.exe',
                      'executable': {'path': 'C:\\native\\codex.exe', 'sha256': 'a'*64,
                                     'bytes': 99, 'file_identity': [1, 2, 99, 456]},
                      'wall_unix_s': 10., 'monotonic_s': 10.}
        self.owner_bound = self.bind('codehost-native-owner-v3.json', raw_json(self.owner))
        self.ready = {'schema': 'campaign002-codehost-owner-ready-3', 'child_pid': 42,
                      'max_connections': 16, 'max_frame_bytes': 65536,
                      'per_channel_queue_bytes': 1048576, 'aggregate_queue_bytes': 4194304,
                      'sources': self.inside}
        self.parent, self.namespace, self.channels = [], [], []
        self.p('open', sources=self.sources, max_connections=16, max_frame_bytes=65536,
               per_channel_queue_bytes=1048576, aggregate_queue_bytes=4194304,
               framing_headroom_bytes=655360,subprocess_reader_limit=32768,client_socket_read_ahead_bytes=0)
        self.p('namespace_started')
        self.n('open', sources=self.inside, max_records=16384, max_metadata_bytes=1048576)
        self.n('child_started', child_pid=42)
        self.n('ready', receipt=self.ready)
        self.frame('incoming', 9, 0, subject.canonical(self.ready))
        self.p('listening', shared_child_pid=42, endpoint=['127.0.0.1', 5000])
        self.p('owner_registered', owner=self.owner, receipt=self.owner_bound)
        for cid in range(1, count+1):
            auth = {'schema': 'campaign002-channel-owner-1', 'owner_pid': 123,
                    'process_creation_filetime': 789, 'queried_executable_path': self.owner['queried_executable_path'],
                    'executable_sha256': 'a'*64, 'executable_file_identity': [1,2,99,456],
                    'client': ['127.0.0.1', 6000+cid], 'server': ['127.0.0.1', 5000], 'tcp_state': 5,
                    'lookup_attempts': 1, 'lookup_elapsed_s': .001,
                    'wall_unix_s': 11., 'monotonic_s': 11.}
            self.p('channel_authenticated', channel_id=cid, authentication=auth, owner_receipt=self.owner_bound)
            self.frame('outgoing', 1, cid)
            self.n('channel_open', channel_id=cid, child_pid=42)
            self.frame('incoming', 2, cid)
            active = cid == count
            flags = 4 if active else 5
            settings = b'\0\0\0\4\0\0\0\0\0'
            header = b'\0\0\0\1' + bytes([flags]) + b'\0\0\0\1'
            upload = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n' + settings + header
            download = settings + header
            self.frame('outgoing', 3, cid, upload); self.frame('incoming', 3, cid, download)
            witness = h2(upload, download, active)
            terminal = {'schema': 'campaign002-codehost-channel-3', 'channel_id': cid,
                        'qualified': True, 'reason': 'owner_finish' if active else 'clean_idle_eof',
                        'upload': stream(upload), 'download': stream(download), 'h2': witness,
                        'finish_frontier': copy.deepcopy(witness) if active else None,
                        'upload_eof_h2': None, 'download_eof_h2': None, 'error_type': None}
            meters = {'client_read': stream(upload), 'upload': stream(upload),
                      'download': stream(download), 'client_written': stream(download)}
            self.channels.append({'channel_id': cid, 'authentication': auth, 'namespace_closed': terminal,
                                  'meters': meters, 'h2': witness, 'parent_eof': None})
        for channel in self.channels[:-1]: self.close_channel(channel)
        self.finishing = self.p('owner_finishing', client_finishing=True,
                               authenticated_channels=count, attempts=count)
        self.frame('outgoing', 7, 0)
        self.p('owner_input_closed',after_finish_drain=True)
        self.n('owner_finish', channels=count)
        if self.channels: self.close_channel(self.channels[-1])
        for name in ('stdout', 'stderr'):
            self.n('child_diagnostic', stream=name, bytes=0, sha256=subject.digest(b''), truncated=False)
        self.finished = self.n('closed', qualified=True, reason='owner_finish', child_pid=42,
            child_exit_before_cleanup=None, child_exit_code=-15, terminate_sent=True, kill_sent=False,
            diagnostic_streams_complete=True, error_type=None, sources=self.inside,
            owner_finish_received=True, stdin_eof=True, owner_input_wait_bound_s=.5,
            channel_count=count, channels_closed=count, queue_bytes_at_close=0, queue_high_water_bytes=100,
            queue_headroom_bytes=196608, per_channel_queue_maximum_bytes={str(n):100 for n in range(1,count+1)},
            frame_counts={d: sum(x['kind']=='frame' and x['direction']==d for x in self.namespace)
                          for d in ('incoming','outgoing')})
        self.terminal = self.p('namespace_finished', finished=self.finished)
        self.p('namespace_output_closed',after_finished=True)
        self.p('retirement_started')
        self.p('closed', qualified=True, failures=[], accepted=count, denied=0, attempts=count)
        self.receipt = {'schema': 'campaign002-codehost-owner-bridge-3', 'qualified': True,
                        'sources': self.sources, 'exit_code': 0, 'owner_receipt': self.owner_bound,
                        'owner': self.owner, 'ready': self.ready, 'finished': self.finished,
                        'attempts': count, 'accepted': count, 'denied': 0,
                        'queue_maximum_bytes': 100, 'queued_bytes_at_close': 0,
                        'framing_headroom_bytes':655360,'queue_with_headroom_maximum_bytes':655460,
                        'per_channel_queue_maximum_bytes':{str(n):100 for n in range(1,count+1)},
                        'per_channel_with_headroom_maximum_bytes':{str(n):655460 for n in range(1,count+1)},
                        'channels': self.channels, 'failures': [], 'namespace_records': self.namespace}
        self.retirement = {'qualified': True, 'normal_wait_timed_out': False,
                           'windows_wrapper_killed_after_linux_retired': False, 'windows_exit_code': 0,
                           'observations': [{'retired': True, 'namespace_evidence_available': True,
                             'outer_same_process': False, 'namespace_members': [], 'namespace_ids': [987]}]}
        self.marker = {'kind': 'client_finishing_before_close', 'schema': 'campaign002-client-finishing-1',
                       'wall_unix_s': self.finishing['wall_unix_s']-.1,
                       'monotonic_s': self.finishing['monotonic_s']-.1}
        owner_raw = raw_json(self.owner)
        self.client = [{'kind': 'native_process_owner_registered', 'receipt_bytes': len(owner_raw),
                        'receipt_sha256': subject.digest(owner_raw)},
                       {'kind':'request','method':'initialize','id':1}, self.marker,
                       {'kind': 'client_shutdown', 'exit_code': 0}]

    def bind(self, name, raw):
        (self.stage/name).write_bytes(raw)
        return {'path': Path(name).name, **stream(raw)}

    def p(self, kind, **fields):
        row = {'kind': kind, 'wall_unix_s': 100.+len(self.parent), 'monotonic_s': 200.+len(self.parent), **fields}
        self.parent.append(row); return row

    def n(self, kind, **fields):
        row = {'kind':kind, 'schema':subject.NAMESPACE_SCHEMA, 'sequence':len(self.namespace)+1,
               'wall_unix_s':500.+len(self.namespace), 'monotonic_s':800.+len(self.namespace), **fields}
        self.namespace.append(row); return row

    def frame(self, direction, kind, cid, payload=b''):
        fields = {'frame_type':kind, 'channel_id':cid, 'payload_bytes':len(payload),
                  'payload_sha256':subject.digest(payload)}
        self.p('frame', direction=direction, **fields)
        self.n('frame', direction={'incoming':'outgoing','outgoing':'incoming'}[direction], **fields)

    def close_channel(self, channel):
        cid, closed = channel['channel_id'], channel['namespace_closed']
        self.n('channel_closed', channel_id=cid, receipt=closed)
        self.frame('incoming', 5, cid, subject.canonical(closed))
        self.p('channel_closed', channel_id=cid, namespace_closed=closed,
               meters=channel['meters'], h2=channel['h2'])

    def seal(self):
        previous = None
        for i,row in enumerate(self.parent,1):
            row.pop('record_sha256',None)
            row.update(schema=subject.TRANSPORT_SCHEMA,sequence=i,previous_sha256=previous)
            row['record_sha256']=subject.digest(subject.canonical(row));previous=row['record_sha256']

    def write(self):
        self.bind('client/native-owner.json',raw_json(self.owner))
        self.bind('client/events.jsonl',b''.join(subject.canonical(x)+b'\n' for x in self.client))
        self.bind('client/launch.json',raw_json({'binary':self.owner['executable']['path'],
              'binary_sha256':self.owner['executable']['sha256'],'bootstrap_requested':bool(self.channels)}))
        self.bind('client/result.json',raw_json({'model_started':bool(self.channels),'success':True}))
        stderr=b''.join(b'RCI_CODEHOST_V3 '+subject.canonical(x)+b'\n' for x in self.namespace)
        item=self.bind('codehost-owner-stderr-v3.txt',stderr)
        self.receipt['stderr']={**item,'raw_bytes':len(stderr),'raw_sha256':subject.digest(stderr),
                                'truncated':False,'redacted':False}
        self.receipt['retirement']=self.bind('codehost-owner-retirement-v3.json',raw_json(self.retirement))
        self.terminal.update(payload_bytes=len(subject.canonical(self.finished)),
                             payload_sha256=subject.digest(subject.canonical(self.finished)))
        self.parent[-1]['receipt']=self.bind('codehost-owner-bridge-v3.json',raw_json(self.receipt))
        self.seal();self.bind('codehost-transport-v3.jsonl',b''.join(subject.canonical(x)+b'\n' for x in self.parent))


def diagnostic_fixture(root, case):
    f=Fixture(root,count=0 if case=='foreign_owner' else 1)
    f.owner['owner_kind']='transport_probe'
    f.owner_bound.update(f.bind('codehost-native-owner-v3.json',raw_json(f.owner)))
    owner_raw=raw_json(f.owner)
    f.client[0].update(receipt_bytes=len(owner_raw),receipt_sha256=subject.digest(owner_raw))
    f.receipt.update(qualified=False,failures=['channel_OwnerError' if case=='foreign_owner' else 'channel_ValueError'])
    f.parent[-1].update(qualified=False,failures=f.receipt['failures'])
    if case=='foreign_owner':
        client,server=['127.0.0.1',6001],['127.0.0.1',5000]
        f.receipt.update(denied=1,attempts=1);f.parent[-1].update(denied=1,attempts=1)
        f.finishing['attempts']=1
        i=f.parent.index(f.finishing)
        f.parent[i:i]=[{'kind':'channel_denied','channel_id':1,'reason':'foreign_tcp_owner',
                       'client':client,'server':server}, {'kind':'failure','reason':'channel_OwnerError'}]
        sibling={key:copy.deepcopy(f.owner[key]) for key in
                 ('pid','process_creation_filetime','queried_executable_path','executable')}
        sibling.update(pid=124,process_creation_filetime=790)
        result={'ready_to_finish':True,'channels':[],'client':client,'server':server,
                'attempted_payload_bytes':0,'denial_eof_observed':True}
        injection={'sibling_process':sibling,'client':client,'server':server,
                   'attempted_payload_bytes':0,'denial_eof_observed':True}
    else:
        partial=b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'+b'\0\0\0\4\0\0\0\0\0'+b'\0\0\0\4\1\0\0\0\0'+b'\0\0\x08'
        sibling=None;channel=f.channels[0]
        value=channel['h2'];value.update(frames_complete=False,open_streams=0,active_stream_ids=[],closed_streams=0)
        value['bytes']['upload']=len(partial)
        for name in ('client_read','upload'):channel['meters'][name]=stream(partial)
        final=channel['namespace_closed'];final.update(qualified=False,reason='error',error_type='PartialHttp2',
                 upload=stream(partial),finish_frontier=copy.deepcopy(value))
        f.finished.update(qualified=False,reason='error',error_type='PartialHttp2')
        f.receipt['exit_code']=1;f.retirement['windows_exit_code']=1
        i=f.parent.index(f.finishing)
        eof={'kind':'client_eof','channel_id':1,'client_finishing':False,'h2':copy.deepcopy(value)}
        f.parent[i:i]=[eof,{'kind':'failure','reason':'channel_ValueError'}]
        channel['parent_eof']=eof
        for rows in (f.parent,f.namespace):
            for row in rows:
                if row['kind']=='frame' and row['frame_type']==3 and row['channel_id']==1:
                    upload=(row['direction']=='outgoing') if rows is f.parent else row['direction']=='incoming'
                    if upload:row.update(payload_bytes=len(partial),payload_sha256=subject.digest(partial))
                elif row['kind']=='frame' and row['frame_type']==5:
                    row.update(payload_bytes=len(subject.canonical(final)),payload_sha256=subject.digest(subject.canonical(final)))
        result={'ready_to_finish':True,'channels':[{'channel_id':1,'sent':stream(partial),'closed_before_finish':True}],
                'partial_header_bytes':3,'client_eof_before_owner_finish':True}
        injection={'channel_id':1,'fixed_upload_bytes':len(partial),'fixed_upload_sha256':subject.digest(partial),
                   'partial_header_bytes':3,'client_eof_before_owner_finish':True}
    for i,row in enumerate(f.parent):row.update(wall_unix_s=100.+i,monotonic_s=200.+i)
    f.marker.update(wall_unix_s=f.finishing['wall_unix_s']-.1,monotonic_s=f.finishing['monotonic_s']-.1)
    f.client[-1]={'kind':'probe_client_closed','schema':'campaign002-h2-probe-client-1','closed':True,
                  'wall_unix_s':f.marker['wall_unix_s']+1,'monotonic_s':f.marker['monotonic_s']+1}
    identity={key:copy.deepcopy(f.owner[key]) for key in
              ('pid','process_creation_filetime','queried_executable_path','executable')}
    client_result={'schema':'campaign002-channel-client-3','case':case,'completed':True,'owner':identity,
                   'sibling':sibling,'result':result,'child_exit_codes':{'owner':0},'finish':f.marker,'model_calls':0}
    if sibling:client_result['child_exit_codes']['foreign']=0
    transcript=[]
    def event(role,kind,offset,**fields):
        evt={'kind':kind,'wall_unix_s':f.marker['wall_unix_s']+offset,
             'monotonic_s':f.marker['monotonic_s']+offset,**fields}
        transcript.append({'schema':'campaign002-channel-probe-transcript-3','role':role,
                           'event':evt,'received_wall_unix_s':evt['wall_unix_s']+.01})
    event('owner','client_ready',-5,pid=123)
    if sibling:event('foreign','client_ready',-4,pid=124)
    event('foreign' if sibling else 'owner','ready_to_finish',-1,result=result)
    transcript.append({'schema':'campaign002-channel-probe-transcript-3','role':'controller',
                       'event':f.marker,'received_wall_unix_s':f.marker['wall_unix_s']+.01})
    for role in client_result['child_exit_codes']:
        event(role,'client_finishing',.1);event(role,'client_closed',.2)
    f.seal();f.write()
    tr=f.bind('client-transcript.jsonl',b''.join(subject.canonical(x)+b'\n' for x in transcript))
    cr=f.bind('client-result.json',raw_json(client_result))
    declaration={'schema':'campaign002-transport-v3-case-1','case':case,'owner_kind':'transport_probe','model_calls':0,
                 'physical_simulation':False,'expected_failure':True,'injection':injection,
                 'client_transcript':tr,'client_result':cr}
    f.bind('diagnostic-case.json',raw_json(declaration))
    return f,declaration


def positive_probe_fixture(root,case):
    f=Fixture(root,count=1 if case=='boundary_single_channel' else 3)
    f.owner['owner_kind']='transport_probe'
    f.owner_bound.update(f.bind('codehost-native-owner-v3.json',raw_json(f.owner)))
    owner_raw=raw_json(f.owner)
    f.client[0].update(receipt_bytes=len(owner_raw),receipt_sha256=subject.digest(owner_raw))
    f.client[-1]={'kind':'probe_client_closed','schema':'campaign002-h2-probe-client-1','closed':True,
                 'wall_unix_s':f.marker['wall_unix_s']+1,'monotonic_s':f.marker['monotonic_s']+1}
    identity={key:copy.deepcopy(f.owner[key]) for key in
              ('pid','process_creation_filetime','queried_executable_path','executable')}
    result={'ready_to_finish':True,'channels':[{'channel_id':ch['channel_id'],
              'client':ch['authentication']['client'],'server':ch['authentication']['server'],
              'sent':ch['meters']['client_read']} for ch in f.channels]}
    value={'schema':'campaign002-channel-client-3','case':case,'completed':True,'owner':identity,
           'sibling':None,'result':result,'child_exit_codes':{'owner':0},'finish':f.marker,'model_calls':0}
    transcript=[]
    for kind,offset,fields in [('client_ready',-5,{'pid':123}),('ready_to_finish',-1,{'result':result}),
                             ('client_finishing',.1,{}),('client_closed',.2,{})]:
        event={'kind':kind,'wall_unix_s':f.marker['wall_unix_s']+offset,
               'monotonic_s':f.marker['monotonic_s']+offset,**fields}
        transcript.append({'schema':'campaign002-channel-probe-transcript-3','role':'owner',
                           'event':event,'received_wall_unix_s':event['wall_unix_s']+.01})
    transcript.insert(2,{'schema':'campaign002-channel-probe-transcript-3','role':'controller',
                        'event':f.marker,'received_wall_unix_s':f.marker['wall_unix_s']+.01})
    f.write();f.bind('client-result.json',raw_json(value))
    f.bind('client-transcript.jsonl',b''.join(subject.canonical(x)+b'\n' for x in transcript))
    return f


class TransportV3Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.f=Fixture(Path(self.temp.name))
        self.repo=patch.object(subject,'REPO',self.f.repo);self.repo.start();self.addCleanup(self.repo.stop)

    def verify(self,**kwargs):
        return subject.verify_transport_integrity(self.f.stage,self.f.frozen,**kwargs)

    def fails(self,phrase):
        self.f.write()
        with self.assertRaisesRegex(ValueError,phrase):self.verify()

    def test_two_channels_one_child_and_exact_bytes(self):
        self.f.write();value=self.verify()
        self.assertTrue(value['passed']);self.assertEqual(value['accepted_count'],2)
        self.assertEqual(value['namespace']['child_pid'],42)
        self.assertIn('client/native-owner.json',value['input_bindings'])

    def test_empty_requires_explicit_source_bound_zero_model_preflight(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Fixture(Path(tmp),count=0);f.write()
            with patch.object(subject,'REPO',f.repo):
                with self.assertRaisesRegex(ValueError,'channel count'):subject.verify_transport_integrity(f.stage,f.frozen)
                self.assertTrue(subject.verify_transport_integrity(f.stage,f.frozen,allow_empty=True)['passed'])
                f.frozen['sources'].pop(subject.PREFLIGHT_SOURCE_NAME)
                with self.assertRaisesRegex(ValueError,'source differs'):subject.verify_transport_integrity(f.stage,f.frozen,allow_empty=True)

    def test_denial_cannot_be_laundered_by_clean_final_flag(self):
        self.f.parent[-1]['denied']=1;self.fails('channel count')

    def test_foreign_pid(self):
        self.f.channels[0]['authentication']['owner_pid']=124;self.fails('foreign')

    def test_reused_pid_creation(self):
        self.f.channels[0]['authentication']['process_creation_filetime']=790;self.fails('foreign')

    def test_same_binary_name_different_file(self):
        self.f.channels[0]['authentication']['executable_file_identity'][1]=99;self.fails('foreign')

    def test_wrong_server_tuple(self):
        self.f.channels[0]['authentication']['server'][1]=5001;self.fails('listener')

    def test_nonestablished_or_late_tcp_lookup(self):
        for key,val in [('tcp_state',2),('lookup_elapsed_s',.251),('lookup_attempts',True)]:
            with self.subTest(key=key):
                original=self.f.channels[0]['authentication'][key]
                self.f.channels[0]['authentication'][key]=val;self.fails('lookup')
                self.f.channels[0]['authentication'][key]=original

    def test_parent_stream_loss(self):
        self.f.channels[0]['meters']['client_written']['bytes']-=1;self.fails('original bytes')

    def test_endpoint_hash_mismatch(self):
        self.f.channels[0]['namespace_closed']['upload']['sha256']='b'*64;self.fails('original bytes')

    def test_partial_http2_final_frame(self):
        self.f.channels[-1]['h2']['frames_complete']=False;self.fails('completion')

    def test_inflight_idle_eof_not_waived_by_later_finish(self):
        ch=self.f.channels[0];ch['h2'].update(open_streams=1,active_stream_ids=[1]);self.fails('Early channel EOF')

    def test_prefinish_reset_cannot_be_laundered(self):
        frontier=self.f.channels[-1]['namespace_closed']['finish_frontier']
        frontier.update(reset_streams=1,reset_records=[{'direction':'upload','stream_id':1,'error_code':8}])
        self.fails('Earlier HTTP2 reset')

    def test_postfinish_reset_must_be_cancel_on_previous_active_stream(self):
        value=self.f.channels[-1]['h2'];value.update(reset_streams=1,reset_records=[{'direction':'upload','stream_id':3,'error_code':8}])
        self.fails('unexplained reset')

    def test_opaque_frame_hash_mismatch(self):
        row=next(x for x in self.f.namespace if x['kind']=='frame' and x['frame_type']==3)
        row['payload_sha256']='c'*64;self.fails('frame identities')

    def test_duplicate_namespace_child(self):
        self.f.namespace[2]['kind']='child_started';self.fails('duplicate host')

    def test_missing_namespace_eof(self):
        self.f.finished['stdin_eof']=False;self.fails('cleanup')

    def test_unclean_retirement(self):
        self.f.retirement['observations'][0]['namespace_members']=[{'pid':42}];self.fails('empty namespace')

    def test_source_drift(self):
        self.f.write();(self.f.repo/subject.SOURCE_NAMES[0]).write_text('changed')
        with self.assertRaisesRegex(ValueError,'source differs'):self.verify()

    def test_truncated_ledger(self):
        self.f.write();p=self.f.stage/'codehost-transport-v3.jsonl';p.write_bytes(p.read_bytes()[:-1])
        with self.assertRaisesRegex(ValueError,'truncated'):self.verify()

    def test_duplicate_json_key(self):
        with self.assertRaisesRegex(ValueError,'Malformed'):subject.decode(b'{"a":1,"a":2}','fixture')

    def test_boolean_byte_counter_rejected(self):
        self.f.channels[0]['meters']['client_read']['bytes']=True;self.fails('stream identity')

    def test_foreign_owner_kind_does_not_masquerade_as_native_client(self):
        self.f.owner['owner_kind']='transport_probe';self.fails('kind differs')

    def test_client_owner_receipt_hash_cannot_be_replaced(self):
        self.f.client[0]['receipt_sha256']='0'*64;self.fails('registration receipt differs')

    def test_marker_after_transport_finish_rejected(self):
        self.f.marker['monotonic_s']=10000.;self.fails('ordering differs')

    def test_pid_boolean_not_integer(self):
        self.f.owner['pid']=True;self.fails('identity or kind')

    def test_namespace_source_omission_rejected(self):
        self.f.inside.pop('codehost_inside_v3.py');self.fails('READY identity')

    def test_finish_without_stdin_eof_is_not_complete(self):
        self.f.finished.pop('stdin_eof');self.fails('cleanup')

    def test_original_byte_digest_substitution_without_chain_rehash(self):
        self.f.write();p=self.f.stage/'codehost-transport-v3.jsonl'
        raw=p.read_bytes();p.write_bytes(raw.replace(b'"pid":123',b'"pid":124',1))
        with self.assertRaisesRegex(ValueError,'hash or chain'):self.verify()

    def test_aggregate_queue_over_bound(self):
        self.f.receipt['queue_maximum_bytes']=4194305;self.fails('queued-byte')

    def test_additional_retired_namespace_is_not_one_host(self):
        self.f.retirement['observations'][0]['namespace_ids'].append(988);self.fails('More than one')

    def test_unknown_framing_type_not_silently_ignored(self):
        next(x for x in self.f.parent if x['kind']=='frame' and x['frame_type']==3)['frame_type']=10
        self.fails('Framing type')

    def test_data_before_acknowledgement_rejected(self):
        row=next(x for x in self.f.parent if x['kind']=='frame' and x['frame_type']==2)
        row.update(frame_type=3,payload_bytes=1,payload_sha256=subject.digest(b'x'))
        self.fails('DATA before OPENED')

    def test_bound_cancel_after_finish_frontier_is_allowed(self):
        frontier=copy.deepcopy(self.f.channels[-1]['namespace_closed']['finish_frontier'])
        final=copy.deepcopy(frontier)
        final.update(open_streams=0,active_stream_ids=[],reset_streams=1,
                     reset_records=[{'direction':'download','stream_id':1,'error_code':8}])
        subject.channel_h2(final,frontier)
        final['reset_records'][0]['error_code']=2
        with self.assertRaisesRegex(ValueError,'unexplained reset'):subject.channel_h2(final,frontier)

    def test_extra_legacy_host_retirement_rejected(self):
        self.f.write();self.f.bind('codehost-1-retirement.json',raw_json(self.f.retirement))
        with self.assertRaisesRegex(ValueError,'Additional'):self.verify()

    def test_missing_framed_output_eof_rejected(self):
        next(x for x in self.f.parent if x['kind']=='namespace_output_closed')['after_finished']=False
        self.fails('framing EOF')

    def test_per_channel_headroom_is_within_original_limit(self):
        self.f.receipt['per_channel_queue_maximum_bytes']['1']=400000
        self.fails('Per-channel queue')

    def test_expected_failure_diagnostics_cannot_be_production_passes(self):
        for case in ('foreign_owner','in_flight_eof'):
            with self.subTest(case=case),tempfile.TemporaryDirectory() as tmp:
                f,_=diagnostic_fixture(Path(tmp),case)
                with patch.object(subject,'REPO',f.repo):
                    value=subject.verify_expected_failure(f.stage,f.frozen,case=case)
                    self.assertTrue(value['expected_failure_verified']);self.assertNotIn('passed',value)
                    self.assertFalse(value['ordinary_transport_passed'])
                    with self.assertRaises(ValueError):subject.verify_transport_integrity(f.stage,f.frozen,owner_kind='transport_probe')

    def test_expected_inflight_failure_rejects_fabricated_input_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            f,declaration=diagnostic_fixture(Path(tmp),'in_flight_eof')
            declaration['injection']['fixed_upload_sha256']='f'*64
            f.bind('diagnostic-case.json',raw_json(declaration))
            with patch.object(subject,'REPO',f.repo),self.assertRaisesRegex(ValueError,'45-byte'):
                subject.verify_expected_failure(f.stage,f.frozen,case='in_flight_eof')

    def test_foreign_owner_diagnostic_rejects_registered_pid(self):
        with tempfile.TemporaryDirectory() as tmp:
            f,declaration=diagnostic_fixture(Path(tmp),'foreign_owner')
            declaration['injection']['sibling_process']['pid']=f.owner['pid']
            f.bind('diagnostic-case.json',raw_json(declaration))
            with patch.object(subject,'REPO',f.repo),self.assertRaisesRegex(ValueError,'separately identified'):
                subject.verify_expected_failure(f.stage,f.frozen,case='foreign_owner')

    def test_foreign_owner_requires_specific_producer_exception(self):
        with tempfile.TemporaryDirectory() as tmp:
            f,_=diagnostic_fixture(Path(tmp),'foreign_owner')
            f.receipt['failures']=['channel_ValueError']
            f.parent[-1]['failures']=f.receipt['failures']
            next(row for row in f.parent if row['kind']=='failure')['reason']='channel_ValueError'
            f.write()
            with patch.object(subject,'REPO',f.repo),self.assertRaisesRegex(ValueError,'unrelated failures'):
                subject.verify_expected_failure(f.stage,f.frozen,case='foreign_owner')

    def test_declared_probe_cases_and_boundary_source_binding(self):
        for case in ('multi_channel','boundary_single_channel'):
            with self.subTest(case=case),tempfile.TemporaryDirectory() as tmp:
                f=positive_probe_fixture(Path(tmp),case)
                with patch.object(subject,'REPO',f.repo):
                    value=subject.verify_transport_integrity(f.stage,f.frozen,owner_kind='transport_probe')
                    self.assertTrue(value['passed'])
                    self.assertEqual(subject.BOUNDARY_SOURCE_NAME in value['source_bindings'],case=='boundary_single_channel')
                    if case=='boundary_single_channel':
                        f.frozen['sources'].pop(subject.BOUNDARY_SOURCE_NAME)
                        with self.assertRaisesRegex(ValueError,'Boundary transport source differs'):
                            subject.verify_transport_integrity(f.stage,f.frozen,owner_kind='transport_probe')

    def test_probe_foreign_transcript_pid_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=positive_probe_fixture(Path(tmp),'boundary_single_channel')
            p=f.stage/'client-transcript.jsonl';raw=p.read_bytes();p.write_bytes(raw.replace(b'"pid":123',b'"pid":124',1))
            with patch.object(subject,'REPO',f.repo),self.assertRaisesRegex(ValueError,'Probe child identity'):
                subject.verify_transport_integrity(f.stage,f.frozen,owner_kind='transport_probe')

    def test_native_initialization_cannot_precede_owner_registration(self):
        self.f.client[0],self.f.client[1]=self.f.client[1],self.f.client[0]
        self.fails('Native initialization')


if __name__=='__main__':unittest.main()
