"""Three fixed no-model channel diagnostics; never launch during unit tests.

Only the explicit CLI runner creates Runtime/native fixtures. assess() is an
independent read-only replay, called after the external official queue gate.
"""
import argparse
import asyncio
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import socket
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit

HERE = Path(__file__).resolve().parent
CAMPAIGN = HERE.parent
REPO = HERE.parents[3]
SCHEMA = 'campaign002-codehost-channel-probe-3'
CASES = ('multi_channel','foreign_owner','in_flight_eof')
CASE_CAP_SECONDS = 180
IDLE_SECONDS = 95
CASE_BYTES = 32 * 1024 * 1024
CLIENT_BYTES = 1024 * 1024
PREFACE = b'PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n'
SETTINGS = b'\x00\x00\x00\x04\x00\x00\x00\x00\x00'
SETTINGS_ACK = b'\x00\x00\x00\x04\x01\x00\x00\x00\x00'
PARTIAL = b'\x00\x00\x08'
PARTIAL_INPUT = PREFACE + SETTINGS + SETTINGS_ACK + PARTIAL


def require(value, message):
    if value is not True: raise ValueError(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',', ':'),allow_nan=False).encode()


def digest(raw): return hashlib.sha256(raw).hexdigest()


def binding(path):
    raw=Path(path).read_bytes();return {'sha256':digest(raw),'bytes':len(raw)}


def save(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,indent=2,allow_nan=False)+'\n');stream.flush();os.fsync(stream.fileno())


def append(path,value):
    with Path(path).open('ab') as stream:
        stream.write(canonical(value)+b'\n');stream.flush();os.fsync(stream.fileno())


def dependency(name):
    for directory in (HERE,CAMPAIGN/'assessment'):
        if str(directory) not in sys.path:sys.path.insert(0,str(directory))
    return __import__(name)


def make_cases():
    return [{'case':name,'maximum_elapsed_seconds':CASE_CAP_SECONDS,'maximum_output_bytes':CASE_BYTES,
             'model_calls':0,'physical_simulation':False,'expected_failure':name!='multi_channel',
             'minimum_idle_seconds':IDLE_SECONDS if name=='multi_channel' else None}
            for name in CASES]


def required_sources():
    paths=dependency('raw_event_preflight_v2').required_sources()
    extra=[HERE/'codehost_transport_probe_v3.py',HERE/'test_codehost_transport_probe_v3.py',
           HERE/'test_codehost_owner.py',HERE/'test_codehost_bridge_v3.py',
           HERE/'test_codehost_mux_protocol.py',HERE/'test_codehost_inside_v3.py',
           CAMPAIGN/'assessment/test_transport_integrity_v3.py']
    return sorted(set(paths+[p.relative_to(REPO).as_posix() for p in extra]))


def validate_snapshot(snapshot,revision=None):
    frozen=dependency('raw_event_preflight_v2').validate_snapshot(snapshot,revision)
    for name in required_sources():
        p=REPO/name
        require(p.is_file() and not p.is_symlink() and frozen.get('sources',{}).get(name)==binding(p),
                'Missing or changed channel-probe source: '+name)
    return frozen


def frame(kind,flags=0,payload=b''):
    return len(payload).to_bytes(3,'big')+bytes([kind,flags])+b'\0'*4+payload


class SyntheticChannel:
    def __init__(self,port,channel_id,emit):
        self.id=channel_id;self.emit=emit
        self.sock=socket.create_connection(('127.0.0.1',port),8);self.sock.settimeout(8)
        self.sent=self.received=0;self.tx=hashlib.sha256();self.rx=hashlib.sha256()
        self.client=list(self.sock.getsockname());self.server=list(self.sock.getpeername())
        self.frames=[];self.closed=False
        emit('channel_connected',channel_id=self.id,client=self.client,server=self.server)

    def send(self,raw):
        self.sock.sendall(raw);self.sent+=len(raw);self.tx.update(raw)

    def exact(self,count):
        out=bytearray()
        while len(out)<count:
            value=self.sock.recv(count-len(out))
            if not value:raise ValueError('Synthetic H2 peer EOF')
            out.extend(value);self.received+=len(value);self.rx.update(value)
        return bytes(out)

    def read_frame(self):
        header=self.exact(9);length=int.from_bytes(header[:3],'big')
        require(length<=65536 and int.from_bytes(header[5:],'big')==0,'Unexpected synthetic H2 frame')
        payload=self.exact(length)
        require(header[3] in (4,6,7,8),'Unexpected synthetic H2 application frame')
        self.frames.append({'type':header[3],'flags':header[4],'bytes':length,'sha256':digest(payload)})
        require(len(self.frames)<=32,'Synthetic frame-count bound')
        return header[3],header[4],payload

    def handshake(self,ping):
        self.send(PREFACE+SETTINGS)
        kind,flags,payload=self.read_frame()
        require(kind==4 and flags==0 and len(payload)%6==0,'Native SETTINGS absent')
        self.send(SETTINGS_ACK)
        got_ack=False;got_ping=not ping
        marker=b'C02V3H2!'
        if ping:self.send(frame(6,payload=marker))
        for _ in range(12):
            kind,flags,payload=self.read_frame()
            if kind==4 and flags==1 and not payload:got_ack=True
            elif kind==6 and flags==1 and payload==marker:got_ping=True
            elif kind==8 and len(payload)==4:pass
            else:raise ValueError('Unexpected synthetic H2 handshake')
            if got_ack and got_ping:break
        require(got_ack and got_ping,'Incomplete synthetic H2 handshake')
        self.emit('channel_handshake',channel_id=self.id,ping_acknowledged=ping)

    def close_idle(self):
        self.sock.shutdown(socket.SHUT_WR)
        while value:=self.sock.recv(65536):
            self.received+=len(value);self.rx.update(value)
            require(self.received<=CLIENT_BYTES,'Synthetic peer byte bound')
        self.sock.close();self.closed=True
        self.emit('channel_closed',channel_id=self.id,clean_idle=True)

    def summary(self):
        return {'channel_id':self.id,'client':self.client,'server':self.server,
                'sent':{'bytes':self.sent,'sha256':self.tx.hexdigest()},
                'received':{'bytes':self.received,'sha256':self.rx.hexdigest()},
                'closed_before_finish':self.closed,'frames':list(self.frames)}


def client_main(mode):
    """Fixed trusted Python client; stdin control only supplies a private port."""
    def emit(kind,**value):
        print(canonical({'kind':kind,'wall_unix_s':time.time(),'monotonic_s':time.monotonic(),**value}).decode(),flush=True)
    require(mode in (*CASES,'hold','foreign','boundary_single_channel'),'Unknown fixed client mode')
    emit('client_ready',pid=os.getpid(),mode=mode)
    command=json.loads(sys.stdin.readline(1024))
    require(set(command)=={'port'} and type(command['port']) is int and 0<command['port']<65536,'Fixed client port control')
    channels=[];result={'ready_to_finish':True,'channels':[]}
    try:
        if mode=='hold':pass
        elif mode=='foreign':
            sock=socket.create_connection(('127.0.0.1',command['port']),8);sock.settimeout(8)
            client,server=list(sock.getsockname()),list(sock.getpeername())
            emit('foreign_connected',client=client,server=server,attempted_payload_bytes=0)
            denied=sock.recv(1)==b'';sock.close()
            require(denied,'Foreign owner was not denied before payload')
            result.update(client=client,server=server,attempted_payload_bytes=0,denial_eof_observed=True)
            emit('foreign_denied',**result)
        else:
            channel=SyntheticChannel(command['port'],1,emit);channels.append(channel)
            channel.handshake(ping=mode in ('multi_channel','boundary_single_channel'))
            if mode=='multi_channel':
                started=time.monotonic();emit('idle_started',channel_id=1)
                time.sleep(IDLE_SECONDS);result['idle_seconds']=time.monotonic()-started
                emit('idle_finished',channel_id=1,elapsed_seconds=result['idle_seconds'])
                second=SyntheticChannel(command['port'],2,emit);channels.append(second);second.handshake(True);second.close_idle()
                third=SyntheticChannel(command['port'],3,emit);channels.append(third);third.handshake(True)
            elif mode=='boundary_single_channel':
                started=time.monotonic();emit('idle_started',channel_id=1)
                time.sleep(1);result['idle_seconds']=time.monotonic()-started
                emit('idle_finished',channel_id=1,elapsed_seconds=result['idle_seconds'])
            elif mode=='in_flight_eof':
                channel.send(PARTIAL);emit('partial_frame_sent',channel_id=1,bytes=len(PARTIAL),sha256=digest(PARTIAL))
                channel.sock.shutdown(socket.SHUT_WR)
                emit('client_eof_before_owner_finish',channel_id=1)
                while value:=channel.sock.recv(65536):
                    channel.received+=len(value);channel.rx.update(value)
                    require(channel.received<=CLIENT_BYTES,'Synthetic peer byte bound')
                channel.sock.close();channel.closed=True
                result.update(partial_header_bytes=3,client_eof_before_owner_finish=True)
            else:raise ValueError('Unknown fixed client mode')
            result['channels']=[c.summary() for c in channels]
        emit('ready_to_finish',result=result)
        require(json.loads(sys.stdin.readline(1024))=={'finish':True},'Fixed client finish control')
        emit('client_finishing')
        for channel in channels:
            if not channel.closed:channel.sock.close();channel.closed=True
        emit('client_closed')
        return 0
    finally:
        for channel in channels:
            channel.sock.close()


class ChildLog:
    def __init__(self,process,role,transcript,lock):
        self.process,self.role=process,role
        self.queue=queue.Queue(maxsize=128);self.bytes=0;self.error=None
        self.stderr=bytearray()
        def stdout():
            try:
                while raw:=process.stdout.readline(16385):
                    require(len(raw)<=16384 and raw.endswith(b'\n'),'Incomplete/bounded probe client line')
                    self.bytes+=len(raw);require(self.bytes<=CLIENT_BYTES,'Probe client output bound')
                    event=json.loads(raw)
                    require(isinstance(event,dict),'Probe client event type')
                    row={'schema':'campaign002-channel-probe-transcript-3','role':role,'event':event,'received_wall_unix_s':time.time()}
                    with lock:append(transcript,row)
                    self.queue.put_nowait(event)
            except BaseException as error:self.error=type(error).__name__
        def stderr():
            try:
                while raw:=process.stderr.read(65536):
                    require(len(self.stderr)+len(raw)<=CLIENT_BYTES,'Probe child stderr bound')
                    self.stderr.extend(raw)
            except BaseException as error:self.error=type(error).__name__
        self.workers=[threading.Thread(target=fn,daemon=True) for fn in (stdout,stderr)]
        for worker in self.workers:worker.start()

    async def event(self,kind,deadline):
        while time.monotonic()<deadline:
            if self.error:raise ValueError(self.error)
            try:value=self.queue.get_nowait()
            except queue.Empty:
                if self.process.poll() is not None:raise ValueError('Probe process exited before '+kind)
                await asyncio.sleep(.01);continue
            if value.get('kind')==kind:return value
        raise TimeoutError('Probe client deadline')

    def finish(self):
        for worker in self.workers:worker.join(timeout=2)
        require(not any(w.is_alive() for w in self.workers) and self.error is None,'Incomplete probe client drains')
        require(not self.stderr,'Unexpected probe client stderr')


async def drive_clients(url,runtime,case,deadline):
    require(case in (*CASES,'boundary_single_channel'),'Undeclared client workload')
    require(time.monotonic()<deadline-35,'No bounded client/cleanup time remaining')
    if case=='multi_channel':require(time.monotonic()+IDLE_SECONDS<deadline-35,'No declared idle interval budget')
    root=Path(runtime.evidence);(root/'client').mkdir(exist_ok=False)
    transcript=root/'client-transcript.jsonl';lock=threading.Lock()
    children=[];logs=[];identities={};result=None;finish=None
    owner_api=dependency('codehost_owner')
    port=urlsplit(url).port
    require(url.startswith('http://127.0.0.1:') and type(port) is int,'Fixed bridge endpoint')
    def start(role,mode):
        process=subprocess.Popen([sys.executable,'-X','utf8','-B',str(Path(__file__).resolve()),'--client',mode],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        children.append(process)
        observed=owner_api.WindowsOwnerAPI().process(process.pid)
        observed['executable']=owner_api.file_identity(sys.executable)
        identities[role]=observed
        log=ChildLog(process,role,transcript,lock);logs.append(log)
        return process,log
    def control(process,value):
        process.stdin.write(canonical(value)+b'\n');process.stdin.flush()
    try:
        owner,owner_log=start('owner','hold' if case=='foreign_owner' else case)
        owner_receipt=runtime.native_process_ready(owner,sys.executable)
        save(root/'client/native-owner.json',owner_receipt)
        owner_binding=binding(root/'client/native-owner.json')
        append(root/'client/events.jsonl',{'kind':'native_process_owner_registered',
            'receipt_sha256':owner_binding['sha256'],'receipt_bytes':owner_binding['bytes']})
        await owner_log.event('client_ready',deadline-35)
        control(owner,{'port':port})
        active_log=owner_log
        if case=='foreign_owner':
            await owner_log.event('ready_to_finish',deadline-35)
            sibling,sibling_log=start('foreign','foreign')
            await sibling_log.event('client_ready',deadline-35)
            control(sibling,{'port':port});active_log=sibling_log
        result=(await active_log.event('ready_to_finish',deadline-35))['result']
    finally:
        finish={'kind':'client_finishing_before_close','schema':'campaign002-client-finishing-1',
                'wall_unix_s':time.time(),'monotonic_s':time.monotonic()}
        append(root/'client/events.jsonl',finish)
        with lock:append(transcript,{'schema':'campaign002-channel-probe-transcript-3','role':'controller','event':finish,'received_wall_unix_s':time.time()})
        runtime.client_finishing.set()
        for process in children:
            if process.poll() is None:
                try:control(process,{'finish':True})
                except (BrokenPipeError,OSError):pass
        for process in children:
            try:await asyncio.to_thread(process.wait,timeout=3)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:await asyncio.to_thread(process.wait,timeout=3)
                except subprocess.TimeoutExpired:process.kill();await asyncio.to_thread(process.wait,timeout=3)
        for log in logs:log.finish()
        exits={log.role:log.process.returncode for log in logs}
        append(root/'client/events.jsonl',{'kind':'probe_client_closed','schema':'campaign002-h2-probe-client-1',
            'closed':bool(children) and all(type(v)is int and v==0 for v in exits.values()),
            'wall_unix_s':time.time(),'monotonic_s':time.monotonic()})
        record={'schema':'campaign002-channel-client-3','case':case,'completed':result is not None and all(type(v)is int and v==0 for v in exits.values()),
                'owner':identities.get('owner'),'sibling':identities.get('foreign'),'result':result,
                'child_exit_codes':exits,'finish':finish,'model_calls':0}
        save(root/'client-result.json',record)
    require(record['completed'],'Fixed synthetic client did not complete')
    injection={}
    if case=='foreign_owner':
        injection={'sibling_process':identities['foreign'],'client':result['client'],'server':result['server'],
                   'attempted_payload_bytes':0,'denial_eof_observed':result['denial_eof_observed']}
    elif case=='in_flight_eof':
        injection={'channel_id':1,'fixed_upload_bytes':len(PARTIAL_INPUT),'fixed_upload_sha256':digest(PARTIAL_INPUT),
                   'partial_header_bytes':3,'client_eof_before_owner_finish':result['client_eof_before_owner_finish']}
    save(root/'diagnostic-case.json',{'schema':'campaign002-transport-v3-case-1','case':case,'owner_kind':'transport_probe',
        'model_calls':0,'physical_simulation':False,'expected_failure':case in ('foreign_owner','in_flight_eof'),'injection':injection,
        'client_transcript':{'path':'client-transcript.jsonl',**binding(transcript)},
        'client_result':{'path':'client-result.json',**binding(root/'client-result.json')}})
    return record


async def boundary_probe(fixture):
    """One fixed H2 channel; caller independently verifies and retires Runtime."""
    fixture.native_owner_kind='transport_probe'
    started=time.monotonic()
    async def callback(url):
        return await drive_clients(url,fixture,'boundary_single_channel',started+CASE_CAP_SECONDS)
    record=await dependency('codehost_bridge_v3').run(fixture,callback)
    require(record.get('completed')is True and time.monotonic()-started<=CASE_CAP_SECONDS,
            'Boundary channel diagnostic incomplete or over cap')
    result=record['result']
    require(len(result['channels'])==1 and result['idle_seconds']>=1,'Boundary fixed workload absent')
    return {'qualified':True,'schema':'campaign002-boundary-channel-probe-3','model_calls':0,
            'physical_simulation':False,'case':'boundary_single_channel',
            'client_result':{'path':'client-result.json',**binding(Path(fixture.evidence)/'client-result.json')},
            'client_transcript':{'path':'client-transcript.jsonl',**binding(Path(fixture.evidence)/'client-transcript.jsonl')},
            'scope':'Fixed authenticated H2 settings/PING channel; no model, gRPC tool call or physical simulation.'}


def run_case(root,case):
    runtime_module=dependency('runtime')
    runtime=runtime_module.Runtime.__new__(runtime_module.Runtime)
    started=time.monotonic();wall=time.time();deadline=started+CASE_CAP_SECONDS
    outcome={'schema':'campaign002-channel-case-run-3','case':case,'start_wall_unix_s':wall,
             'start_monotonic_s':started,'case_cap_seconds':CASE_CAP_SECONDS,'cleanup_clean':False,
             'bridge_completed':False,'bridge_error_type':None,'setup_error_type':None}
    try:
        runtime_module.Runtime.__init__(runtime,root,runtime_module.template('bootstrap'))
        runtime.native_owner_kind='transport_probe'
        runtime.qualify();outcome['canaries_completed']=True
        require(time.monotonic()<deadline-35,'Diagnostic setup exhausted case budget')
        async def callback(url):return await drive_clients(url,runtime,case,deadline)
        try:
            asyncio.run(dependency('codehost_bridge_v3').run(runtime,callback))
            outcome['bridge_completed']=True
        except Exception as error:outcome['bridge_error_type']=type(error).__name__
    except Exception as error:outcome['setup_error_type']=type(error).__name__
    finally:
        try:outcome['cleanup_clean']=runtime.close()
        except Exception as error:outcome['cleanup_error_type']=type(error).__name__
        outcome.update(end_monotonic_s=time.monotonic(),end_wall_unix_s=time.time())
        outcome['elapsed_seconds']=outcome['end_monotonic_s']-started
        if root.exists():save(root/'case-run.json',outcome)
    return outcome


def canary_evidence(reader,prefix):
    canary=reader.json(prefix+'/canary-stdout.json')
    require(canary.get('qualified')is True and len(canary.get('checks',{}))==45
            and all(value is True for value in canary['checks'].values()),'Unchanged boundary canaries incomplete')
    host=reader.json(prefix+'/codehost-canary-stdout.json');checks=host.get('checks',{})
    require(host.get('host_qualified')is True and type(host.get('model_calls'))is int and host['model_calls']==0
            and host.get('enabled_tools')==[] and checks.get('tools')==[]
            and type(checks.get('all_tools_count'))is int and checks['all_tools_count']==0
            and checks.get('constructor_process_type')=='undefined'
            and set(checks.get('apis',{}))=={'process','require','fetch','Deno','Bun','WebSocket','XMLHttpRequest'}
            and all(v=='undefined' for v in checks['apis'].values())
            and set(checks.get('imports',{}))=={'node:fs','file:///etc/passwd','https://example.invalid/'}
            and all(v=='denied' for v in checks['imports'].values()),'Unchanged codehost canaries incomplete')


def assess(output,snapshot):
    output=Path(output).resolve();snapshot=Path(snapshot).resolve()
    reader=dependency('raw_event_preflight_v2').Reader(output)
    errors={};checks={};cases=[];source={};frozen={}
    try:
        source=reader.json('source-binding.json');frozen=validate_snapshot(snapshot,source.get('framework_revision'))
        require(source.get('schema')=='campaign002-channel-probe-source-3' and source.get('snapshot_sha256')==binding(snapshot)['sha256']
                and canonical(source.get('cases'))==canonical(make_cases()) and type(source.get('model_calls'))is int and source['model_calls']==0
                and source.get('physical_simulation')is False and canonical(source.get('source_bindings'))==canonical(frozen['sources'])
                and isinstance(source.get('run_id'),str) and bool(source['run_id']),
                'Probe source/declaration binding differs')
        checks['source_identity']=True
    except Exception as error:checks['source_identity']=False;errors['source_identity']=str(error)
    if checks['source_identity']:
        verifier=dependency('transport_integrity_v3')
        for name in CASES:
            row={'case':name,'passed':False,'production_qualified':False}
            try:
                folder=output/name
                require(folder.is_dir() and not folder.is_symlink(),'Missing ordinary case directory')
                files=list(folder.rglob('*'))
                require(all(not p.is_symlink() for p in files),'Linked case evidence')
                require(sum(p.stat().st_size for p in files if p.is_file())<=CASE_BYTES,'Case output bound')
                run=reader.json(name+'/case-run.json');client=reader.json(name+'/client-result.json')
                cleanup=reader.json(name+'/cleanup.json')
                canary_evidence(reader,name)
                require(run.get('schema')=='campaign002-channel-case-run-3' and run.get('case')==name
                        and run.get('cleanup_clean')is True and cleanup.get('clean')is True and cleanup.get('errors')==[]
                        and run.get('setup_error_type')is None and run.get('canaries_completed')is True,
                        'Case setup/cleanup failed')
                elapsed=run.get('elapsed_seconds')
                require(type(elapsed) in (int,float) and math.isfinite(elapsed) and 0<elapsed<=CASE_CAP_SECONDS
                        and elapsed==run['end_monotonic_s']-run['start_monotonic_s'],'Case time cap')
                require(client.get('schema')=='campaign002-channel-client-3' and client.get('case')==name
                        and client.get('completed')is True and type(client.get('model_calls'))is int and client['model_calls']==0
                        and set(client.get('child_exit_codes',{}))==({'owner','foreign'} if name=='foreign_owner' else {'owner'})
                        and all(type(v)is int and v==0 for v in client.get('child_exit_codes',{}).values()),'Client completion identity')
                if name=='multi_channel':
                    proof=verifier.verify_transport_integrity(folder,frozen,owner_kind='transport_probe')
                    require(proof.get('passed')is True and run.get('bridge_completed')is True and run.get('bridge_error_type')is None,
                            'Ordinary three-channel transport did not pass')
                    idle=client['result']['idle_seconds'];channels=client['result']['channels']
                    require(type(idle)in(int,float) and math.isfinite(idle) and idle>=IDLE_SECONDS
                            and [c['channel_id'] for c in channels]==[1,2,3]
                            and channels[1].get('closed_before_finish')is True
                            and channels[0].get('closed_before_finish')is False
                            and channels[2].get('closed_before_finish')is False,'Fixed multi-channel workload absent')
                    receipt=reader.json(name+'/codehost-owner-bridge-v3.json')
                    require(type(receipt.get('accepted'))is int and receipt['accepted']==3
                            and type(receipt.get('denied'))is int and receipt['denied']==0,'Three authenticated channels absent')
                    raw=reader.raw(name+'/codehost-transport-v3.jsonl')
                    require(raw.endswith(b'\n'),'Incomplete transport ledger')
                    events=[json.loads(line) for line in raw.splitlines()]
                    accepted=[e for e in events if e.get('kind')=='channel_authenticated']
                    closed=[e for e in events if e.get('kind')=='channel_closed']
                    require([e['channel_id'] for e in accepted]==[1,2,3],'Admission order differs')
                    close_by_id={e['channel_id']:e for e in closed}
                    require(accepted[1]['monotonic_s']-accepted[0]['monotonic_s']>=IDLE_SECONDS
                            and close_by_id[2]['monotonic_s']<accepted[2]['monotonic_s']<close_by_id[1]['monotonic_s'],
                            'Long-lived first channel or close-then-open sequence absent')
                    require(next(c for c in receipt['channels'] if c['channel_id']==2)['namespace_closed']['reason']=='clean_idle_eof',
                            'Second channel did not close cleanly before finish')
                    row['production_qualified']=True
                else:
                    proof=verifier.verify_expected_failure(folder,frozen,case=name)
                    require(proof.get('expected_failure_verified')is True and proof.get('diagnostic_only')is True
                            and proof.get('ordinary_transport_passed')is False and run.get('bridge_completed')is False
                            and run.get('bridge_error_type')=='RuntimeError','Expected failure not independently established')
                require(isinstance(proof.get('input_bindings'),dict) and bool(proof['input_bindings']),
                        'Dependent transport proof lacks evidence bindings')
                for path,expected in proof['input_bindings'].items():
                    raw=reader.raw(name+'/'+path)
                    require({'sha256':digest(raw),'bytes':len(raw)}==expected,'Dependent transport proof changed')
                row.update(passed=True,elapsed_seconds=elapsed,transport_proof=proof)
            except Exception as error:row['error']=str(error);errors[name]=str(error)
            cases.append(row)
    checks['three_fixed_cases']=len(cases)==3 and [c['case'] for c in cases]==list(CASES)
    checks['all_cases_verified']=checks['three_fixed_cases'] and all(c['passed']is True for c in cases)
    return {'schema':SCHEMA,'passed':all(checks.values()),'run_id':source.get('run_id'),
            'framework_revision':source.get('framework_revision'),'snapshot_sha256':binding(snapshot)['sha256'],
            'model_calls':0,'physical_simulation':False,'checks':checks,'cases':cases,'inputs':reader.inputs,'errors':errors,
            'scope':'Synthetic isolated channel diagnostic, including expected production failures; not native pool reproduction, model read, robot or task evidence.'}


def run(args):
    snapshot=args.snapshot.resolve();frozen=validate_snapshot(snapshot,args.framework_revision)
    require(isinstance(args.run_id,str) and bool(args.run_id),'Missing run identity')
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
    save(output/'source-binding.json',{'schema':'campaign002-channel-probe-source-3','run_id':args.run_id,
        'framework_revision':args.framework_revision,'snapshot_sha256':binding(snapshot)['sha256'],
        'source_bindings':frozen['sources'],'cases':make_cases(),'model_calls':0,'physical_simulation':False})
    for case in CASES:run_case(output/case,case)
    result=assess(output,snapshot);save(output/'result.json',result)
    print(json.dumps({'passed':result['passed'],'result':str(output/'result.json'),'model_calls':0}))
    return 0 if result['passed'] else 1


def main():
    if len(sys.argv)==3 and sys.argv[1]=='--client':return client_main(sys.argv[2])
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot',type=Path,required=True)
    parser.add_argument('--framework-revision',required=True)
    parser.add_argument('--run-id',required=True)
    parser.add_argument('--output',type=Path,required=True)
    return run(parser.parse_args())


if __name__=='__main__':raise SystemExit(main())
