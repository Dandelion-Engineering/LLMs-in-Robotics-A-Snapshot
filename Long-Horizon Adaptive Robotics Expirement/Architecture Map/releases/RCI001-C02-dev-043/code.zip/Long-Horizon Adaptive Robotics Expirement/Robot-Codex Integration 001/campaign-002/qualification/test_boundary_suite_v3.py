"""Preserve fixed boundary checks while adapting the transport wire protocol."""
import ast
from pathlib import Path
import unittest
from unittest.mock import patch

import boundary_suite as original
import boundary_suite_v3 as candidate
import test_boundary_suite as prior_tests


class PreservedGuestProtocol(prior_tests.FixedGuestProtocol):
    def setUp(self):
        self.enterContext(patch.object(prior_tests,'suite',candidate))


class PreservedUnitGroups(prior_tests.UnitSuiteDeclarations):
    def setUp(self):
        self.enterContext(patch.object(prior_tests,'suite',candidate))


class BoundarySourceParity(unittest.TestCase):
    def test_guest_protocol_and_every_unrelated_function_are_unchanged(self):
        self.assertEqual(original.GUEST_SOURCE,candidate.GUEST_SOURCE)
        def functions(module):
            return {n.name:n for n in ast.parse(Path(module.__file__).read_bytes()).body
                    if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
        baseline,updated=functions(original),functions(candidate)
        self.assertEqual(set(baseline),set(updated))
        for name in baseline:
            if name not in {'sources','unit_suites','qualify'}:
                self.assertEqual(ast.dump(baseline[name]),ast.dump(updated[name]),name)
        def required(function):
            node=next(n for n in ast.walk(function) if isinstance(n,ast.Assign)
                      and any(isinstance(t,ast.Name) and t.id=='required' for t in n.targets))
            return ast.literal_eval(node.value)
        self.assertEqual(required(baseline['qualify']),required(updated['qualify']))
        self.assertEqual(len(required(updated['qualify'])),12)

    def test_source_inventory_binds_both_versions_and_the_declared_channel_contract(self):
        names=candidate.sources()
        for suffix in ('qualification/boundary_suite.py','qualification/boundary_suite_v3.py',
                       'qualification/test_boundary_suite_v3.py','io-repair/CODEHOST_CHANNEL_TRANSPORT_V3.md',
                       'io-repair/CHANNEL_TRANSPORT_V3_QUALIFICATION_001.md'):
            self.assertEqual(sum(name.endswith('/'+suffix) for name in names),1)


if __name__=='__main__':unittest.main()
