"""Bounded synthetic regression tests; no renderer, physics run, or scored evidence.

Cell construction is bypassed. Tick tests replace mj_step with a clock increment;
planner tests use an event-controlled thread or manually completed Future. Sensor
tests use explicitly synthetic arrays. No fixtures enter the evidence store.
"""
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
import sys
from threading import Event
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cell as runtime_cell


def fake_cell():
    value = runtime_cell.Cell.__new__(runtime_cell.Cell)
    value.data = SimpleNamespace(time=0., qpos=np.zeros(9), ctrl=np.zeros(8),
                                 site_xpos=np.array([[.4, 0., .4]]), ncon=0)
    value.model = SimpleNamespace(geom=lambda name: SimpleNamespace(id=0),
                                  geom_rgba=np.array([[.03, .03, .03, 1.]]))
    value.tcp = 0
    value.registry = {'A1': {'family': 'A', 'half': [.021, .021, .018],
                             'kind': 'part', 'hue': 0.}}
    value.last_detections = [{'id': 'A1', 'kind': 'part', 'family': 'A',
                              'zone': 'raw', 'pos': [.32, -.31, .02]}]
    value.detection_time = 0.
    value.plan_future = None
    value.pending_plan_generation = None
    value.plan_generation = 0
    value.motion = []
    value.segment = None
    value.active_request = None
    value.lease_deadline = None
    value.feedback = []
    value.events = []
    value.station = {'busy': False, 'ready': True, 'fault': False, 'cycle_id': 0,
                     'completed_cycle_id': None, 'guard_closed': False,
                     'clamped': False}
    value.truth = {'A1': {'recipe': None, 'cycles': 0, 'inspection': None,
                           'cycle_history': [], 'inspection_history': []}}
    value.process_duration_s = 8.
    value.cycle = None
    value.inspection = None
    value.inspection_due = None
    value.total_path = 0.
    value.last_tcp = value.data.site_xpos[0].copy()
    value.contact_peak = 0.
    value.collision_impulse = 0.
    return value


def fake_step(model, data):
    data.time += runtime_cell.DT


def segment():
    return {'q': np.ones(7), 'grip': 255, 'duration': 1., 'phase': 0}


class PlannerTests(unittest.TestCase):
    def test_submission_returns_and_tick_advances_while_planner_is_blocked(self):
        value = fake_cell()
        started, release = Event(), Event()
        snapshots = []

        def blocked_plan(snapshot, generation):
            snapshots.append(snapshot)
            started.set()
            if not release.wait(2):
                raise TimeoutError('test failed to release synthetic planner')
            return generation, [segment()]

        value._plan_snapshot = blocked_plan
        value.planner = ThreadPoolExecutor(max_workers=1)
        caller = ThreadPoolExecutor(max_workers=1)
        try:
            action = {'operation': 'transport', 'part_id': 'A1',
                      'destination': 'fixture', 'request_id': 'synthetic-1'}
            submission = caller.submit(value.submit, action)
            self.assertTrue(started.wait(1), 'planner was not started')
            # A synchronous-planner regression fails this deadline; finally
            # releases the worker so the test never leaves a blocked thread.
            self.assertEqual(submission.result(timeout=.5)['status'], 'accepted')
            self.assertFalse(value.plan_future.done())
            value.last_detections[0]['pos'][0] = 99
            value.data.qpos[0] = 99
            self.assertEqual(snapshots[0]['observed']['pos'][0], .32)
            self.assertEqual(snapshots[0]['configuration'][0], 0)
            with patch.object(runtime_cell.mujoco, 'mj_step', side_effect=fake_step):
                value.tick()
            self.assertEqual(value.data.time, runtime_cell.DT)
            self.assertEqual(value.motion, [])
            self.assertIsNone(value.segment)
            self.assertFalse(any(e['type'] == 'trajectory_dispatched' for e in value.events))
        finally:
            release.set()
            caller.shutdown(wait=True, cancel_futures=True)
            value.planner.shutdown(wait=True, cancel_futures=True)

    def pending(self):
        value = fake_cell()
        value.active_request = {'request_id': 'synthetic-old'}
        value.lease_deadline = 2.
        future = Future()
        value.plan_future = future
        value.pending_plan_generation = value.plan_generation
        return value, future

    def test_current_plan_dispatches_only_when_complete(self):
        value, future = self.pending()
        future.set_result((value.plan_generation, [segment()]))
        with patch.object(runtime_cell.mujoco, 'mj_step', side_effect=fake_step):
            value.tick()
        dispatched = [e for e in value.events if e['type'] == 'trajectory_dispatched']
        self.assertEqual([e['request_id'] for e in dispatched], ['synthetic-old'])
        self.assertIsNotNone(value.segment)
        self.assertIsNone(value.plan_future)

    def cancel_then_begin_inspection(self):
        value, future = self.pending()
        value.cancel('synthetic revocation')
        value._physical_zone = Mock(return_value=True)
        new_action = {'operation': 'inspect', 'part_id': 'A1',
                      'request_id': 'synthetic-new'}
        self.assertEqual(value.submit(new_action)['status'], 'accepted')
        return value, future

    def test_cancelled_plan_cannot_dispatch_for_a_new_active_request(self):
        value, future = self.cancel_then_begin_inspection()
        future.set_result((0, [segment()]))
        with patch.object(runtime_cell.mujoco, 'mj_step', side_effect=fake_step):
            value.tick()
        self.assertEqual(value.motion, [])
        self.assertIsNone(value.segment)
        self.assertEqual(value.active_request['request_id'], 'synthetic-new')
        self.assertEqual(value.events[-1]['type'], 'stale_plan_discarded')
        self.assertFalse(any(e['type'] == 'trajectory_dispatched' for e in value.events))
        self.assertEqual(value.feedback[0]['status'], 'cancelled')

    def test_cancelled_planner_exception_cannot_fail_a_new_request(self):
        value, future = self.cancel_then_begin_inspection()
        future.set_exception(ValueError('synthetic old planner failure'))
        with patch.object(runtime_cell.mujoco, 'mj_step', side_effect=fake_step):
            value.tick()
        self.assertEqual(value.active_request['request_id'], 'synthetic-new')
        self.assertFalse(any(e.get('status') == 'failed' for e in value.feedback))


class SensorTests(unittest.TestCase):
    def sensor(self, visible=True):
        value = fake_cell()
        rgb = np.zeros((480, 640, 3), dtype=np.uint8)
        if visible:
            # Exactly 0.4 before noise fails the >0.4 detector threshold.
            rgb[239:243, 318:322, 0] = 102
        depth = np.ones((480, 640), dtype=np.float32)
        value.render = Mock(return_value=(rgb, depth))
        value.noise_rng = SimpleNamespace(
            integers=Mock(return_value=np.array([[[1, -1, 0]]])),
            normal=Mock(return_value=.0005))
        value.model.camera = lambda name: SimpleNamespace(id=0)
        value.model.cam_fovy = np.array([48.])
        value.data.cam_xmat = np.array([np.eye(3).ravel()])
        value.data.cam_xpos = np.array([[.43, 0., 1.25]])
        value.actual_pos = Mock(side_effect=AssertionError('privileged truth read'))
        return value, rgb, depth

    def test_detector_uses_exact_retained_noisy_rgb_and_depth(self):
        value, raw_rgb, raw_depth = self.sensor()
        found, rgb, depth = value.sense()
        self.assertEqual([d['id'] for d in found], ['A1'])
        self.assertEqual(found[0]['pixels'], 16)
        self.assertEqual(raw_rgb[239, 318, 0], 102)
        self.assertEqual(rgb[239, 318, 0], 103)
        np.testing.assert_array_equal(depth, raw_depth + np.float32(.0005))
        self.assertIs(value.last_rgb, rgb)
        self.assertIs(value.last_depth, depth)
        focal = 480 / (2 * np.tan(np.deg2rad(48.) / 2))
        z = float(depth[240, 319])
        expected = [.43, -z / focal, 1.25-z-.0187]
        np.testing.assert_allclose(found[0]['pos'], expected, atol=1e-8)
        value.actual_pos.assert_not_called()

    def test_registry_does_not_create_a_detection_without_visible_pixels(self):
        value, _, _ = self.sensor(visible=False)
        found, _, _ = value.sense()
        self.assertEqual(found, [])
        value.actual_pos.assert_not_called()


class ProcessTests(unittest.TestCase):
    def accepted_cycle(self):
        value = fake_cell()
        value._physical_zone = Mock(return_value=True)
        response = value.submit({'operation': 'cycle', 'part_id': 'A1',
                                 'recipe': 'A', 'request_id': 'synthetic-cycle'})
        self.assertEqual(response['status'], 'accepted')
        self.assertTrue(value.station['busy'])
        self.assertFalse(value.truth['A1']['cycle_history'][0]['completed'])
        return value

    def test_interrupted_part_or_insert_seating_cannot_gain_processed_mark(self):
        for interrupted in ('A1', 'insert_A'):
            with self.subTest(interrupted=interrupted):
                value = self.accepted_cycle()
                original_mark = value.model.geom_rgba.copy()
                value._physical_zone.side_effect = lambda part, zone: part != interrupted
                value.data.time = 1.
                with patch.object(runtime_cell.mujoco, 'mj_step', side_effect=fake_step):
                    value.tick()
                    self.assertIsNone(value.cycle)
                    self.assertTrue(value.station['fault'])
                    self.assertFalse(value.station['busy'])
                    self.assertFalse(value.station['ready'])
                    # Restoring the seat later does not resurrect the process.
                    value._physical_zone.side_effect = None
                    value._physical_zone.return_value = True
                    value.data.time = 9.
                    value.tick()
                record = value.truth['A1']
                self.assertIsNone(record['recipe'])
                self.assertEqual(record['cycles'], 0)
                self.assertFalse(record['cycle_history'][0]['completed'])
                np.testing.assert_array_equal(value.model.geom_rgba, original_mark)
                self.assertEqual(len([e for e in value.events if e['type'] == 'cycle_fault']), 1)
                self.assertFalse(any(e['type'] == 'cycle_complete' for e in value.events))

    def test_uninterrupted_eligible_cycle_does_complete_and_change_mark(self):
        value = self.accepted_cycle()
        value.data.time = 8.
        with patch.object(runtime_cell.mujoco, 'mj_step', side_effect=fake_step):
            value.tick()
        record = value.truth['A1']
        self.assertEqual(record['recipe'], 'A')
        self.assertEqual(record['cycles'], 1)
        self.assertTrue(record['cycle_history'][0]['completed'])
        np.testing.assert_array_equal(value.model.geom_rgba[0], [1, 1, 1, 1])
        self.assertTrue(value.station['ready'])
        self.assertFalse(value.station['fault'])


if __name__ == '__main__':
    unittest.main()
