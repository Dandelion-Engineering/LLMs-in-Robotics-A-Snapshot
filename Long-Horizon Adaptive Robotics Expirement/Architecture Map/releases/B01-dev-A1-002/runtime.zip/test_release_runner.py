"""Synthetic release-driver checks only: no GPU, physics, queue or map mutations."""
import contextlib
import copy
from dataclasses import dataclass
import itertools
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock,patch
import zipfile

import protocol
import release_runner as runner


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)
        self.job={'id':'unit-queue-job','state':'running','child_pid':123,'argv':['python','release_runner.py']}

    def write(self,path,value):
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(value,sort_keys=True),encoding='utf-8');return path

    def ref(self,path):return {'path':str(path),'sha256':runner.digest(path)}

    def release(self,ready=True):
        evidence=self.root/'synthetic-readiness.txt';evidence.write_text('UNIT FIXTURE; NOT READINESS')
        freeze={'release_id':'unit-release','frozen_at':'2000-01-01T00:00:00+00:00',
                'code_sha256':'1'*64,'environment_sha256':'2'*64,'model_sha256':'3'*64,
                'protocol_sha256':protocol.protocol_sha256(),'selection_criteria':'unit fixture','maximum_retries':0}
        freeze_path=self.write(self.root/'freeze.json',freeze)
        ready_path=self.write(self.root/'readiness.json',{'release_id':'unit-release','freeze_sha256':runner.digest(freeze_path),
            'scored_ready':True,'gates':{gate:True for gate in protocol.REQUIRED_GATES},'evidence_refs':[self.ref(evidence)]})
        root=self.root/'release';sequence=itertools.count(1)
        with patch.object(protocol,'_entropy',side_effect=lambda bits:next(sequence)):
            protocol.create_release(root,freeze_path,ready_path)
        if not ready:
            value=runner.load(ready_path);value['scored_ready']=False;self.write(ready_path,value)
            release=runner.load(root/'release.json');release['readiness']=self.ref(ready_path);self.write(root/'release.json',release)
        return root

    def verified(self,root):
        with patch.object(runner,'verify_artifacts',return_value={'model_config':{},'test_fixture':True}):return runner.verify_release(root)

    def context(self,verified,manifest):
        ref=next(r for r in verified['release']['manifest_refs'] if r['run_id']==manifest['run_id'])
        return runner.VerifiedEvaluationContext(verified['root'],protocol.canonical(manifest).decode(),verified['release_sha256'],ref['sha256'],self.job['id'],runner.utc(),'{"model_config":{}}',runner._AUTHORITY)

    def run_fake(self,root,*,limit=2,behavior=None):
        verified=self.verified(root);registered=[];executed=[]
        def register(context):registered.append(context.manifest['run_id']);return 'fixture-frozen-revision'
        def execute(context,episode):
            m=context.manifest;executed.append(m['run_id'])
            self.assertIn(m['run_id'],registered)
            self.assertTrue((context.evidence_dir.parent/'started.json').is_file())
            if behavior:return behavior(context)
            context.evidence_dir.mkdir()
            result={'run_id':m['run_id'],'stage':'evaluation','execution_status':'completed','validity':'valid',
                    'outcome':'failure','ended_at':runner.utc(),'termination_reason':'time_cap'}
            self.write(context.evidence_dir/'result.json',result);return result
        with patch.object(runner,'queued_job',return_value=self.job),patch.object(runner,'verify_release',return_value=verified),patch.object(runner,'require_supervisor_hook',return_value=MagicMock()),patch.object(runner,'authorize_evaluation',side_effect=lambda m,r:self.context(verified,m)),patch.object(runner,'register_attempt',side_effect=register),patch.object(runner,'execute_episode',side_effect=execute):
            result=runner.run_batch(root,limit=limit)
        return result,verified,registered,executed

    def test_readiness_false_stops_before_artifact_hashes(self):
        root=self.release(ready=False)
        with patch.object(runner,'verify_artifacts',side_effect=AssertionError('must not hash model')):
            with self.assertRaisesRegex(protocol.ProtocolError,'scored_ready'):runner.verify_release(root)

    def test_changed_manifest_or_missing_seed_is_rejected(self):
        root=self.release();release=runner.load(root/'release.json');path=root/release['manifest_refs'][0]['path']
        value=runner.load(path);value['cap_s']=1;self.write(path,value)
        with self.assertRaisesRegex(protocol.ProtocolError,'changed'):self.verified(root)

    def test_wrong_artifact_binding_is_rejected(self):
        root=self.release();release=runner.load(root/'release.json');ref=release['manifest_refs'][0];path=root/ref['path']
        value=runner.load(path);value['artifact_hashes']['code_sha256']='0'*64;self.write(path,value)
        ref['sha256']=runner.digest(path);self.write(root/'release.json',release)
        with self.assertRaisesRegex(runner.ReleaseError,'bound'):self.verified(root)

    def test_context_preserves_all_seed_roles_and_exact_arguments(self):
        root=self.release();verified=self.verified(root);m=verified['manifests'][0];context=self.context(verified,m)
        kwargs=context.episode_kwargs();kwargs.pop('evaluation_context')
        self.assertEqual({k:kwargs[k] for k in m['seeds']},m['seeds'])
        self.assertEqual(context.assert_episode(**kwargs),context.evidence_dir)
        kwargs['noise_seed']+=1
        with self.assertRaisesRegex(runner.ReleaseError,'exact'):context.assert_episode(**kwargs)
        forged=runner.VerifiedEvaluationContext(root,context.manifest_json,'a','b','c','d','{}')
        with self.assertRaisesRegex(runner.ReleaseError,'not issued'):forged.assert_episode(**kwargs)

    def test_context_rejects_dirty_episode_directory(self):
        root=self.release();verified=self.verified(root);context=self.context(verified,verified['manifests'][0]);context.evidence_dir.mkdir(parents=True)
        kwargs=context.episode_kwargs();kwargs.pop('evaluation_context')
        with self.assertRaisesRegex(runner.ReleaseError,'not fresh'):context.assert_episode(**kwargs)

    def test_current_development_supervisor_is_not_silently_enabled(self):
        fake=SimpleNamespace(run_episode=lambda **kwargs:None)
        with patch.dict(sys.modules,{'experiment':fake}):
            with self.assertRaisesRegex(runner.ReleaseError,'hook'):runner.require_supervisor_hook()

    def test_no_implicit_retry_after_interruption(self):
        root=self.release();verified=self.verified(root);m=verified['manifests'][0]
        (root/'attempts'/m['run_id']).mkdir(parents=True)
        with self.assertRaisesRegex(runner.ReleaseError,'Interrupted'):runner.select_runs(verified,None,4)

    def test_explicit_subset_is_bounded_and_keeps_frozen_schedule(self):
        root=self.release();verified=self.verified(root);ordered=sorted(verified['manifests'],key=lambda m:m['scheduled_index'])
        selected=runner.select_runs(verified,[ordered[2]['run_id'],ordered[0]['run_id']],2)
        self.assertEqual([m['scheduled_index'] for m in selected],[1,3])
        with self.assertRaises(runner.ReleaseError):runner.select_runs(verified,[m['run_id'] for m in ordered[:5]],4)

    def test_sequential_attempts_are_registered_first_and_all_failures_retained(self):
        root=self.release();result,verified,registered,executed=self.run_fake(root)
        self.assertEqual(registered,executed);self.assertEqual(len(executed),2)
        self.assertFalse(result['map_results_applied'])
        for run_id in executed:
            terminal=runner.load(root/'attempts'/run_id/'terminal.json')
            self.assertEqual(terminal['result']['outcome'],'failure')
            self.assertFalse(terminal['official_queue_completion_verified'])
        with self.assertRaisesRegex(runner.ReleaseError,'official queue'):runner.select_runs(verified,None,1)
        self.write(root/'batches'/self.job['id']/'finalized.json',{'fixture_verified':True})
        with self.assertRaisesRegex(runner.ReleaseError,'retries'):runner.select_runs(verified,[executed[0]],1)

    def test_infrastructure_exception_retained_and_remaining_runs_not_launched(self):
        root=self.release()
        def fail(context):raise RuntimeError('fixture model startup failure')
        result,verified,registered,executed=self.run_fake(root,behavior=fail)
        self.assertEqual(len(executed),1);self.assertIsNotNone(result['stop_reason'])
        terminal=runner.load(root/'attempts'/executed[0]/'terminal.json')
        self.assertTrue(terminal['result']['infrastructure_invalid'])
        self.assertIsNone(terminal['result']['wall_duration_s'])
        self.write(root/'batches'/self.job['id']/'finalized.json',{'fixture_verified':True})
        with self.assertRaisesRegex(runner.ReleaseError,'readiness review'):runner.select_runs(verified,None,1)

    def test_fresh_model_context_for_each_llm_episode_and_cleanup_on_failure(self):
        root=self.release();verified=self.verified(root);manifests=[m for m in verified['manifests'] if m['architecture']=='A1'][:2]
        class FakeModel:
            instances=[]
            def __init__(self,*args,**kwargs):self.closed=False;self.instances.append(self)
            def __enter__(self):return self
            def __exit__(self,*args):self.closed=True
        module=SimpleNamespace(LocalModel=FakeModel,ModelConfig=lambda **kwargs:kwargs)
        def episode(**kwargs):raise RuntimeError('fixture episode')
        with patch.dict(sys.modules,{'model_runtime':module}):
            for m in manifests:
                with self.assertRaises(RuntimeError):runner.execute_episode(self.context(verified,m),episode)
        self.assertEqual(len(FakeModel.instances),2);self.assertTrue(all(m.closed for m in FakeModel.instances))

    def test_queue_receipt_must_be_successful_and_same_job(self):
        receipt={'id':'unit-queue-job','state':'succeeded','exit_status':0,'child_pid':123,'started_at':'start','ended_at':'end','argv':['test'],'cwd':'test'}
        path=self.write(self.root/'status.json',receipt);state=self.write(self.root/'state.json',{'jobs':[receipt]})
        with patch.object(runner,'QUEUE_STATE',state):
            self.assertEqual(runner.verify_queue_receipt('unit-queue-job',path),receipt)
            with self.assertRaises(runner.ReleaseError):runner.verify_queue_receipt('other-job',path)
            receipt['state']='failed';self.write(path,receipt)
            with self.assertRaises(runner.ReleaseError):runner.verify_queue_receipt('unit-queue-job',path)

    def test_atomic_journal_cannot_overwrite_attempt(self):
        path=self.root/'journal.json';runner.write_once(path,{'state':'started'})
        with self.assertRaises(FileExistsError):runner.write_once(path,{'state':'new attempt'})
        self.assertEqual(runner.load(path),{'state':'started'})

    def test_finalization_checks_terminal_hash_before_map_write(self):
        root=self.release();result,verified,registered,executed=self.run_fake(root,limit=1)
        terminal=root/'attempts'/executed[0]/'terminal.json';value=runner.load(terminal);value['result']['outcome']='success';self.write(terminal,value)
        fake_records=SimpleNamespace(am=SimpleNamespace(main=MagicMock(return_value=0)))
        with patch.object(runner,'verify_queue_receipt',return_value={'id':self.job['id'],'state':'succeeded','exit_status':0}),patch.object(runner,'map_reference',return_value={}),patch.object(runner,'append_map_result') as append,patch.dict(sys.modules,{'record_attempt':fake_records}):
            with self.assertRaisesRegex(runner.ReleaseError,'changed'):runner.finalize(root,self.job['id'],self.root/'unused.json')
        append.assert_not_called()

    def test_successful_finalization_is_separate_from_execution(self):
        root=self.release();result,verified,registered,executed=self.run_fake(root,limit=1)
        fake_records=SimpleNamespace(am=SimpleNamespace(main=MagicMock(return_value=0)))
        with patch.object(runner,'verify_queue_receipt',return_value={'id':self.job['id'],'state':'succeeded','exit_status':0}),patch.object(runner,'map_reference',return_value={}),patch.object(runner,'append_map_result') as append,patch.dict(sys.modules,{'record_attempt':fake_records}):
            finished=runner.finalize(root,self.job['id'],self.root/'unused.json')
        self.assertTrue(finished['official_queue_completion_verified']);append.assert_called_once()
        self.assertTrue((root/'batches'/self.job['id']/'finalized.json').is_file())


class ArtifactTests(unittest.TestCase):
    """Tiny installed-asset fixtures; no real weight hashing or environment probes."""
    setUp=RunnerTests.setUp
    write=RunnerTests.write
    ref=RunnerTests.ref
    def test_all_frozen_source_environment_and_model_files_checked(self):
        runtime=self.root/'Runtime';runtime.mkdir();source=runtime/'one.py';source.write_text('fixture = True\n')
        bundle=self.root/'runtime.zip'
        with zipfile.ZipFile(bundle,'w') as archive:archive.write(source,source.name)
        vendor=runtime/'vendor'/'model';vendor.mkdir(parents=True)
        weight=vendor/'fixture.gguf';weight.write_bytes(b'unit fixture weight')
        binary=vendor/'server.exe';binary.write_bytes(b'unit fixture executable')
        assets=self.write(vendor/'asset_manifest.json',{'installed_files':[{'path':'server.exe','sha256':runner.digest(binary)}]})
        environment_file=self.root/'requirements.txt';environment_file.write_text('SYNTHETIC')
        identity={'python':'fixture','dependencies':{'numpy':'fixture','mujoco':'fixture'}}
        @dataclass(frozen=True)
        class Config:context_tokens:int=123
        model_identity={'identity':'fixture'}
        code=self.write(self.root/'code.json',{'files':[self.ref(source)],'runtime_root':str(runtime),'bundle':self.ref(bundle)})
        env=self.write(self.root/'environment.json',{'files':[self.ref(environment_file)],'runtime_identity':identity,
                    'probes':[{'name':name} for name in ('candidate_python','candidate_isolation','gpu_driver')]})
        model=self.write(self.root/'model.json',{'files':[self.ref(assets),self.ref(weight),self.ref(binary)],'asset_manifest':self.ref(assets),
                    'identity':model_identity,'config':{'context_tokens':123}})
        freeze={'artifacts':{role:self.ref(path) for role,path in (('code',code),('environment',env),('model',model))},
                'code_sha256':runner.digest(code),'environment_sha256':runner.digest(env),'model_sha256':runner.digest(model)}
        modules={'model_runtime':SimpleNamespace(LocalModel=lambda config:SimpleNamespace(identity=model_identity),ModelConfig=Config),
                 'model_setup':SimpleNamespace(VENDOR=vendor,MODEL_FILE=weight.name,MODEL_SHA256=runner.digest(weight))}
        with patch.object(runner,'HERE',runtime),patch.object(runner,'environment_identity',return_value=identity),patch.object(runner,'run_probe') as probe,patch.dict(sys.modules,modules):
            verified=runner.verify_artifacts(freeze,self.root/'freeze.json')
            self.assertEqual(verified['model_identity'],model_identity);self.assertEqual(probe.call_count,3)
            source.write_text('changed = True\n')
            with self.assertRaisesRegex(runner.ReleaseError,'changed'):runner.verify_artifacts(freeze,self.root/'freeze.json')


if __name__=='__main__':unittest.main()
