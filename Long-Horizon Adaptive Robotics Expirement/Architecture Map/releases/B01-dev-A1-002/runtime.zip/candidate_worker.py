"""One stdlib-only candidate inside the OS sandbox; JSON-line IPC only.

The trusted wrapper applies hard rlimits and a no-new-privileges seccomp filter
before importing candidate code. Bubblewrap supplies filesystem/namespaces.
"""
from __future__ import annotations

import argparse
import ctypes
import errno
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys


def restrict(limits: dict) -> dict:
    hard_limits = {
        resource.RLIMIT_CPU: int(limits["cpu_seconds"]),
        resource.RLIMIT_AS: int(limits["memory_bytes"]),
        resource.RLIMIT_NPROC: 1,
        resource.RLIMIT_FSIZE: int(limits["file_bytes"]),
        resource.RLIMIT_NOFILE: int(limits["open_files"]),
        resource.RLIMIT_CORE: 0,
    }
    for key, value in hard_limits.items():
        resource.setrlimit(key, (value, value))
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(38, 1, 0, 0, 0) != 0:  # PR_SET_NO_NEW_PRIVS
        raise OSError(ctypes.get_errno(), "Cannot set no_new_privs")
    seccomp = ctypes.CDLL("libseccomp.so.2", use_errno=True)
    seccomp.seccomp_init.argtypes = [ctypes.c_uint32]
    seccomp.seccomp_init.restype = ctypes.c_void_p
    seccomp.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    seccomp.seccomp_syscall_resolve_name.restype = ctypes.c_int
    seccomp.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
    seccomp.seccomp_rule_add.restype = ctypes.c_int
    seccomp.seccomp_load.argtypes = [ctypes.c_void_p]
    seccomp.seccomp_load.restype = ctypes.c_int
    seccomp.seccomp_release.argtypes = [ctypes.c_void_p]
    context = seccomp.seccomp_init(0x7FFF0000)  # SCMP_ACT_ALLOW
    if not context:
        raise RuntimeError("Cannot create seccomp filter")
    # NPROC is not sufficient on all UID/user-namespace configurations. Deny
    # child/thread creation directly as well, and deny executing other binaries.
    blocked = ["fork", "vfork", "clone", "clone3", "execve", "execveat",
               "socket", "socketpair", "connect", "bind", "listen", "accept", "accept4",
               "mount", "umount2", "pivot_root", "chroot", "unshare", "setns",
               "ptrace", "process_vm_readv", "process_vm_writev", "perf_event_open",
               "bpf", "userfaultfd", "keyctl", "add_key", "request_key", "io_uring_setup",
               "reboot", "kexec_load", "kexec_file_load", "init_module", "finit_module",
               "delete_module", "swapon", "swapoff", "acct", "settimeofday", "clock_settime"]
    installed = []
    try:
        for name in blocked:
            number = seccomp.seccomp_syscall_resolve_name(name.encode("ascii"))
            if number < 0:
                raise RuntimeError("Required syscall is unknown: " + name)
            status = seccomp.seccomp_rule_add(context, 0x00050000 | errno.EPERM, number, 0)
            if status != 0:
                raise OSError(-status, "Cannot deny " + name)
            installed.append(name)
        status = seccomp.seccomp_load(context)
        if status != 0:
            raise OSError(-status, "Cannot install seccomp")
    finally:
        seccomp.seccomp_release(context)
    return {"seccomp_denied_syscalls": installed,
            "hard_limits": {str(key): value for key, value in hard_limits.items()},
            "pid": os.getpid(), "uid": os.getuid(), "cwd": os.getcwd()}


def emit(message: dict, limit: int) -> None:
    usage=resource.getrusage(resource.RUSAGE_SELF)
    message={**message,'runtime_usage':{'source':'fixed candidate wrapper getrusage(RUSAGE_SELF)',
             'user_cpu_s':usage.ru_utime,'system_cpu_s':usage.ru_stime,'maximum_rss_bytes':usage.ru_maxrss*1024,
             'input_blocks':usage.ru_inblock,'output_blocks':usage.ru_oublock,
             'scope':'this Linux candidate incarnation; final partial interval may be missing after abrupt termination'}}
    payload = json.dumps(message, ensure_ascii=True, allow_nan=False, separators=(",", ":")).encode("ascii")
    if len(payload) + 1 > limit:
        raise ValueError("Candidate response exceeds the line limit")
    sys.stdout.buffer.write(payload + b"\n")
    sys.stdout.buffer.flush()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--kind", required=True)
    parser.add_argument("--persistent", choices=["0", "1"], required=True)
    parser.add_argument("--limits", required=True)
    args = parser.parse_args()
    limits = json.loads(args.limits)
    line_limit = int(limits["line_bytes"])
    try:
        restrictions = restrict(limits)
        spec = importlib.util.spec_from_file_location("candidates", "/code/candidates.py")
        if spec is None or spec.loader is None:
            raise RuntimeError("Candidate module is unavailable")
        module = importlib.util.module_from_spec(spec)
        sys.modules["candidates"] = module
        spec.loader.exec_module(module)
        candidate = module.Candidate(args.kind, Path("/work"), args.persistent == "1")
        emit({"type": "ready", "restrictions": restrictions}, line_limit)
        while True:
            line = sys.stdin.buffer.readline(line_limit + 1)
            if not line:
                return 0
            if len(line) > line_limit or not line.endswith(b"\n"):
                raise ValueError("Invalid or oversized IPC input line")
            request = json.loads(line)
            if not isinstance(request, dict):
                raise ValueError("IPC request must be an object")
            kind = request.get("type")
            response = None
            if kind == "step":
                response = candidate.step(request["packet"])
                if not isinstance(response, dict) or response.get("type") not in {"model", "action", "wait", "sensor_request"}:
                    raise ValueError("Candidate.step must return a model, action, sensor_request or wait object")
            elif kind == "model_response":
                candidate.accept_model(request["text"])
            elif kind == "feedback":
                candidate.accept_feedback(request["feedback"])
            elif kind == "sensor_response":
                candidate.accept_sensor(request["response"])
            elif kind == 'snapshot_resources':
                pass
            else:
                raise ValueError("Unknown IPC request type")
            events = candidate.drain_events()
            if not isinstance(events, list):
                raise ValueError("Candidate.drain_events must return a list")
            emit({"type": kind, "response": response, "events": events}, line_limit)
    except BaseException as exc:
        # Candidate paths contain no evaluator data. Report the actual exception
        # without returning a traceback of trusted host process state.
        try:
            emit({"type": "error", "error": type(exc).__name__, "message": str(exc)[:2000]}, line_limit)
        except BaseException:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
