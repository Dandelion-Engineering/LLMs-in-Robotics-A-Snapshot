"""Small supervisor regression checks. No simulator, model or queue job runs."""
from concurrent.futures import Future
import contextlib
import io
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import numpy as np
import experiment
import sandbox


class Clock:
    def __init__(self):self.t=0.
    def now(self):self.t+=.002;return self.t


class FakeResourceSampler:
    """No OS/GPU reads; records lifecycle and creates exact fixture evidence."""
    instances=[]
    def __init__(self,path,**kwargs):
        self.path=Path(path);self.kwargs=kwargs;self.period_s=5.;self.closed=False;self.started=False
        self.instances.append(self)
    def start(self):
        self.started=True;self.path.write_text('{"fixture":true}\n',encoding='utf-8');return self
    def close(self):self.closed=True
    def summary(self):return {'sample_count':1,'failure':None,'sampler_stopped':self.closed,'resource_caps_enforced':False}


class DeferredModelFuture:
    """Unready inside the episode, completed when cleanup awaits the result."""
    def __init__(self,error=None):self.error=error
    def done(self):return False
    def result(self,timeout=None):
        if self.error:raise self.error
        return {'text':'{"operation":"wait"}','usage':{'total_tokens':17}}


class ImmediateExecutor:
    def __init__(self,model,deferred):self.model=model;self.deferred=deferred;self.model_kwargs=[]
    def submit(self,function,*args,**kwargs):
        if function==self.model.complete:self.model_kwargs.append(kwargs);return self.deferred
        future=Future()
        try:future.set_result(function(*args,**kwargs))
        except BaseException as exc:future.set_exception(exc)
        return future
    def shutdown(self,**kwargs):pass


def fake_cell(clock=None, sense_error=None):
    cell=MagicMock()
    cell.data.time=0.;cell.data.qpos=np.zeros(16);cell.data.qvel=np.zeros(16)
    cell.data.actuator_force=np.zeros(9);cell.data.ctrl=np.zeros(9)
    cell.data.site_xpos=np.zeros((1,3));cell.tcp=0
    cell.total_path=0.;cell.contact_peak=0.;cell.collision_impulse=0.
    cell.events=[];cell.feedback=[];cell.segment=None;cell.active_request=None
    cell.truth={}
    cell.tick.side_effect=lambda:setattr(cell.data,'time',cell.data.time+.002)
    cell.outcome.return_value={'success':False,'accepted_count':0,'accepted':{},'reasons':['fixture unfinished']}
    cell.truth_snapshot.return_value={}
    cell.public_packet.return_value={'sequence':1,'sim_time':.5,'detections':[]}
    def sense():
        if sense_error:raise sense_error
        if clock:clock.t+=.2
        return [],np.zeros((2,2,3),dtype=np.uint8),np.zeros((2,2))
    cell.sense.side_effect=sense
    cell.sensor_worker.wait.return_value=None
    cell.request_sense.return_value={'accepted':True}
    def poll():
        _,rgb,depth=sense()
        return SimpleNamespace(sequence=1,capture_sim_time_s=cell.data.time,capture_wall_elapsed_s=0.,
                               rgb=rgb,depth=depth,calibration={},capture_telemetry={},artifacts={},
                               worker_finished_monotonic_s=0.,worker_started_monotonic_s=0.)
    cell.poll_sense.side_effect=poll
    return cell


class SupervisorTests(unittest.TestCase):
    def setUp(self):
        FakeResourceSampler.instances=[]
        self.resources_patch=patch.object(experiment,'ResourceSampler',FakeResourceSampler)
        self.resources_patch.start();self.addCleanup(self.resources_patch.stop)

    def test_seeds_are_independent_and_legacy_alias_is_checked(self):
        self.assertEqual(experiment.resolve_seeds(seed=7,policy_noise_seed=19),(7,19))
        self.assertEqual(experiment.resolve_seeds(world_seed=3),(3,0))
        with self.assertRaisesRegex(ValueError,'disagree'):experiment.resolve_seeds(seed=7,world_seed=8)
        with self.assertRaises(ValueError):experiment.resolve_seeds(policy_noise_seed=-1)

    def test_assistance_requires_both_clocks_and_is_durable_idempotent(self):
        service=experiment.ScriptedAssistance()
        action={'request_id':'help-1','reason':'unknown outcome','evidence':{'sequence':3},'requested_information_or_action':'safe public reconciliation'}
        self.assertEqual(service.request(action,10.,1.,4)['status'],'accepted')
        self.assertTrue(service.request(action,11.,2.,5)['duplicate_suppressed'])
        self.assertEqual(service.advance(25.,15.9),[])
        self.assertEqual(service.advance(24.9,16.),[])
        answers=service.advance(25.,16.)
        self.assertEqual(len(answers),1);self.assertEqual(answers[0]['wait_wall_s'],15.)
        self.assertEqual(service.advance(100.,100.),[])
        packet=service.public_answers();packet[0]['content']='mutated'
        self.assertEqual(service.public_answers()[0]['content'],service.ANSWER)
        self.assertEqual(service.summary(100.)['requests'],1)
        self.assertIsNone(service.summary(100.)['actual_human_time_s'])

    def test_malformed_help_is_counted_without_answer_or_hidden_rescue(self):
        service=experiment.ScriptedAssistance()
        feedback=service.request({'request_id':'help-1','reason':'unknown'},0.,0.,1)
        self.assertEqual(feedback['status'],'rejected')
        self.assertEqual(service.advance(16.,16.),[])
        self.assertTrue(service.summary(16.)['any_help_requested'])
        self.assertEqual(service.summary(16.)['physical_rescue_actions'],0)

    def test_wall_stall_cannot_disappear_from_lag(self):
        timing=experiment.TimingMonitor()
        timing.observe(.2,0.)
        timing.observe(1.2,1.)
        report=timing.report()
        self.assertGreaterEqual(report['maximum_lag_s'],.199)
        self.assertFalse(report['actual_host_timing_pass'])
        self.assertEqual(report['complete_wall_windows'],1)
        self.assertAlmostEqual(report['timing'][0]['real_time_factor'],.8)

    def test_matching_clocks_pass_complete_windows(self):
        timing=experiment.TimingMonitor()
        for i in range(1,251):timing.observe(i*.01,i*.01)
        report=timing.report()
        self.assertTrue(report['actual_host_timing_pass'])
        self.assertAlmostEqual(report['trailing_partial_window_s'],.5)

    def test_pending_restart_worker_is_closed(self):
        old=MagicMock();fresh=MagicMock();pending=Future();pending.set_result(fresh)
        self.assertEqual(experiment.close_pending_restart(pending,'restart',old),[])
        old.close.assert_called_once();fresh.close.assert_called_once()

    def test_late_restart_after_cleanup_timeout_is_still_closed(self):
        old=MagicMock();fresh=MagicMock();pending=Future()
        errors=experiment.close_pending_restart(pending,'restart',old,timeout=.001)
        self.assertTrue(errors)
        pending.set_result(fresh)
        fresh.close.assert_called_once()

    def test_candidate_input_records_exact_supplied_message(self):
        worker=MagicMock();worker.receive.return_value={'type':'step','response':None}
        evidence=MagicMock();evidence.emit.return_value=8
        message={'type':'step','packet':{'sequence':5,'age_s':.123}}
        reply=experiment.candidate_call(worker,message,evidence,lambda:1.5,[3])
        evidence.emit.assert_called_once_with('candidate_input',{'message':message},1.5,'candidate_gateway',[3])
        worker.send.assert_called_once_with(message)
        self.assertEqual(reply['supervisor_input_event_id'],8)

    def test_initialization_failure_retains_terminal_result(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(experiment,'EVIDENCE',Path(directory)), patch.object(experiment,'Cell',side_effect=RuntimeError('fixture setup failed')), contextlib.redirect_stdout(io.StringIO()):
            result=experiment.run_episode(run_id='startup-failure')
            saved=json.loads((Path(directory)/'startup-failure'/'result.json').read_text())
        self.assertEqual(result,saved)
        self.assertEqual(result['failure_class'],'infrastructure_failure')
        self.assertEqual(result['validity'],'invalid')
        self.assertIsNone(result['wall_duration_s'])
        self.assertIsNone(result['independent_outcome'])
        self.assertTrue(FakeResourceSampler.instances[0].closed)
        self.assertEqual(result['resources']['path'],'resources.jsonl')
        self.assertEqual(len(result['resources']['sha256']),64)

    def test_render_failure_retains_terminal_result(self):
        cell=fake_cell(sense_error=RuntimeError('render failed'));worker=MagicMock()
        with tempfile.TemporaryDirectory() as directory, patch.object(experiment,'EVIDENCE',Path(directory)), patch.object(experiment,'Cell',return_value=cell), patch.object(sandbox,'CandidateSandbox',return_value=worker), contextlib.redirect_stdout(io.StringIO()):
            result=experiment.run_episode(run_id='render-failure',cap=.1)
        self.assertEqual(result['failure_class'],'infrastructure_failure')
        self.assertIn('render failed',result['error'])
        worker.close.assert_called_once();cell.close.assert_called_once()
        self.assertEqual(len(FakeResourceSampler.instances),1)
        self.assertTrue(FakeResourceSampler.instances[0].closed)

    def test_sensor_latency_is_in_final_actual_host_timing(self):
        clock=Clock();cell=fake_cell(clock);worker=MagicMock()
        worker.receive.return_value={'type':'step','response':None};worker.alive=True
        with tempfile.TemporaryDirectory() as directory, patch.object(experiment,'EVIDENCE',Path(directory)), patch.object(experiment,'Cell',return_value=cell), patch.object(sandbox,'CandidateSandbox',return_value=worker), patch.object(experiment.time,'perf_counter',side_effect=clock.now), patch.object(experiment,'write_png'), patch.object(experiment.np,'savez_compressed'), contextlib.redirect_stdout(io.StringIO()):
            result=experiment.run_episode(run_id='sensor-stall',cap=.1)
        self.assertGreater(result['maximum_lag_s'],.1)
        self.assertEqual(result['validity'],'invalid')
        cell.renew_authority.assert_called_once_with(1,1)

    def late_model_run(self,error=None):
        clock=Clock();cell=fake_cell();worker=MagicMock();worker.alive=True
        worker.receive.return_value={'type':'step','response':{'type':'model','messages':[{'role':'user','content':'wait'}],'schema':{'type':'object'}}}
        model=MagicMock();model.identity={'test_fixture':True};model.config.request_timeout_s=.01
        executor=ImmediateExecutor(model,DeferredModelFuture(error))
        with tempfile.TemporaryDirectory() as directory, patch.object(experiment,'EVIDENCE',Path(directory)), patch.object(experiment,'Cell',return_value=cell), patch.object(sandbox,'CandidateSandbox',return_value=worker), patch.object(experiment,'ThreadPoolExecutor',return_value=executor), patch.object(experiment.time,'perf_counter',side_effect=clock.now), patch.object(experiment,'write_png'), patch.object(experiment.np,'savez_compressed'), contextlib.redirect_stdout(io.StringIO()):
            result=experiment.run_episode(kind='A1',model=model,run_id='late-model',cap=.15,world_seed=12,policy_noise_seed=37)
            events=[json.loads(line) for line in (Path(directory)/'late-model'/'events.jsonl').read_text().splitlines()]
        self.assertEqual(executor.model_kwargs[0]['seed'],37)
        self.assertEqual(result['world_seed'],12)
        self.assertEqual(result['policy_noise_seed'],37)
        return result,events,model

    def test_model_tokens_finishing_after_cap_are_accounted_without_delivery(self):
        result,events,model=self.late_model_run()
        self.assertEqual(result['model_calls'],1)
        self.assertEqual(result['late_model_responses'],1)
        self.assertEqual(result['total_tokens'],17)
        self.assertTrue(result['model_accounting_complete'])
        self.assertTrue(any(e['event_type']=='late_model_response' and e['payload']['after_episode_end'] for e in events))
        self.assertFalse(any(e['event_type']=='candidate_input' and e['payload']['message']['type']=='model_response' for e in events))

    def test_failed_late_model_call_has_missing_token_count(self):
        result,events,model=self.late_model_run(TimeoutError('model timed out'))
        self.assertEqual(result['model_failed_calls'],1)
        self.assertIsNone(result['total_tokens'])
        self.assertEqual(result['unknown_token_calls'],1)
        self.assertFalse(result['model_accounting_complete'])
        model.stop.assert_called_once()


if __name__=='__main__':unittest.main()
