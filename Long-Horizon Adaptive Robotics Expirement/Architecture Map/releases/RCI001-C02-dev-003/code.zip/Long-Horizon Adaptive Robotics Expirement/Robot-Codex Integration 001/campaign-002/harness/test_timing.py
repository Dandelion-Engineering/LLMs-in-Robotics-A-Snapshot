"""Focused timing contract tests; no simulation, models or scheduling mutation."""
from array import array
import hashlib
import json
from pathlib import Path
import struct
import tempfile
import unittest

from timing import TimingCapture, load_monitor, verify_timing


class Clock:
    def __init__(self, value):
        self.value = value

    def __call__(self):
        return self.value


class TimingTests(unittest.TestCase):
    def capture(self, origin=100., sim_origin=50., capacity=1000):
        clock = Clock(origin)
        capture = TimingCapture(origin, sim_origin, max_samples=capacity, clock=clock)
        return capture, clock

    def persist(self, root, capture):
        return capture.persist(root, {"applied": True, "restored": True})

    def test_common_origin_and_terminal_replay(self):
        capture, clock = self.capture()
        clock.value = 101.
        capture.sample(51.)
        clock.value = 101.4
        capture.finish(51.4, "task_success")
        # Cleanup advances wall time but must not enter the ended interval.
        clock.value = 900.
        with tempfile.TemporaryDirectory() as directory:
            binding = self.persist(directory, capture)
            result = verify_timing(directory)
            self.assertTrue(binding["passed"])
            self.assertEqual(result["complete_wall_windows"], 1)
            self.assertAlmostEqual(result["trailing_partial_window_s"], .4)
            self.assertEqual(binding["loop_origin"]["monotonic_s"], 100.)
            self.assertEqual(binding["loop_origin"]["initial_sim_s"], 50.)
            self.assertEqual(Path(directory, "timing-samples.bin").stat().st_size, 3 * 16)

    def test_lag_equality_fails(self):
        monitor_type, _ = load_monitor()
        monitor = monitor_type()
        monitor.observe(.1, 0.)
        monitor.observe(1., 1.)
        self.assertEqual(monitor.report()["maximum_lag_s"], .1)
        self.assertFalse(monitor.report()["actual_host_timing_pass"])

    def test_fraction_equality_fails_then_below_passes(self):
        monitor_type, _ = load_monitor()
        monitor = monitor_type()
        for wall in range(1, 101):
            monitor.observe(float(wall), wall - .06)
        self.assertEqual(monitor.report()["outside_rtf_tolerance_fraction"], .01)
        self.assertFalse(monitor.report()["actual_host_timing_pass"])
        monitor.observe(101., 100.94)
        self.assertTrue(monitor.report()["actual_host_timing_pass"])

    def test_rtf_endpoints_remain_inclusive(self):
        monitor_type, _ = load_monitor()
        for sim in (.95, 1.05):
            monitor = monitor_type()
            monitor.observe(1., sim)
            self.assertTrue(monitor.report()["actual_host_timing_pass"])

    def test_entry_sample_catches_lag_before_catchup(self):
        capture, clock = self.capture(origin=0., sim_origin=0.)
        clock.value = .12
        capture.sample(0.)
        capture.sample(.12)
        clock.value = 1.
        capture.finish(1., "task_success")
        self.assertFalse(capture.monitor.report()["actual_host_timing_pass"])
        self.assertEqual(capture.maximum_sample["lag_s"], .12)

    def test_capacity_and_terminal_are_fail_closed(self):
        capture, clock = self.capture(capacity=2)
        clock.value = 101.
        capture.finish(51., "task_success")
        with self.assertRaises(ValueError):
            capture.sample(51.)
        capture, clock = self.capture(capacity=2)
        capture.sample(50.)
        with self.assertRaises(ValueError):
            capture.sample(50.)

    def test_nan_and_regression_rejected(self):
        capture, _ = self.capture()
        with self.assertRaises(ValueError):
            capture.observe_relative(float("nan"), 0.)
        capture.observe_relative(1., 1.)
        with self.assertRaises(ValueError):
            capture.observe_relative(.9, 1.)

    def test_corruption_and_metadata_tampering_rejected(self):
        capture, clock = self.capture(origin=0., sim_origin=0.)
        clock.value = 1.
        capture.finish(1., "task_success")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.persist(root, capture)
            binary = root / "timing-samples.bin"
            metadata = root / "timing-v2.json"
            original = binary.read_bytes()
            info = json.loads(metadata.read_text())
            binary.write_bytes(original[:-1])
            with self.assertRaisesRegex(ValueError, "length"):
                verify_timing(root)
            corrupted = struct.pack("<dddd", 0., 0., float("nan"), 1.)
            binary.write_bytes(corrupted)
            info["sha256"] = hashlib.sha256(corrupted).hexdigest()
            metadata.write_text(json.dumps(info))
            with self.assertRaisesRegex(ValueError, "Invalid retained"):
                verify_timing(root)
            binary.write_bytes(original)
            info["sha256"] = hashlib.sha256(original).hexdigest()
            info["report"]["maximum_lag_s"] = .01
            metadata.write_text(json.dumps(info))
            with self.assertRaisesRegex(ValueError, "differs"):
                verify_timing(root)

    def test_phase_diagnostics_are_bounded(self):
        capture, clock = self.capture(origin=0., sim_origin=0.)
        for _ in range(200):
            with capture.phase("host_work", lambda: 0.):
                clock.value += .01
        self.assertEqual(capture.phases["host_work"]["count"], 200)
        self.assertEqual(len(capture.slow), 64)
        self.assertIsInstance(capture.values, array)


if __name__ == "__main__":
    unittest.main()
