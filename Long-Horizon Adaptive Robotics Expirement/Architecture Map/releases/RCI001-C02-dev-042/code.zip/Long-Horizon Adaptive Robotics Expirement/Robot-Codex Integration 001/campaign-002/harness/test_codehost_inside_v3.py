import ast
import asyncio
import hashlib
import io
from pathlib import Path
import threading
import unittest
from unittest import mock

import codehost_inside_v3 as inside
import codehost_entry_v3 as entry
import codehost_mux_protocol as m
from test_codehost_mux_protocol import h2


class Writer:
    def __init__(self):self.data=bytearray();self.eof=False;self.closed=False;self.block=None
    def write(self,data):self.data.extend(data)
    async def drain(self):
        if self.block:await self.block.wait()
    def write_eof(self):self.eof=True
    def close(self):self.closed=True
    async def wait_closed(self):pass


class Child:
    pid=321
    code=None
    def poll(self):return self.code


class CleanupChild(Child):
    def __init__(self):self.code=None;self.terminations=0;self.kills=0
    def terminate(self):self.terminations+=1;self.code=-15
    def kill(self):self.kills+=1;self.code=-9
    def wait(self,timeout):return self.code


class RelayTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.input=asyncio.StreamReader();self.output=Writer();self.events=[];self.hosts=[];self.child=Child()
        async def connect():
            reader,writer=asyncio.StreamReader(),Writer();self.hosts.append((reader,writer));return reader,writer
        self.relay=inside.Relay(self.input,self.output,lambda kind,**kw:self.events.append({'kind':kind,**kw}),self.child,threading.Event(),connect)

    async def asyncTearDown(self):
        for c in self.relay.channels.values():
            if not c.closed:await self.relay.close_channel(c,'error')

    async def ready(self,channel=1):
        await self.relay.accept(m.OPEN,channel,b'')
        await self.relay.accept(m.DATA,channel,m.PREFACE+h2(4))
        await self.relay.channels[channel].queue.join()
        self.hosts[channel-1][0].feed_data(h2(4))
        for _ in range(4):await asyncio.sleep(0)

    async def test_two_channels_one_child_exact_byte_isolation(self):
        await self.ready(1);await self.ready(2)
        for channel,raw in ((1,b'one'),(2,b'two')):
            await self.relay.accept(m.DATA,channel,h2(1,5,1,raw))
            await self.relay.channels[channel].queue.join()
            self.hosts[channel-1][0].feed_data(h2(1,5,1,raw))
        for _ in range(6):await asyncio.sleep(0)
        await self.relay.accept(m.FINISH,0,b'')
        for c in self.relay.channels.values():await self.relay.close_channel(c,'owner_finish')
        rows=[x['receipt'] for x in self.events if x['kind']=='channel_closed']
        self.assertEqual(len(rows),2);self.assertTrue(all(x['qualified'] for x in rows))
        for channel,row in enumerate(rows,1):
            raw=bytes(self.hosts[channel-1][1].data)
            self.assertEqual(row['upload'],{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
        self.assertEqual({x['child_pid'] for x in self.events if x['kind']=='channel_open'},{321})
        self.assertNotEqual(self.hosts[0][1].data,self.hosts[1][1].data)
        self.assertEqual(self.relay.budget.total,0)

    async def test_clean_idle_channel_eof_does_not_finish_owner(self):
        await self.ready();self.hosts[0][0].feed_eof()
        for _ in range(15):await asyncio.sleep(0)
        self.assertTrue(self.relay.channels[1].closed);self.assertFalse(self.relay.finishing)
        self.assertIsNone(self.relay.failure)
        await self.relay.accept(m.OPEN,2,b'')
        self.assertEqual(len(self.hosts),2)

    async def test_inflight_eof_fails_before_eventual_finish(self):
        await self.ready();await self.relay.accept(m.DATA,1,h2(1,5,1,b'x'))
        self.hosts[0][0].feed_eof()
        for _ in range(8):await asyncio.sleep(0)
        self.assertIsNotNone(self.relay.failure)
        await self.relay.accept(m.FINISH,0,b'');await self.relay.close_channel(self.relay.channels[1],'owner_finish')
        self.assertFalse([x['receipt'] for x in self.events if x['kind']=='channel_closed'][-1]['qualified'])

    async def test_data_before_open_duplicate_and_halfclose(self):
        with self.assertRaises(ValueError):await self.relay.accept(m.DATA,1,b'x')
        await self.ready()
        with self.assertRaises(ValueError):await self.relay.accept(m.OPEN,1,b'')
        await self.relay.accept(m.HALF_CLOSE,1,b'')
        with self.assertRaises(ValueError):await self.relay.accept(m.DATA,1,b'x')
        with self.assertRaises(ValueError):await self.relay.accept(m.HALF_CLOSE,1,b'')

    async def test_queue_overflow_no_drop(self):
        await self.ready();c=self.relay.channels[1]
        self.hosts[0][1].block=asyncio.Event()
        # Valid H2 upload data on an open request, bounded payload frame chunks.
        await self.relay.accept(m.DATA,1,h2(1,4,1,b'x'))
        wire=h2(0,0,1,b'x'*16384)
        with self.assertRaises(ValueError):
            for _ in range(80):await self.relay.accept(m.DATA,1,wire)
        self.assertLessEqual(self.relay.budget.total,m.PER_CHANNEL_QUEUE_BYTES)

    async def test_cancel_after_finish_only_and_previous_stream(self):
        await self.ready();await self.relay.accept(m.DATA,1,h2(1,5,1,b'x'))
        await self.relay.channels[1].queue.join()
        await self.relay.accept(m.FINISH,0,b'')
        self.hosts[0][0].feed_data(h2(3,0,1,(8).to_bytes(4,'big')))
        for _ in range(6):await asyncio.sleep(0)
        await self.relay.close_channel(self.relay.channels[1],'owner_finish')
        row=[x['receipt'] for x in self.events if x['kind']=='channel_closed'][-1]
        self.assertTrue(row['qualified']);self.assertEqual(row['finish_frontier']['active_stream_ids'],[1])

    async def test_prefinish_reset_cannot_be_excused(self):
        await self.ready();await self.relay.accept(m.DATA,1,h2(1,5,1,b'x'))
        self.hosts[0][0].feed_data(h2(3,0,1,(8).to_bytes(4,'big')))
        for _ in range(6):await asyncio.sleep(0)
        await self.relay.accept(m.FINISH,0,b'');await self.relay.close_channel(self.relay.channels[1],'owner_finish')
        self.assertIsNotNone(self.relay.failure)

    async def test_owner_eof_and_child_failure_terminal_fail_closed(self):
        self.input.feed_eof();result=await self.relay.run()
        self.assertFalse(result['owner_finish_received']);self.assertIsNotNone(result['error_type'])

    async def test_framed_finish_complete_handshake(self):
        self.input.feed_data(m.encode_frame(m.OPEN,1)+m.encode_frame(m.DATA,1,m.PREFACE+h2(4))+m.encode_frame(m.FINISH,0))
        self.input.feed_eof()
        result=await self.relay.run()
        self.assertTrue(result['owner_finish_received']);self.assertEqual(result['channels_closed'],1)
        self.assertEqual(result['queue_bytes_at_close'],0)
        p=m.FrameParser();frames=p.feed(bytes(self.output.data));p.finish()
        self.assertEqual([x[0] for x in frames],[m.OPENED,m.CLOSED])

    async def test_child_failure_without_parent_input_is_observed(self):
        self.child.code=7
        result=await asyncio.wait_for(self.relay.run(),1)
        self.assertEqual(result['error_type'],'ChildOrDiagnosticFailure')

    async def test_trailing_finish_partial_tail_and_missing_eof_fail(self):
        for suffix in (m.encode_frame(m.FINISH,0),b'R'):
            reader=asyncio.StreamReader();reader.feed_data(m.encode_frame(m.FINISH,0)+suffix);reader.feed_eof()
            relay=inside.Relay(reader,Writer(),lambda *a,**k:None,self.child,threading.Event())
            result=await relay.run()
            self.assertIsNotNone(result['error_type']);self.assertFalse(result['stdin_eof'])

    async def test_partial_host_frame_at_finish_is_unqualified(self):
        await self.ready();self.hosts[0][0].feed_data(b'\x00\x00')
        for _ in range(4):await asyncio.sleep(0)
        await self.relay.accept(m.FINISH,0,b'');await self.relay.close_channel(self.relay.channels[1],'owner_finish')
        self.assertIsNotNone(self.relay.failure)

    async def test_non_cancel_reset_after_finish_is_unqualified(self):
        await self.ready();await self.relay.accept(m.DATA,1,h2(1,5,1,b'x'))
        await self.relay.accept(m.FINISH,0,b'')
        self.hosts[0][0].feed_data(h2(3,0,1,(2).to_bytes(4,'big')))
        for _ in range(6):await asyncio.sleep(0)
        await self.relay.close_channel(self.relay.channels[1],'owner_finish')
        self.assertIsNotNone(self.relay.failure)

    async def test_connect_failure_is_not_retried(self):
        count=[]
        async def broken():count.append(1);raise OSError('synthetic')
        self.relay.connect=broken
        with self.assertRaises(OSError):await self.relay.accept(m.OPEN,1,b'')
        self.assertEqual(count,[1]);self.assertEqual(self.hosts,[])


class ParityTests(unittest.TestCase):
    def test_fixed_gateway_ast_is_identical_to_v2(self):
        here=Path(inside.__file__).parent
        def classes(path):
            tree=ast.parse(path.read_text());return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.ClassDef)}
        old,new=classes(here/'codehost_inside_v2.py'),classes(here/'codehost_inside_v3.py')
        for name in ('Handler','BoundedHTTPServer'):self.assertEqual(old[name],new[name])

    def test_entry_changes_only_inside_and_fixed_readonly_helper(self):
        original=['bwrap','--unshare-all','--ro-bind','old','/inside.py','--die-with-parent','/usr/bin/python3','-I','-B','/inside.py']
        actual=entry.replace_inside(original,'old','new','helper')
        restored=list(actual);index=restored.index('/codehost_mux_protocol.py');del restored[index-2:index+1]
        restored[restored.index('new')]='old';self.assertEqual(restored,original)
        for bad in (original+['x'],['bwrap']):
            with self.assertRaises(ValueError):entry.replace_inside(bad,'old','new','helper')

    def test_source_keys_and_metadata_namespace_schema(self):
        self.assertEqual(set(inside.sources()),{'codehost_inside_v3.py','codehost_mux_protocol.py'})
        stream=io.StringIO();meta=inside.Metadata(stream)
        value=meta.emit('ready',receipt={'schema':'different'})
        self.assertEqual(value['schema'],'campaign002-codehost-namespace-3')
        with mock.patch.object(inside,'MAX_METADATA_BYTES',1):
            with self.assertRaises(RuntimeError):meta.emit('more')


class OwnerLifecycleTests(unittest.IsolatedAsyncioTestCase):
    async def test_finish_handshake_binds_actual_child_cleanup(self):
        child=CleanupChild();reader=asyncio.StreamReader();writer=Writer()
        reader.feed_data(m.encode_frame(m.FINISH,0));reader.feed_eof()
        stream=io.StringIO();meta=inside.Metadata(stream);failed=threading.Event();ready=threading.Event();ready.set()
        meta.emit('open');meta.emit('child_started',child_pid=child.pid)
        async def streams():return reader,writer
        def diagnostics():
            for name in ('stdout','stderr'):meta.emit('child_diagnostic',stream=name,bytes=0,sha256=hashlib.sha256(b'').hexdigest(),truncated=False)
            return True
        with mock.patch.object(inside,'stdio_streams',streams):
            result=await inside.operate(child,meta,failed,ready,diagnostics)
        self.assertIs(type(result),int);self.assertEqual(result,0)
        self.assertEqual(child.terminations,1);self.assertEqual(child.kills,0)
        parser=m.FrameParser();frames=parser.feed(bytes(writer.data));parser.finish()
        self.assertEqual([x[0] for x in frames],[m.READY,m.FINISHED])
        rows=[__import__('json').loads(s[len(inside.PREFIX):]) for s in stream.getvalue().splitlines()]
        self.assertEqual(m.metadata(frames[-1][2]),rows[-1]);self.assertTrue(rows[-1]['qualified'])
        self.assertTrue(all(x['schema']=='campaign002-codehost-namespace-3' for x in rows))

    async def test_partial_startup_failure_still_terminates_child(self):
        child=CleanupChild();meta=inside.Metadata(io.StringIO())
        class NotReady:
            def wait(self,timeout):return False
        result=await inside.operate(child,meta,threading.Event(),NotReady(),lambda:True)
        self.assertEqual(result,1);self.assertEqual(child.terminations,1);self.assertEqual(child.kills,0)

    async def test_diagnostic_failure_prevents_success(self):
        child=CleanupChild();meta=inside.Metadata(io.StringIO());failed=threading.Event();failed.set();ready=threading.Event();ready.set()
        result=await inside.operate(child,meta,failed,ready,lambda:False)
        self.assertEqual(result,1);self.assertEqual(child.terminations,1)


if __name__ == '__main__':unittest.main()
