"""Original namespace entry, new fixed inside relay and read-only mux helper."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
BOUNDARY = HERE.parents[1] / 'readiness-session-10/boundary'


def replace_inside(argv, original, replacement, helper):
    result = list(argv)
    locations = [i for i in range(len(result)-2)
                 if result[i:i+3] == ['--ro-bind', str(original), '/inside.py']]
    if len(locations) != 1 or result[-4:] != ['/usr/bin/python3','-I','-B','/inside.py']:
        raise ValueError('Original namespace inside binding changed')
    if any('/codehost_mux_protocol.py' == item for item in result):
        raise ValueError('Duplicate fixed helper binding')
    result[locations[0]+1] = str(replacement)
    result[-4:-4] = ['--ro-bind', str(helper), '/codehost_mux_protocol.py']
    return result


def main():
    if len(sys.argv) < 2 or sys.argv[1] != 'codehost':
        raise SystemExit('Additive entry supports codehost mode only')
    sys.path.insert(0,str(BOUNDARY))
    import linux_entry
    original_command = linux_entry.command
    def command(*args, **kwargs):
        return replace_inside(original_command(*args, **kwargs), BOUNDARY/'inside.py',
                              HERE/'codehost_inside_v3.py', HERE/'codehost_mux_protocol.py')
    linux_entry.command = command
    linux_entry.main()


if __name__ == '__main__':
    main()
