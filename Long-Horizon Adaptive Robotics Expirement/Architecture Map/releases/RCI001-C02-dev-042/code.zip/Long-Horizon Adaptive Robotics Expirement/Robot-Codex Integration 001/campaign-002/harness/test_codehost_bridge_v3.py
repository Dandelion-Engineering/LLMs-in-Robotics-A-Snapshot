"""Deterministic in-memory bridge/namespace tests; no native, OS query or model."""
import asyncio
import hashlib
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from types import SimpleNamespace
from unittest import mock

import codehost_bridge_v3 as bridge
import codehost_inside_v3 as inside
import codehost_mux_protocol as m
from codehost_owner import OwnerError


def h2(kind, flags=0, stream=0, payload=b''):
    return len(payload).to_bytes(3,'big') + bytes([kind,flags]) + stream.to_bytes(4,'big') + payload


class Pipe:
    def __init__(self, reader): self.reader=reader; self.closed=False
    def write(self, data):
        if self.closed: raise BrokenPipeError('closed pipe')
        self.reader.feed_data(data)
    async def drain(self): await asyncio.sleep(0)
    def close(self):
        if not self.closed: self.closed=True; self.reader.feed_eof()
    async def wait_closed(self): pass


class NativeSocket:
    def __init__(self, reader, port, *, eof_after_response=False):
        self.reader=reader; self.port=port; self.eof_after_response=eof_after_response
        self.data=bytearray(); self.closed=False; self.received=asyncio.Event()
    def get_extra_info(self, name): return ('127.0.0.1',self.port if name=='peername' else 32100)
    def write(self, data):
        self.data.extend(data); self.received.set()
        if self.eof_after_response: self.reader.feed_eof(); self.eof_after_response=False
    async def drain(self): await asyncio.sleep(0)
    def close(self): self.closed=True
    async def wait_closed(self): pass


class FakeOwner:
    def __init__(self): self.owner=None; self.calls=[]; self.reject=None; self.gate=None
    def register(self, process, binary):
        if self.owner is not None: raise ValueError('already registered')
        self.owner={'schema':'campaign002-native-owner-1','pid':123,'process_creation_filetime':456,
                    'owner_kind':'model_client','executable':{'path':'fake-native','sha256':'a'*64}}
        return dict(self.owner)
    def authenticate(self, client, server):
        self.calls.append((client,server,threading.get_ident()))
        if self.gate: self.gate.wait(1)
        if self.reject: raise OwnerError(self.reject)
        if self.owner is None: raise ValueError('unregistered')
        return {'schema':'campaign002-channel-owner-1','owner_pid':123,'client':list(client),'server':list(server)}


class SharedHost:
    """Actual Linux Relay and framing in memory, with opaque fake H2 service."""
    def __init__(self, *, respond=True, corrupt=False, terminal_change=None):
        self.stdout=asyncio.StreamReader(); self.stderr=asyncio.StreamReader()
        self.input=asyncio.StreamReader(); self.stdin=Pipe(self.input); self.returncode=None
        self.metadata_stream=io.StringIO(); self.metadata=inside.Metadata(self.metadata_stream)
        self.child=SimpleNamespace(pid=789,poll=lambda:None)
        self.hosts=[]; self.respond=respond; self.corrupt=corrupt; self.terminal_change=terminal_change or {}
        self.relay=inside.Relay(self.input,Pipe(self.stdout),self.metadata.emit,self.child,threading.Event(),self.connect)
        self.task=asyncio.create_task(self.operate())
    async def connect(self):
        reader=asyncio.StreamReader(); host=self
        class Socket:
            def __init__(self): self.data=bytearray(); self.sent=False; self.closed=False
            def write(self,data):
                self.data.extend(data)
                if host.respond and not self.sent:
                    # Each test sends one complete preface/settings/request chunk.
                    self.sent=True
                    reply=h2(4)+h2(1,5,1,b'\x88')
                    if host.corrupt: reply=reply[:-1]
                    reader.feed_data(reply)
            async def drain(self): await asyncio.sleep(0)
            def write_eof(self): reader.feed_eof()
            def close(self): self.closed=True
            async def wait_closed(self): pass
        writer=Socket(); self.hosts.append((reader,writer)); return reader,writer
    async def operate(self):
        self.metadata.emit('open',sources={})
        self.metadata.emit('child_started',child_pid=self.child.pid)
        ready={'schema':'campaign002-codehost-owner-ready-3','child_pid':self.child.pid,
               'max_connections':16,'max_frame_bytes':65536,'per_channel_queue_bytes':1048576,
               'aggregate_queue_bytes':4194304,'sources':{}}
        self.metadata.emit('ready',receipt=ready)
        await self.relay.send(m.READY,0,m.canonical(ready))
        result=await self.relay.run(); error=result.pop('error_type')
        for stream in ('stdout','stderr'):
            self.metadata.emit('child_diagnostic',stream=stream,bytes=0,sha256=hashlib.sha256(b'').hexdigest(),truncated=False)
        fields=dict(qualified=error is None,reason='owner_finish' if error is None else 'error',
            child_pid=self.child.pid,child_exit_before_cleanup=None,child_exit_code=-15,terminate_sent=True,
            kill_sent=False,diagnostic_streams_complete=True,error_type=error,sources={},**result)
        fields.update(self.terminal_change)
        final=self.metadata.emit('closed',**fields)
        await self.relay.send(m.FINISHED,0,m.canonical(final),account=False)
        self.stdout.feed_eof()
        self.stderr.feed_data(self.metadata_stream.getvalue().encode()); self.stderr.feed_eof()


class BridgeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.folder=Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.fixture=SimpleNamespace(evidence=self.folder,run='/fake/run',abort_event=threading.Event(),
            client_finishing=threading.Event(),redact=lambda v:v,argv=lambda mode:['fake-entry',mode])
        self.owner=FakeOwner(); self.launches=[]; self.retirements=[]; self.process=None
        self.retirement_qualified=True; self.wrapper_exit=0
        self.host_options={}
        async def launch(*args,**kwargs):
            self.launches.append((args,kwargs)); self.process=SharedHost(**self.host_options); return self.process
        async def retire(process,identity,path):
            self.retirements.append(identity)
            await asyncio.wait_for(process.task,2); process.returncode=self.wrapper_exit
            path.write_text(json.dumps({'qualified':self.retirement_qualified}))
        self.bridge=bridge.Bridge(self.fixture,owner=self.owner,launcher=launch,retirer=retire,sources={})
        class Server:
            sockets=[SimpleNamespace(getsockname=lambda:('127.0.0.1',32100))]
            def close(self): pass
            async def wait_closed(self): pass
        self.enterContext(mock.patch.object(bridge,'create_server',new=mock.AsyncMock(return_value=Server())))
    async def run_bridge(self, body, *, register=True, fail=False):
        async def callback(url):
            self.assertEqual(url,'http://127.0.0.1:32100')
            if register: self.fixture.native_process_ready(object(),'fake-native')
            try: await body()
            finally: self.fixture.client_finishing.set()
            return 'callback-result'
        if fail:
            with self.assertRaises(RuntimeError): await asyncio.wait_for(self.bridge.run(callback),5)
        else:
            self.assertEqual(await asyncio.wait_for(self.bridge.run(callback),5),'callback-result')
        self.assertEqual(len(self.launches),1); self.assertEqual(len(self.retirements),1)
        return json.loads((self.folder/'codehost-owner-bridge-v3.json').read_text())
    def client(self, index=1, *, natural=False, payload=b'\x82'):
        reader=asyncio.StreamReader(); reader.feed_data(m.PREFACE+h2(4)+h2(1,5,1,payload))
        writer=NativeSocket(reader,40000+index,eof_after_response=natural)
        task=asyncio.create_task(self.bridge.handle(reader,writer))
        return reader,writer,task
    async def test_two_concurrent_channels_one_host_opaque_order_and_receipts(self):
        clients=[]
        async def body():
            clients.extend([self.client(1,natural=True,payload=b'one'),self.client(2,natural=True,payload=b'two')])
            await asyncio.gather(*(c[2] for c in clients))
        receipt=await self.run_bridge(body)
        self.assertTrue(receipt['qualified']); self.assertEqual(receipt['accepted'],2)
        self.assertEqual(len(self.process.hosts),2); self.assertNotEqual(self.process.hosts[0][1].data,self.process.hosts[1][1].data)
        self.assertEqual(receipt['queued_bytes_at_close'],0)
        self.assertTrue(all(x[2] != threading.get_ident() for x in self.owner.calls))
        for channel in receipt['channels']:
            self.assertEqual(channel['namespace_closed']['reason'],'clean_idle_eof')
            self.assertEqual(channel['meters']['client_read'],channel['namespace_closed']['upload'])
            self.assertEqual(channel['meters']['client_written'],channel['namespace_closed']['download'])
        events=self.bridge.ledger.events
        previous=None
        for n,event in enumerate(events,1):
            value=dict(event); digest=value.pop('record_sha256')
            self.assertEqual(bridge.sha(m.canonical(value)),digest);self.assertEqual(event['previous_sha256'],previous)
            self.assertEqual(event['sequence'],n);previous=digest
        self.assertLess(next(i for i,e in enumerate(events) if e['kind']=='owner_registered'),
                        next(i for i,e in enumerate(events) if e['kind']=='channel_authenticated'))
        self.assertTrue(any(e['kind']=='namespace_finished' for e in events))
        self.assertTrue(any(e['kind']=='owner_input_closed' for e in events))
    async def test_owner_finish_keeps_download_sink_until_accounted_close(self):
        async def body():
            _,writer,_=self.client(); await writer.received.wait()
        receipt=await self.run_bridge(body)
        self.assertTrue(receipt['qualified']);self.assertEqual(receipt['channels'][0]['namespace_closed']['reason'],'owner_finish')
        self.assertTrue(self.process.stdin.closed); self.assertEqual(receipt['channels'][0]['meters']['download'],receipt['channels'][0]['meters']['client_written'])
    async def test_finish_event_closes_namespace_before_callback_returns(self):
        async def body():
            _,writer,_=self.client();await writer.received.wait()
            self.fixture.client_finishing.set()
            await asyncio.wait_for(asyncio.shield(self.bridge.finished),1)
            self.assertTrue(self.process.stdin.closed)
            self.assertTrue(self.bridge.finishing)
        receipt=await self.run_bridge(body)
        self.assertTrue(receipt['qualified'])
    async def test_missing_owner_rejects_before_open_or_client_read(self):
        async def body():
            reader,writer,task=self.client(); await task
            self.assertGreater(len(reader._buffer),0); self.assertFalse(writer.data)
        receipt=await self.run_bridge(body,register=False,fail=True)
        self.assertEqual(receipt['accepted'],0);self.assertEqual(receipt['denied'],1);self.assertEqual(self.owner.calls,[])
        self.assertFalse(any(e.get('frame_type')==m.OPEN for e in self.bridge.ledger.events))
    async def test_foreign_owner_rejects_before_open_or_client_read(self):
        self.owner.reject='foreign_tcp_owner'
        async def body():
            reader,writer,task=self.client(); await task
            self.assertGreater(len(reader._buffer),0);self.assertFalse(writer.data)
        receipt=await self.run_bridge(body,fail=True)
        self.assertEqual(receipt['accepted'],0);self.assertEqual(len(self.process.hosts),0)
        self.assertIn('channel_OwnerError',receipt['failures'])
        self.assertEqual(next(e['reason'] for e in self.bridge.ledger.events if e['kind']=='channel_denied'),'foreign_tcp_owner')
    async def test_repeated_registration_aborts_without_overwriting_receipt(self):
        async def body():
            before=(self.folder/'codehost-native-owner-v3.json').read_bytes()
            with self.assertRaises(ValueError):self.fixture.native_process_ready(object(),'other')
            self.assertEqual((self.folder/'codehost-native-owner-v3.json').read_bytes(),before)
        receipt=await self.run_bridge(body,fail=True)
        self.assertEqual(receipt['accepted'],0);self.assertTrue(self.fixture.abort_event.is_set())
    async def test_seventeenth_attempt_rejected_before_authentication(self):
        self.bridge.attempts=16
        async def body():
            _,_,task=self.client();await task
        receipt=await self.run_bridge(body,fail=True)
        self.assertEqual(receipt['attempts'],17);self.assertEqual(self.owner.calls,[])
    async def test_upload_queue_caps_are_fail_closed_without_partial_reserve(self):
        self.bridge.channels[1]=bridge.Channel(1,None,None,{})
        self.bridge.channels[2]=bridge.Channel(2,None,None,{})
        per_channel=(m.PER_CHANNEL_QUEUE_BYTES-bridge.FRAME_HEADROOM_BYTES)//65536
        for _ in range(per_channel):self.bridge.enqueue(m.DATA,1,b'a'*65536)
        with self.assertRaises(ValueError):self.bridge.enqueue(m.DATA,1,b'b')
        self.assertEqual(self.bridge.budget.total,m.PER_CHANNEL_QUEUE_BYTES-bridge.FRAME_HEADROOM_BYTES)
        channel=2
        while self.bridge.budget.total+bridge.FRAME_HEADROOM_BYTES < m.AGGREGATE_QUEUE_BYTES:
            for _ in range(per_channel):
                if self.bridge.budget.total+bridge.FRAME_HEADROOM_BYTES == m.AGGREGATE_QUEUE_BYTES:break
                self.bridge.enqueue(m.DATA,channel,b'b'*65536)
            channel+=1
        with self.assertRaises(ValueError):self.bridge.enqueue(m.DATA,channel,b'x')
        self.assertEqual(self.bridge.budget.total+bridge.FRAME_HEADROOM_BYTES,m.AGGREGATE_QUEUE_BYTES)
    async def test_prefinish_inflight_client_eof_is_permanent_failure(self):
        self.host_options['respond']=False
        async def body():
            reader,_,task=self.client();reader.feed_eof();await task
        receipt=await self.run_bridge(body,fail=True)
        self.assertFalse(receipt['qualified']);self.assertTrue(any('channel_' in x for x in receipt['failures']))
    async def test_reset_cannot_be_retroactively_excused(self):
        channel=bridge.Channel(1,None,None,{})
        self.bridge.channels[1]=channel
        self.bridge.feed_h2(channel,'upload',m.PREFACE+h2(4)+h2(1,5,1,b'x'))
        self.bridge.feed_h2(channel,'download',h2(4))
        with self.assertRaisesRegex(ValueError,'reset_before_owner_finish'):
            self.bridge.feed_h2(channel,'download',h2(3,0,1,(8).to_bytes(4,'big')))
        self.fixture.client_finishing.set()
        with self.assertRaisesRegex(ValueError,'reset_before_owner_finish'):self.bridge.observe_finishing()
    async def test_finish_allows_only_cancel_for_previously_active_stream(self):
        channel=bridge.Channel(1,None,None,{})
        self.bridge.channels[1]=channel
        self.bridge.feed_h2(channel,'upload',m.PREFACE+h2(4)+h2(1,5,1,b'x'))
        self.bridge.feed_h2(channel,'download',h2(4));self.fixture.client_finishing.set()
        self.bridge.feed_h2(channel,'download',h2(3,0,1,(8).to_bytes(4,'big')))
        self.assertEqual(channel.finish_frontier['active_stream_ids'],[1])
        bad=bridge.Channel(2,None,None,{})
        self.bridge.channels[2]=bad
        bad.h2.feed('upload',m.PREFACE+h2(4)+h2(1,5,1,b'x'));bad.h2.feed('download',h2(4))
        with self.assertRaises(ValueError):self.bridge.feed_h2(bad,'download',h2(3,0,1,(2).to_bytes(4,'big')))
    async def test_unverified_retirement_never_qualifies(self):
        self.retirement_qualified=False
        async def body():pass
        receipt=await self.run_bridge(body,fail=True)
        self.assertFalse(receipt['qualified']);self.assertIn('owner_retirement_ValueError',receipt['failures'])
    async def test_child_status_cannot_be_masked_by_qualified_namespace_flag(self):
        self.host_options['terminal_change']={'child_exit_code':7,'qualified':True}
        async def body():pass
        receipt=await self.run_bridge(body,fail=True)
        self.assertFalse(receipt['qualified']);self.assertIn('namespace_receipt_ValueError',receipt['failures'])
        self.assertEqual(receipt['namespace_records'][-1]['child_exit_code'],7)
        self.assertEqual(bridge.sha((self.folder/receipt['stderr']['path']).read_bytes()),receipt['stderr']['sha256'])
    async def test_nonzero_wrapper_exit_never_qualifies(self):
        self.wrapper_exit=7
        async def body():pass
        receipt=await self.run_bridge(body,fail=True)
        self.assertIn('namespace_wrapper_nonzero',receipt['failures'])
    async def test_endpoint_mismatch_rejected_before_channel_closed(self):
        reader=asyncio.StreamReader();writer=NativeSocket(reader,40001)
        channel=bridge.Channel(1,reader,writer,{})
        self.bridge.channels[1]=channel;channel.state='closed'
        channel.h2.feed('upload',m.PREFACE+h2(4));channel.h2.feed('download',h2(4))
        channel.namespace_closed={'qualified':True,'reason':'clean_idle_eof','upload':{'bytes':1,'sha256':'a'*64},
                                  'download':channel.meters['download'].summary()}
        channel.queue.put_nowait(None)
        with self.assertRaisesRegex(ValueError,'relay_endpoint_byte_mismatch'):await self.bridge.sink(channel)
        channel.closed.exception()
        self.assertFalse(any(e['kind']=='channel_closed' for e in self.bridge.ledger.events))
    async def test_malformed_partial_or_data_before_opened_fail_closed(self):
        for wire in (b'bad',m.encode_frame(m.DATA,1,b'x'),m.encode_frame(m.OPENED,1)*2):
            with self.subTest(wire=wire[:14]):
                other_folder=self.folder/str(len(self.bridge.ledger.events));other_folder.mkdir()
                fixture=SimpleNamespace(**vars(self.fixture));fixture.evidence=other_folder
                b=bridge.Bridge(fixture,owner=self.owner,launcher=mock.AsyncMock(),retirer=mock.AsyncMock(),sources={})
                loop=asyncio.get_running_loop();b.ready=loop.create_future();b.ready.set_result({});b.finished=loop.create_future()
                c=bridge.Channel(1,None,None,{});b.channels[1]=c
                output=asyncio.StreamReader();output.feed_data(wire);output.feed_eof();b.process=SimpleNamespace(stdout=output)
                with self.assertRaises(ValueError):await b.receive_frames()
                for future in (b.finished,c.opened,c.closed):
                    if future.done():future.exception()
                self.assertTrue(b.failures)
                # Give subsequent subtests a unique retained metadata directory.
                self.bridge.ledger.emit('synthetic_case_complete')
    async def test_receipt_size_bound_is_checked_before_file_creation(self):
        target=self.folder/'too-large.json'
        with mock.patch.object(bridge,'MAX_RECEIPT_BYTES',8):
            with self.assertRaisesRegex(ValueError,'protected_receipt_bound'):bridge.save(target,{'payload':'abcdef'})
        self.assertFalse(target.exists())
    async def test_pending_client_read_is_reserved_and_released_on_cancel(self):
        reader=asyncio.StreamReader();channel=bridge.Channel(1,reader,None,{})
        self.bridge.channels[1]=channel
        task=asyncio.create_task(self.bridge.upload(channel));await asyncio.sleep(0)
        self.assertEqual(self.bridge.budget.total,65536)
        task.cancel();await asyncio.gather(task,return_exceptions=True)
        self.assertEqual(self.bridge.budget.total,0)
        self.assertEqual(self.bridge.budget.channel_maximum[1],65536)
    async def test_native_bytes_crossing_finish_are_not_retroactively_forwarded(self):
        reader=asyncio.StreamReader();reader.feed_data(m.PREFACE+h2(4))
        channel=bridge.Channel(1,reader,None,{});self.bridge.channels[1]=channel
        self.fixture.client_finishing.set()
        with self.assertRaisesRegex(ValueError,'client_data_after_owner_finish'):await self.bridge.upload(channel)
        self.assertTrue(self.bridge.outgoing.empty());self.assertEqual(self.bridge.budget.total,0)


class SocketAdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_raw_adapter_reads_exact_requested_bound_and_has_one_pending_write(self):
        sock=SimpleNamespace(getpeername=lambda:('127.0.0.1',40000),getsockname=lambda:('127.0.0.1',32100),close=mock.Mock())
        loop=SimpleNamespace(sock_recv=mock.AsyncMock(return_value=b'abc'),sock_sendall=mock.AsyncMock())
        reader=bridge.SocketReader(sock);writer=bridge.SocketWriter(sock)
        with mock.patch.object(asyncio,'get_running_loop',return_value=loop):
            self.assertEqual(await reader.read(3),b'abc');loop.sock_recv.assert_awaited_once_with(sock,3)
            writer.write(b'abc')
            with self.assertRaises(ValueError):writer.write(b'more')
            await writer.drain();loop.sock_sendall.assert_awaited_once_with(sock,b'abc')
            self.assertIsNone(writer.pending)
        writer.close();await writer.wait_closed();sock.close.assert_called_once()


if __name__=='__main__':unittest.main()
