"""Deterministic source/receipt/client tests; never create a native fixture."""
import argparse
import asyncio
import copy
import io
import json
import os
from pathlib import Path
import tempfile
import threading
import types
import unittest
from unittest import mock

import codehost_transport_probe_v3 as p
import raw_event_preflight_v2 as raw


def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value)+'\n',encoding='utf-8')


def canaries(root):
    write(root/'canary-stdout.json',{'qualified':True,'checks':{str(i):True for i in range(45)}})
    write(root/'codehost-canary-stdout.json',{'host_qualified':True,'model_calls':0,'enabled_tools':[],
        'checks':{'tools':[],'all_tools_count':0,'constructor_process_type':'undefined',
        'apis':{k:'undefined' for k in ('process','require','fetch','Deno','Bun','WebSocket','XMLHttpRequest')},
        'imports':{k:'denied' for k in ('node:fs','file:///etc/passwd','https://example.invalid/')}}})


class ReplayTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)/'output';self.root.mkdir()
        self.snapshot=Path(self.temp.name)/'snapshot.json';write(self.snapshot,{'revision':'dev-test'})
        self.frozen={'revision':'dev-test','sources':{'fixed.py':{'sha256':'a'*64,'bytes':1}}}
        self.source={'schema':'campaign002-channel-probe-source-3','run_id':'fixed-run','framework_revision':'dev-test',
            'snapshot_sha256':p.binding(self.snapshot)['sha256'],'source_bindings':self.frozen['sources'],
            'cases':p.make_cases(),'model_calls':0,'physical_simulation':False}
        write(self.root/'source-binding.json',self.source)
        self.proofs={}
        for case in p.CASES:
            root=self.root/case;root.mkdir();canaries(root)
            write(root/'cleanup.json',{'clean':True,'errors':[]})
            write(root/'case-run.json',{'schema':'campaign002-channel-case-run-3','case':case,
                'cleanup_clean':True,'setup_error_type':None,'canaries_completed':True,
                'elapsed_seconds':110,'start_monotonic_s':1,'end_monotonic_s':111,
                'bridge_completed':case=='multi_channel','bridge_error_type':None if case=='multi_channel' else 'RuntimeError'})
            write(root/'client-result.json',{'schema':'campaign002-channel-client-3','case':case,'completed':True,
                'model_calls':0,'child_exit_codes':{'owner':0,**({'foreign':0} if case=='foreign_owner' else {})},
                'result':{'idle_seconds':95,'channels':[{'channel_id':i,'closed_before_finish':i==2} for i in (1,2,3)]}})
            write(root/'proof-input.json',{'case':case})
            self.proofs[case]={'input_bindings':{'proof-input.json':p.binding(root/'proof-input.json')}}
            if case=='multi_channel':self.proofs[case]['passed']=True
            else:self.proofs[case].update(expected_failure_verified=True,diagnostic_only=True,ordinary_transport_passed=False)
        write(self.root/'multi_channel/codehost-owner-bridge-v3.json',{'accepted':3,'denied':0,
            'channels':[{'channel_id':2,'namespace_closed':{'reason':'clean_idle_eof'}}]})
        self.events=[{'kind':'channel_authenticated','channel_id':1,'monotonic_s':1},
            {'kind':'channel_authenticated','channel_id':2,'monotonic_s':97},
            {'kind':'channel_closed','channel_id':2,'monotonic_s':98},
            {'kind':'channel_authenticated','channel_id':3,'monotonic_s':99},
            {'kind':'channel_closed','channel_id':1,'monotonic_s':101},
            {'kind':'channel_closed','channel_id':3,'monotonic_s':102}]
        self.ledger()
        self.verifier=types.SimpleNamespace(
            verify_transport_integrity=lambda root,frozen,**kw:copy.deepcopy(self.proofs[Path(root).name]),
            verify_expected_failure=lambda root,frozen,**kw:copy.deepcopy(self.proofs[Path(root).name]))
        def dep(name):
            return {'raw_event_preflight_v2':raw,'transport_integrity_v3':self.verifier}[name]
        self.addCleanup(mock.patch.stopall)
        mock.patch.object(p,'dependency',side_effect=dep).start()
        mock.patch.object(p,'validate_snapshot',return_value=self.frozen).start()

    def ledger(self):
        (self.root/'multi_channel/codehost-transport-v3.jsonl').write_text(
            ''.join(json.dumps(e)+'\n' for e in self.events),encoding='utf-8')

    def mutate(self,path,fn):
        target=self.root/path;value=json.loads(target.read_text());fn(value);write(target,value)

    def result(self):return p.assess(self.root,self.snapshot)

    def test_replay_stable_with_exact_three_scopes_and_bound_inputs(self):
        result=self.result();self.assertTrue(result['passed'],result)
        self.assertEqual(result,self.result());self.assertEqual(result['model_calls'],0)
        self.assertEqual([r['production_qualified'] for r in result['cases']],[True,False,False])
        self.assertIn('foreign_owner/proof-input.json',result['inputs'])

    def test_false_or_nonboolean_production_proof_never_passes(self):
        for value in (False,1,None):
            self.proofs['multi_channel']['passed']=value;self.assertFalse(self.result()['passed'])

    def test_expected_failure_cannot_become_production_success(self):
        for key,value in [('expected_failure_verified',False),('diagnostic_only',1),('ordinary_transport_passed',True)]:
            original=self.proofs['foreign_owner'][key];self.proofs['foreign_owner'][key]=value
            self.assertFalse(self.result()['passed']);self.proofs['foreign_owner'][key]=original

    def test_missing_or_changed_dependent_input_fails(self):
        self.proofs['in_flight_eof']['input_bindings']={};self.assertFalse(self.result()['passed'])
        self.proofs['in_flight_eof']['input_bindings']={'proof-input.json':{'bytes':1,'sha256':'0'*64}}
        self.assertFalse(self.result()['passed'])

    def test_source_declaration_type_and_identity_strict(self):
        for change in (lambda s:s.update(model_calls=False),lambda s:s['cases'][0].update(model_calls=False),
                       lambda s:s.update(snapshot_sha256='0'*64),lambda s:s['source_bindings']['fixed.py'].update(bytes=True)):
            value=copy.deepcopy(self.source);change(value);write(self.root/'source-binding.json',value)
            self.assertFalse(self.result()['passed'])

    def test_lifetime_close_sequence_and_legacy_event_rejected(self):
        saved=copy.deepcopy(self.events)
        for index,key,value in ((1,'monotonic_s',95),(2,'monotonic_s',100),(0,'kind','connection_accepted')):
            self.events=copy.deepcopy(saved);self.events[index][key]=value;self.ledger()
            self.assertFalse(self.result()['passed'])

    def test_time_cap_cleanup_and_child_exit_are_strict(self):
        file='foreign_owner/case-run.json'
        self.mutate(file,lambda v:v.update(elapsed_seconds=181,end_monotonic_s=182))
        self.assertFalse(self.result()['passed'])
        self.mutate(file,lambda v:v.update(elapsed_seconds=110,end_monotonic_s=111))
        self.mutate('foreign_owner/client-result.json',lambda v:v.update(child_exit_codes={}))
        self.assertFalse(self.result()['passed'])
        self.mutate('foreign_owner/client-result.json',lambda v:v.update(child_exit_codes={'owner':0,'foreign':False}))
        self.assertFalse(self.result()['passed'])

    def test_canary_failure_and_output_bound_fail(self):
        self.mutate('multi_channel/canary-stdout.json',lambda v:v['checks'].update({'0':1}))
        self.assertFalse(self.result()['passed'])
        canaries(self.root/'multi_channel')
        with mock.patch.object(p,'CASE_BYTES',10):self.assertFalse(self.result()['passed'])


class SourceRunTests(unittest.TestCase):
    def test_validate_before_fixture_or_output(self):
        with tempfile.TemporaryDirectory() as temp:
            output=Path(temp)/'new';args=argparse.Namespace(snapshot=Path(temp)/'bad.json',framework_revision='x',run_id='r',output=output)
            with mock.patch.object(p,'validate_snapshot',side_effect=ValueError('bad source')),mock.patch.object(p,'run_case') as launch:
                with self.assertRaises(ValueError):p.run(args)
                launch.assert_not_called();self.assertFalse(output.exists())

    def test_existing_output_never_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);args=argparse.Namespace(snapshot=root/'s.json',framework_revision='x',run_id='r',output=root)
            with mock.patch.object(p,'validate_snapshot',return_value={'sources':{}}),mock.patch.object(p,'run_case') as launch:
                with self.assertRaises(FileExistsError):p.run(args)
                launch.assert_not_called()

    def test_source_closure_is_present_and_contains_test_method_protocol(self):
        sources=p.required_sources()
        self.assertTrue(all((p.REPO/n).is_file() for n in sources))
        for tail in ('test_codehost_transport_probe_v3.py','CODEHOST_CHANNEL_TRANSPORT_V3.md','codehost_mux_protocol.py',
                     'CHANNEL_PROBE_PROCESS_IDENTITY_V1.md'):
            self.assertTrue(any(n.endswith('/'+tail) for n in sources),tail)

    def test_partial_runtime_initialization_still_closes(self):
        class Runtime:
            closed=False
            def __init__(self,root,files):root.mkdir();raise ValueError('setup')
            def close(self):type(self).closed=True;return True
        with tempfile.TemporaryDirectory() as temp,mock.patch.object(p,'dependency',return_value=types.SimpleNamespace(Runtime=Runtime,template=lambda k:{})):
            result=p.run_case(Path(temp)/'case','multi_channel')
            self.assertTrue(Runtime.closed);self.assertEqual(result['setup_error_type'],'ValueError')
            self.assertFalse(result['bridge_completed'])


class FixedClientTests(unittest.TestCase):
    def exercise(self,mode):
        clock=[0];instances=[]
        class Channel:
            def __init__(self,port,channel_id,emit):
                self.id=channel_id;self.closed=False;self.sock=mock.Mock();self.ping=None;instances.append(self)
            def handshake(self,ping):self.ping=ping
            def close_idle(self):self.closed=True
            def summary(self):return {'channel_id':self.id,'closed_before_finish':self.closed}
        def sleep(seconds):clock[0]+=seconds
        with mock.patch.object(p,'SyntheticChannel',Channel),mock.patch.object(p.time,'sleep',side_effect=sleep),\
             mock.patch.object(p.time,'monotonic',side_effect=lambda:clock[0]),mock.patch.object(p.sys,'stdin',io.StringIO('{"port":1234}\n{"finish":true}\n')),\
             mock.patch.object(p.sys,'stdout',io.StringIO()) as output:
            code=p.client_main(mode);events=[json.loads(s) for s in output.getvalue().splitlines()]
        return code,events,instances

    def test_boundary_same_fixed_client_one_second_one_channel(self):
        code,events,channels=self.exercise('boundary_single_channel')
        self.assertEqual(code,0);self.assertEqual(len(channels),1);self.assertTrue(channels[0].ping)
        result=next(e['result'] for e in events if e['kind']=='ready_to_finish')
        self.assertEqual(result['idle_seconds'],1);self.assertEqual(events[-1]['kind'],'client_closed')

    def test_multi_channel_has_fixed_95_second_overlap_and_no_rpc(self):
        code,events,channels=self.exercise('multi_channel')
        self.assertEqual(code,0);self.assertEqual([c.id for c in channels],[1,2,3]);self.assertTrue(all(c.ping for c in channels))
        result=next(e['result'] for e in events if e['kind']=='ready_to_finish')
        self.assertEqual(result['idle_seconds'],95)
        self.assertEqual([c['closed_before_finish'] for c in result['channels']],[False,True,False])
        self.assertEqual(len(p.PARTIAL_INPUT),45)

    def test_unknown_mode_fails_before_output_or_connection(self):
        with mock.patch.object(p,'SyntheticChannel') as channel:
            with self.assertRaises(ValueError):p.client_main('custom')
            channel.assert_not_called()


class DriverTests(unittest.IsolatedAsyncioTestCase):
    async def exercise_driver(self,case='boundary_single_channel',ready_changes=None,stderr=b'',exit_code=0,
                              duplicate_pid=False,executable_changed=False):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);root=Path(temp.name)
        children=[];exe={'path':'declared-base-python','bytes':10,'sha256':'a'*64,'file_identity':[1,2,10,4]}
        ready_changes=ready_changes or {}
        result={'ready_to_finish':True,'idle_seconds':95,'channels':[{'channel_id':1}],
                'client':['127.0.0.1',2345],'server':['127.0.0.1',1234],'denial_eof_observed':True}
        class Process:
            def __init__(self,argv,**kw):
                self.argv=argv;self.pid=111 if not children or duplicate_pid else 222;self.returncode=None
                self.role='owner' if not children else 'foreign';self.stdin=io.BytesIO()
                ready={'kind':'client_ready','pid':self.pid,'mode':argv[-1],**ready_changes.get(self.role,{})}
                events=[ready,{'kind':'ready_to_finish','result':result}]
                self.stdout=io.BytesIO(b''.join(p.canonical(e)+b'\n' for e in events))
                self.stderr=io.BytesIO(stderr);children.append(self)
            def poll(self):return self.returncode
            def wait(self,timeout):self.returncode=exit_code;return exit_code
        def observe(pid):return {'pid':pid,'process_creation_filetime':pid+1,'queried_executable_path':exe['path']}
        owner=types.SimpleNamespace(WindowsOwnerAPI=lambda:types.SimpleNamespace(process=observe))
        def register(process,path):return {'schema':'campaign002-native-owner-1','owner_kind':'transport_probe',
                                          **observe(process.pid),'executable':exe,'wall_unix_s':1,'monotonic_s':1}
        fixture=types.SimpleNamespace(evidence=root,client_finishing=threading.Event(),
                                     native_process_ready=mock.Mock(side_effect=register),redact=lambda s:s.replace('SECRET','[REDACTED]'))
        values=[exe,{**exe,'sha256':'b'*64}] if executable_changed else None
        with mock.patch.object(p.subprocess,'Popen',Process),mock.patch.object(p,'dependency',return_value=owner),\
             mock.patch.object(p,'client_executable',side_effect=values,return_value=exe):
            try:
                value=await p.drive_clients('http://127.0.0.1:1234',fixture,case,p.time.monotonic()+180)
                raised=None
            except Exception as exc:value=None;raised=exc
        record=json.loads((root/'client-result.json').read_text(encoding='utf-8'))
        return root,children,fixture,record,raised,value

    async def test_direct_executable_and_matching_actual_popen_registration(self):
        root,children,fixture,record,raised,value=await self.exercise_driver()
        self.assertIsNone(raised);self.assertTrue(record['completed']);self.assertTrue(value['completed'])
        self.assertEqual(children[0].argv[0],'declared-base-python')
        self.assertIs(fixture.native_process_ready.call_args.args[0],children[0])
        self.assertEqual(fixture.native_process_ready.call_args.args[1],children[0].argv[0])
        self.assertEqual(json.loads(children[0].stdin.getvalue().splitlines()[0]),{'port':1234})
        self.assertTrue(record['diagnostics']['owner']['complete'])
        self.assertEqual(json.loads((root/'client-executable.json').read_text()),record['launch_executable'])

    async def test_owner_ready_pid_mode_type_and_first_event_fail_before_port(self):
        for change in ({'pid':222},{'pid':True},{'mode':'foreign'},{'kind':'premature_event'}):
            with self.subTest(change=change):
                root,children,fixture,record,raised,_=await self.exercise_driver(ready_changes={'owner':change})
                self.assertIsInstance(raised,ValueError);self.assertFalse(record['completed'])
                self.assertEqual(record['error_type'],'ValueError');fixture.native_process_ready.assert_not_called()
                self.assertNotIn(b'"port"',children[0].stdin.getvalue())
                self.assertTrue((root/'client/owner-stdout.txt').is_file())

    async def test_foreign_role_exact_ready_and_distinct_pid_gate_before_its_port(self):
        for change,duplicate in [({'pid':111},False),({'mode':'hold'},False),({},True)]:
            with self.subTest(change=change,duplicate=duplicate):
                _,children,fixture,record,raised,_=await self.exercise_driver('foreign_owner',
                    ready_changes={'foreign':change},duplicate_pid=duplicate)
                self.assertIsInstance(raised,ValueError);self.assertFalse(record['completed'])
                self.assertEqual(fixture.native_process_ready.call_count,1)
                self.assertIn(b'"port"',children[0].stdin.getvalue());self.assertNotIn(b'"port"',children[1].stdin.getvalue())

    async def test_foreign_role_uses_same_executable_distinct_actual_process(self):
        _,children,fixture,record,raised,_=await self.exercise_driver('foreign_owner')
        self.assertIsNone(raised);self.assertTrue(record['completed']);self.assertEqual(len(children),2)
        self.assertNotEqual(record['owner']['pid'],record['sibling']['pid'])
        self.assertEqual([c.argv[0] for c in children],['declared-base-python']*2)
        self.assertEqual(fixture.native_process_ready.call_count,1)

    async def test_changed_executable_rejected_before_popen_with_incomplete_receipt(self):
        root,children,fixture,record,raised,_=await self.exercise_driver(executable_changed=True)
        self.assertIsInstance(raised,ValueError);self.assertEqual(children,[])
        fixture.native_process_ready.assert_not_called();self.assertFalse(record['completed'])
        self.assertTrue((root/'client-result.json').is_file())

    async def test_stderr_and_nonzero_exit_are_retained_before_failure_propagates(self):
        for stderr,code in ((b'SECRET\n',0),(b'',7),(b'bad\xff\n',1)):
            with self.subTest(stderr=stderr,code=code):
                root,_,_,record,raised,_=await self.exercise_driver(stderr=stderr,exit_code=code)
                self.assertIsInstance(raised,ValueError);self.assertFalse(record['completed']);self.assertTrue(record['errors'])
                self.assertEqual(record['child_exit_codes'],{'owner':code})
                stream=record['diagnostics']['owner']['streams']['stderr']
                self.assertEqual(stream['raw_bytes'],len(stderr));self.assertEqual(stream['raw_sha256'],p.digest(stderr))
                retained=(root/stream['path']).read_bytes();self.assertNotIn(b'SECRET',retained)
                self.assertEqual(p.binding(root/stream['path']),{k:stream[k] for k in ('sha256','bytes')})
                if b'\xff' in stderr:self.assertEqual(stream['decode_error_type'],'UnicodeDecodeError')

    async def test_registration_and_finish_receipts_survive_fake_child(self):
        with tempfile.TemporaryDirectory() as temp:
            identity={'pid':111,'process_creation_filetime':222,'queried_executable_path':'python','executable':{'path':'python'}}
            receipt={'schema':'campaign002-native-owner-1','owner_kind':'transport_probe',**identity,'wall_unix_s':1,'monotonic_s':1}
            result={'ready_to_finish':True,'idle_seconds':1,'channels':[{'channel_id':1}]}
            class Process:
                pid=111
                def __init__(self,*a,**kw):self.stdin=io.BytesIO();self.returncode=None
                def poll(self):return self.returncode
                def wait(self,timeout):self.returncode=0;return 0
            class Log:
                def __init__(self,process,role,*a):self.process=process;self.role=role
                async def event(self,kind,deadline):return {'kind':kind,'result':result,'pid':111,'mode':'boundary_single_channel'}
                def finish(self,*a):return {'errors':[],'complete':True,'streams':{}}
            fixture=types.SimpleNamespace(evidence=Path(temp),client_finishing=threading.Event(),native_process_ready=mock.Mock(return_value=receipt),redact=lambda x:x)
            owner=types.SimpleNamespace(WindowsOwnerAPI=lambda:types.SimpleNamespace(process=lambda pid:{k:v for k,v in identity.items() if k!='executable'}),
                                        file_identity=lambda path:identity['executable'])
            with mock.patch.object(p.subprocess,'Popen',Process),mock.patch.object(p,'ChildLog',Log),mock.patch.object(p,'dependency',return_value=owner),\
                 mock.patch.object(p,'client_executable',return_value=identity['executable']):
                value=await p.drive_clients('http://127.0.0.1:1234',fixture,'boundary_single_channel',p.time.monotonic()+180)
            self.assertTrue(value['completed']);self.assertTrue(fixture.client_finishing.is_set())
            root=Path(temp);rows=[json.loads(r) for r in (root/'client/events.jsonl').read_text().splitlines()]
            self.assertEqual([r['kind'] for r in rows],['native_process_owner_registered','client_finishing_before_close','probe_client_closed'])
            self.assertEqual(rows[0]['receipt_sha256'],p.binding(root/'client/native-owner.json')['sha256'])
            self.assertEqual(json.loads((root/'client/native-owner.json').read_text()),receipt)
            self.assertFalse(json.loads((root/'diagnostic-case.json').read_text())['expected_failure'])
            self.assertEqual(value['launch_executable'],identity['executable'])
            self.assertEqual(fixture.native_process_ready.call_args.args[1],'python')

    async def test_deadline_rejects_before_popen(self):
        fixture=types.SimpleNamespace()
        with mock.patch.object(p.subprocess,'Popen') as launch:
            with self.assertRaises(ValueError):await p.drive_clients('unused',fixture,'multi_channel',p.time.monotonic()+100)
            launch.assert_not_called()

    async def test_boundary_uses_actual_bridge_api_and_no_case_expansion(self):
        with tempfile.TemporaryDirectory() as temp:
            fixture=types.SimpleNamespace(evidence=Path(temp));seen=[]
            write(Path(temp)/'client-result.json',{});(Path(temp)/'client-transcript.jsonl').write_text('{}\n')
            async def run(f,callback):seen.append(f);return await callback('http://127.0.0.1:1')
            async def drive(url,f,case,deadline):
                self.assertEqual(case,'boundary_single_channel')
                return {'completed':True,'result':{'channels':[{}],'idle_seconds':1}}
            with mock.patch.object(p,'dependency',return_value=types.SimpleNamespace(run=run)),mock.patch.object(p,'drive_clients',side_effect=drive):
                result=await p.boundary_probe(fixture)
            self.assertTrue(result['qualified']);self.assertEqual(fixture.native_owner_kind,'transport_probe')
            self.assertEqual(len(seen),1);self.assertEqual(len(p.make_cases()),3)


class DiagnosticRetentionTests(unittest.TestCase):
    def retain(self,stdout,stderr,redact=lambda s:s,limit=None):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);root=Path(temp.name);(root/'client').mkdir()
        process=types.SimpleNamespace(stdout=io.BytesIO(stdout),stderr=io.BytesIO(stderr))
        with mock.patch.object(p,'CLIENT_BYTES',limit or p.CLIENT_BYTES):
            log=p.ChildLog(process,'owner',root/'transcript.jsonl',threading.Lock())
            result=log.finish(root,redact)
        return root,result

    def test_output_overflow_drained_counted_hashed_and_bounded_without_partial_secret(self):
        data=b'valid line\n'+b'SECRET'*30
        root,result=self.retain(b'',data,limit=64)
        state=result['streams']['stderr'];self.assertFalse(result['complete']);self.assertTrue(state['truncated'])
        self.assertTrue(state['capture_complete']);self.assertEqual(state['raw_bytes'],len(data))
        self.assertEqual(state['raw_sha256'],p.digest(data));self.assertLessEqual(state['bytes'],64)
        self.assertEqual((root/state['path']).read_bytes(),b'valid line\n')

    def test_malformed_stdout_and_redaction_failure_leave_bounded_typed_diagnostics(self):
        def reject(_):raise RuntimeError('PRIVATE VALUE')
        root,result=self.retain(b'not json\xff\n',b'secret\n',reject)
        self.assertFalse(result['complete'])
        for state in result['streams'].values():
            raw=(root/state['path']).read_bytes();self.assertNotIn(b'secret',raw);self.assertNotIn(b'PRIVATE',raw)
            self.assertEqual(state['redaction_error_type'],'RuntimeError')
        self.assertEqual(result['streams']['stdout']['decode_error_type'],'UnicodeDecodeError')


class DirectExecutableTests(unittest.TestCase):
    def test_changed_base_path_or_bytes_rejected_without_child_launch(self):
        with tempfile.TemporaryDirectory() as temp:
            declared=Path(temp)/'base.exe';declared.write_bytes(b'expected')
            different=Path(temp)/'other.exe';different.write_bytes(b'other')
            identity={'path':str(declared.resolve()),'bytes':8,'sha256':p.digest(b'expected')}
            api=types.SimpleNamespace(file_identity=lambda path:dict(identity))
            with mock.patch.object(p,'CLIENT_EXECUTABLE',declared),mock.patch.object(p,'CLIENT_EXECUTABLE_BYTES',8),\
                 mock.patch.object(p,'CLIENT_EXECUTABLE_SHA256',identity['sha256']),mock.patch.object(p,'dependency',return_value=api),\
                 mock.patch.object(p.subprocess,'Popen') as launch:
                with mock.patch.object(p.sys,'_base_executable',str(different)):
                    with self.assertRaises(ValueError):p.client_executable()
                with mock.patch.object(p.sys,'_base_executable',str(declared)):
                    self.assertEqual(p.client_executable(),identity)
                    identity['sha256']='0'*64
                    with self.assertRaises(ValueError):p.client_executable()
                launch.assert_not_called()

    @unittest.skipUnless(os.name=='nt','Declared bounded Windows process identity check')
    def test_declared_base_python_popen_pid_is_actual_python_pid_without_socket_or_namespace(self):
        identity=p.client_executable()
        process=p.subprocess.Popen([identity['path'],'-I','-X','utf8','-B','-c',
            'import os,json; print(json.dumps({"pid":os.getpid()}),flush=True)'],
            stdin=p.subprocess.DEVNULL,stdout=p.subprocess.PIPE,stderr=p.subprocess.PIPE,
            creationflags=getattr(p.subprocess,'CREATE_NO_WINDOW',0))
        try:stdout,stderr=process.communicate(timeout=3)
        except BaseException:
            process.kill();process.communicate(timeout=3);raise
        self.assertEqual(process.returncode,0);self.assertEqual(stderr,b'');self.assertLess(len(stdout),128)
        self.assertEqual(json.loads(stdout),{'pid':process.pid})
        self.assertEqual(identity['sha256'],p.CLIENT_EXECUTABLE_SHA256)


if __name__=='__main__':unittest.main()
