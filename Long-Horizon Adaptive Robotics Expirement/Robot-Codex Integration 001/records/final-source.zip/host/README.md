# Development workcell host

`supervisor.py` implements public journaling, command identity/authority, continuity commits, native command normalization and handback. `run_host.py` binds it to byte-verified frozen Runtime 004 classes on the protected host, provides loopback HTTP, and runs baseline/reference/development-server modes. `challenges.py` holds operator-only initial fixtures and reference recoveries. None of these files belongs in Robot-Codex's permitted filesystem.

The final gateway revision rechecks each request's authenticated epoch after queueing, including note writes, and rotates capabilities immediately after an authority transition. Trusted in-process restarts have durable stable-ID receipts and query/retry semantics. Robot HTTP cannot invoke lifecycle restarts; a protected launcher-to-host lifecycle bridge remains unimplemented. These corrections were made after the four original native fixture attempts completed; their immutable source snapshots and results remain the evidence for those physical runs. New gateway tests use synthetic state and actual loopback HTTP, without creating a physical Cell or invoking a model.

Two implemented families use the existing physical scene and skills: healthy raw stock placed in quarantine (one required A part), and a raw workpiece occupying insert A's return home while a B job requires setup (two parts, one B required). The latter requires moving the blocker and completing setup before handback because the frozen baseline retains failure counts. Initial placement modifies free-joint poses only before episode timing; recovery never sets object state. The controller and simulator sources are imported unchanged and checked against the r4 artifact index.

Ordinary tabletop displacement is not a novel fixture: the frozen detector labels points outside named pads as `raw`. The new fixtures use existing excluded named pads. A fault-reset family is deferred because the simulator has no reset interface.

The reference is not proof until its queued run completes and shows physical actions, fresh public effects, accepted handback and useful resumed conventional work. Failures remain results. Reference plans, fixture identities, protected evaluator output, and manifests never enter public runtime files. The public episode identity is opaque.

Run synthetic tests (no physical Cell is instantiated):

```powershell
.\venv\Scripts\python.exe -X utf8 -B -m unittest discover -s "Long-Horizon Adaptive Robotics Expirement\Robot-Codex Integration 001\host" -p "test_*.py" -v
```

Create the four immutable development manifest drafts once with `run_host.py --write-manifests <new-directory>`. Register source/revision and each exact attempt through the existing map before physical execution. A manifest pins family, mode, seed, part count, order, initialization, caps, and operator reference steps. It is not a permission or launch record.

For each registered manifest, submit through the shared queue (replace paths with its exact planned paths):

```powershell
.\venv\Scripts\python.exe -X utf8 -B "C:\Users\cresp\Documents\Dandelion Engineering\tools\compute_queue\compute_queue.py" submit --project "LLMs-in-Robotics" --cwd "C:\Users\cresp\Documents\Dandelion Engineering\LLMs in Robotics" -- "C:\Users\cresp\Documents\Dandelion Engineering\LLMs in Robotics\venv\Scripts\python.exe" -X utf8 -B "Long-Horizon Adaptive Robotics Expirement\Robot-Codex Integration 001\host\run_host.py" --manifest "<registered-manifest.json>" --evidence "<new-protected-evidence-dir>" --runtime-workspace "<separate-runtime-dir>"
```

Require queue `state=succeeded` and `exit_status=0` before consuming completed outputs. Exit zero means the bounded host produced an honest terminal report, not task success; inspect `result.json`. A failed reference is preserved, not silently retried. `baseline` stops when the frozen controller itself requests assistance; it gets its existing bounded retry logic first. `reference` then uses the protected reference actions through the same gateway, observes them, hands back and waits for the independent evaluator. `serve` exposes the API and never launches a model itself; source/model verification and agent lifecycle are separate launcher responsibilities.

The native recorder reuses the separately versioned sustainable `FutureEvidence` backend, with drift-safe full-precision 100 Hz joint/TCP/effort motion, a live image ring with sparse two-second persistence, 50 MB core and 12 MB image quotas. Live sensing remains 10 Hz with no full-stream PNG/depth persistence. Authoritative public history and registry are separate, fsynced before action; runtime files mirror this public history. All observations/actions are retained as small structured records. Explicit overhead image requests retain at most 50 images. Total protected evidence plus runtime `live/` is checked against 200 MiB; individual writer budgets reserve headroom. These runs retain timing lag rather than asserting production real-time performance. Recorder source hashes are saved independently and can be required through manifest `recorder_source_sha256`.

World time is wall-paced and never deliberately stopped while the agent reasons. Synchronous JSON/fsync and sparse image compression can add measured lag; no conclusion about responsiveness follows from an unqualified development host. The existing low-level limits are not a whole-arm collision safety certificate. Generated program isolation and complete supervisor crash recovery are not implemented. See [API](API.md) for the exact callable surface and limits.
