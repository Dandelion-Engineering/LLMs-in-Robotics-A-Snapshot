"""Bounded synthetic adversarial checks; no native/model process is launched."""
import ast
import base64
import copy
import json
from pathlib import Path
import shlex
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import canary_readback_proof as proof
from canary_exit_proof import CHECK_KEYS, SCOPE
from retained_reads import canonical, sha

TARGET='notes/resume-boundary-observation.json'
SIDECAR='notes/resume-boundary-execution.json'


def recipe(target=TARGET,sidecar=SIDECAR):
    return (f'python3 /canary.py > {target}\ncanary_exit=$?\npython3 -B - "$canary_exit" <<\'PY\'\n'
            f"import json,sys\nfrom pathlib import Path\np=Path({target!r})\nr=json.loads(p.read_text())\n"
            f"Path({sidecar!r}).write_text(json.dumps({{'exit_code':int(sys.argv[1]),'output_file':str(p)}},indent=2)+'\\n')\n"
            "print(json.dumps(r,indent=2))\nPY")


def argv(script):return ['/usr/bin/bash','-lc',script]
def document():return {'qualified':True,'checks':dict.fromkeys(sorted(CHECK_KEYS),True),'details':{},'scope':SCOPE}
def file_record(raw):return {'bytes':len(raw),'sha256':sha(raw),'retained_sha256':sha(raw),'base64':base64.b64encode(raw).decode()}


class Capture:
    def __init__(self):self.rows=[];self.delivered=set();self.events=[];self.clock=1.
    def add(self,kind,message=None,**extra):
        row={'schema':'campaign002-executor-capture-1','connection_id':'1','sequence':len(self.rows)+1,
             'previous_sha256':self.rows[-1]['record_sha256'] if self.rows else None,
             'wall_unix_s':self.clock,'kind':kind,**extra};self.clock+=.01
        if message is not None:
            row.update(message=message,original_message_sha256=sha(canonical(message)),
                       retained_message_sha256=sha(canonical(message)),blobs=[])
            if message.get('method')=='process/output':
                b=base64.b64decode(message['params']['chunk'])
                row['blobs']=[{'path':['params','chunk'],'raw_bytes':len(b),'retained_bytes':len(b),
                               'raw_sha256':sha(b),'retained_sha256':sha(b)}]
        row['record_sha256']=sha(canonical(row));self.rows.append(row);return row
    def response(self,message):
        row=self.add('response',message);self.delivered.add(row['sequence'])
        self.add('delivered',response_sequence=row['sequence']);return row
    def process(self,script,code=0,stdout=b'{}',stderr=b'',identity='exec-one',probe=False):
        pid='canary' if probe else identity
        params={'arg0':None,'argv':['/usr/bin/python3','-I','-B','/canary.py'] if probe else argv(script),
                'cwd':'file:///workspace','env':{'HOME':'/workspace','PATH':'/usr/bin:/bin'} if probe else {'LANG':'C.UTF-8'},
                'processId':pid,'sandbox':None,'tty':False}
        if not probe:params.update(pipeStdin=False,metadata={'toolCallId':identity,'threadId':'thread'},
            envPolicy={'inherit':'none','includeOnly':[],'ignoreDefaultExcludes':False,'set':{}})
        request=self.add('request',{'id':len(self.rows)+1,'method':'process/start','params':params})
        self.response({'id':request['message']['id'],'result':{'processId':pid}})
        seq=1
        for stream,data in [('stdout',stdout),('stderr',stderr)]:
            if data:self.response({'method':'process/output','params':{'processId':pid,'seq':seq,'stream':stream,'chunk':base64.b64encode(data).decode()}});seq+=1
        self.response({'method':'process/exited','params':{'processId':pid,'seq':seq,'exitCode':code}});seq+=1
        self.response({'method':'process/closed','params':{'processId':pid,'seq':seq}})
        if not probe:
            item={'id':identity,'type':'commandExecution','command':shlex.join(argv(script)),
                  'status':'completed','exitCode':code,'aggregatedOutput':stdout.decode()}
            for method in ['item/started','item/completed']:
                self.events.append({'method':method,'emittedAtMs':int((self.clock+.01)*1000),
                                    'params':{'threadId':'thread','turnId':'turn','item':item.copy()}})
            self.clock+=.1
        return request


class RecipeTests(unittest.TestCase):
    def test_exact_candidate(self):
        self.assertEqual(proof.readback_recipe(argv(recipe()))['output'],TARGET)
    def test_candidate_attacks(self):
        original=recipe()
        attacks=[original+'\necho done',original.replace('canary_exit=$?','canary_exit=0'),
                 original.replace('r=json.loads(p.read_text())','r={"qualified":True}'),
                 original.replace('import json,sys','import json,sys,os'),
                 original.replace('print(json.dumps(r,indent=2))','r["qualified"]=True\nprint(json.dumps(r,indent=2))'),
                 original.replace('python3 /canary.py','false #python3 /canary.py'),
                 recipe(sidecar=TARGET),recipe(target='notes/../canary.json'),
                 recipe(sidecar=TARGET+'/child'),recipe(target='notes/canary-write.txt')]
        for attack in attacks:
            with self.subTest(attack=attack[:80]):
                try:value=proof.readback_recipe(argv(attack))
                except ValueError:continue
                self.assertIsNone(value)
    def test_three_exact_readonly_asts(self):
        for prefix,body in proof.READ_ONLY_BODIES:
            value=proof.preceding_recipe(argv(prefix+"python3 -B - <<'PY'\n"+body+'\nPY'),[TARGET,SIDECAR])
            self.assertEqual(value['kind'],'reviewed_readonly_json_projection')
    def test_readonly_ast_extension_rejected(self):
        for prefix,body in proof.READ_ONLY_BODIES:
            for extra in ['\nopen("notes/x","w").write("x")','\nimport subprocess','\nprint(eval("1"))']:
                with self.assertRaises(ValueError):proof.preceding_recipe(argv(prefix+"python3 -B - <<'PY'\n"+body+extra+'\nPY'),[TARGET,SIDECAR])
    def test_unknown_writers_and_backgrounds(self):
        for script in ['cat Tasks.md &','sleep 1 &','python3 writer.py','python3 -c "print(1)"',
                       'echo harmless','cat Tasks.md > notes/x','find notes -exec touch notes/x ;',
                       'sed -n "1e touch notes/x" robot.py','cat $(touch notes/x)','cat Tasks.md; true']:
            with self.subTest(script=script),self.assertRaises(ValueError):proof.preceding_recipe(argv(script),[TARGET,SIDECAR])
    def test_fixed_get_redirect_excludes_target_or_alias(self):
        for path in [TARGET,SIDECAR,TARGET+'/child','notes/../x']:
            with self.assertRaises(ValueError):proof.preceding_recipe(argv(f'python3 -B robot.py query id > {path}\ncat {path}'),[TARGET,SIDECAR])
    def test_fixed_get_and_cat_allowed(self):
        for kind in ['query id','history --after 3214 --limit 42']:
            self.assertEqual(proof.preceding_recipe(argv(f'python3 -B robot.py {kind} > notes/other.json\ncat notes/other.json'),[TARGET,SIDECAR])['writes'],['notes/other.json'])
    def test_wrapper_is_closed(self):
        command=json.dumps({'cmd':'cat Tasks.md','workdir':'/workspace'})
        single=f'text(await tools.exec_command({command}));'
        self.assertEqual(len(proof.wrapper_commands(single)),1)
        parallel=f'const results = await Promise.allSettled([tools.exec_command({command})]); for (let i=0;i<results.length;i++) text({{i,...results[i]}});'
        self.assertEqual(len(proof.wrapper_commands(parallel)),1)
        for bad in [single+'fetch("x")',single.replace('exec_command','other_tool'),parallel.replace('i=0','i=1')]:
            with self.assertRaises(ValueError):proof.wrapper_commands(bad)


class ProcessTests(unittest.TestCase):
    def test_nonzero127_is_accounted(self):
        c=Capture();c.add('open');r=c.process('pwd && rg --files',code=127,stderr=b'rg: command not found\n')
        value=proof.process_record(c.rows,c.delivered,r,c.events)
        self.assertEqual(value['exit_code'],127);self.assertTrue(value['stderr'])
    def test_incomplete_or_unmatched_process_rejected(self):
        for attack in ['noexit','noclose','nodelivery','noapp','duplicate','redacted','wrongexit','shadowenv','outputgap']:
            with self.subTest(attack=attack):
                c=Capture();c.add('open');r=c.process(recipe(),stdout=json.dumps(document()).encode())
                if attack=='noexit':c.rows[:]=[x for x in c.rows if x.get('message',{}).get('method')!='process/exited']
                if attack=='noclose':c.rows[:]=[x for x in c.rows if x.get('message',{}).get('method')!='process/closed']
                if attack=='nodelivery':c.delivered.clear()
                if attack=='noapp':c.events.clear()
                if attack=='duplicate':c.events.append(copy.deepcopy(c.events[-1]))
                if attack=='redacted':r['original_message_sha256']='0'*64
                if attack=='wrongexit':c.events[-1]['params']['item']['exitCode']=False
                if attack=='shadowenv':r['message']['params']['env']['PYTHONPATH']='notes'
                if attack=='outputgap':next(x for x in c.rows if x.get('message',{}).get('method')=='process/output')['message']['params']['seq']=44
                with self.assertRaises(ValueError):proof.process_record(c.rows,c.delivered,r,c.events)
    def test_real_prefix_shaped_exclusivity(self):
        c=Capture();c.add('open');requests=[]
        requests.append(c.process('',probe=True,stdout=json.dumps(document()).encode()))
        scripts=['ls -la /workspace',"pwd && rg --files -g 'RobotAgentPrompt.md' -g 'AGENTS.md' -g 'SKILL.md' -g '!node_modules' -g '!vendor' /workspace",
                 'find /workspace -name AGENTS.md -o -name SKILL.md','cat AGENTS.md RobotAgentPrompt.md',
                 'cat Tasks.md Robot.md Tools.md','cat live/activation.json live/state.json Continuity.md','cat Tools.md',
                 "cat live/activation.json && find notes programs live -maxdepth 2 -type f -printf '%p\\n'",
                 "python3 -B robot.py query smoke-open-001 > notes/resume-open-terminal.json\ncat notes/resume-open-terminal.json",
                 "python3 -B robot.py history --after 3214 --limit 42 > notes/resume-history-interruption.json\ncat notes/resume-history-interruption.json",
                 "cat notes/smoke-observation.json\nsed -n '1,320p' robot.py"]
        scripts += [prefix+"python3 -B - <<'PY'\n"+body+'\nPY' for prefix,body in proof.READ_ONLY_BODIES]
        self.assertEqual(len(scripts),14)
        for i,script in enumerate(scripts):requests.append(c.process(script,127 if script.startswith('pwd &&') else 0,identity='exec-'+str(i)))
        requests.append(c.process(recipe(),stdout=json.dumps(document()).encode(),identity='selected'))
        processes=[proof.process_record(c.rows,c.delivered,r,c.events) for r in requests]
        for p in processes:p['capture']='executor-1-capture.jsonl'
        value=proof.prefix_exclusive(processes,processes[-1]);self.assertEqual(value['processes_including_candidate'],16)
        self.assertEqual(value['nonzero_exit_count'],1)
        for change in ['overlap','writer','bad127']:
            bad=copy.deepcopy(processes)
            if change=='overlap':bad[1]['execution']['evidence_complete_upper_wall_unix_s']=bad[-1]['execution']['request_wall_unix_s']
            if change=='writer':bad[1]['argv']=argv('sleep 1 &')
            if change=='bad127':bad[1]['exit_code']=127
            with self.assertRaises(ValueError):proof.prefix_exclusive(bad,bad[-1])


class RestoreAndDocumentTests(unittest.TestCase):
    def test_snapshot_retained_bytes_and_aliases(self):
        value={'files':{'notes/a':file_record(b'a')},'total_bytes':1,'scope':'actual file bytes; endpoint omitted'}
        self.assertEqual(proof.snapshot_files(value),{'notes/a':b'a'})
        for mutate in [lambda x:x['files']['notes/a'].update(sha256='0'*64),
                       lambda x:x['files'].update({'notes/a/child':file_record(b'x')}),
                       lambda x:x.update(total_bytes=True),lambda x:x['files'].update({'notes/../x':file_record(b'x')})]:
            bad=copy.deepcopy(value);mutate(bad)
            with self.assertRaises(ValueError):proof.snapshot_files(bad)
    def test_duplicate_and_changed_checks(self):
        with self.assertRaises(ValueError):proof.json_document('{"qualified":false,"qualified":true}')
        for mutate in [lambda x:x.update(qualified=False),lambda x:x['checks'].update(workspace_read=1),lambda x:x['checks'].pop('workspace_read')]:
            value=document();mutate(value)
            with self.assertRaises(ValueError):proof.check_document(value)
    def test_wrong_source_abstains(self):
        with tempfile.TemporaryDirectory() as folder:
            r=Path(folder);(r/'runtime-input-hashes.json').write_text('{}');z=r/'source.zip'
            with zipfile.ZipFile(z,'w') as archive:archive.writestr('unexpected.py','pass')
            result=proof.canary_readback_evidence(r,z)
            self.assertFalse(result['verified']);self.assertEqual(result['evidence'],[]);self.assertTrue(result['errors'])
    def test_missing_restore_never_becomes_a_claim(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'resume';root.mkdir()
            with self.assertRaises(OSError):proof.restoration_proof(root,{},TARGET,SIDECAR,[])


if __name__=='__main__':unittest.main()
